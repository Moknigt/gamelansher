"""Runs slow work (network) off the UI thread, so the window never freezes.

    run_async(lambda: backend.add_game(path), lambda result, error: ...)

`fn` runs in a worker thread. `done(result, error)` is always called later on the UI thread
(error is None on success, otherwise the exception).
Create the first call from the UI thread (it makes the small QObject that lives there).
"""
import itertools

from PySide6.QtCore import QObject, QRunnable, Qt, QThreadPool, Signal, Slot


class _Signals(QObject):
    finished = Signal(int, object, object)


class _Job(QRunnable):
    def __init__(self, jid, fn, sig):
        super().__init__()
        self.jid, self.fn, self.sig = jid, fn, sig

    def run(self):
        res, err = None, None
        try:
            res = self.fn()
        except BaseException as ex:          # noqa: BLE001 - everything goes back to the UI
            err = ex
        self.sig.finished.emit(self.jid, res, err)


class _Hub(QObject):
    def __init__(self):
        super().__init__()
        self.sig = _Signals()
        self.sig.finished.connect(self._finish, Qt.ConnectionType.QueuedConnection)
        self.ids = itertools.count(1)
        self.cbs = {}
        self.pool = QThreadPool()
        self.pool.setMaxThreadCount(3)

    @Slot(int, object, object)
    def _finish(self, jid, res, err):
        cb = self.cbs.pop(jid, None)
        if cb:
            cb(res, err)

    def run(self, fn, done):
        jid = next(self.ids)
        self.cbs[jid] = done
        self.pool.start(_Job(jid, fn, self.sig))


_hub = None


def run_async(fn, done):
    global _hub
    if _hub is None:
        _hub = _Hub()
    _hub.run(fn, done)
