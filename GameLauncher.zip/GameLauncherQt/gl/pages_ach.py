"""Achievements screen: Overview / All Games / Stats / Settings (chosen from the side list)."""
import time

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFontMetrics, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QLabel, QLineEdit, QVBoxLayout, QWidget

from .icons import draw_icon, icon
from .theme import T
from .i18n import tr as _t
from .util import TIER_NAME, TIER_XP, fmt_long, hue_color
from .widgets import (AA, SMOOTH, Bar, Btn, Emblem, LogoMark, Panel, SmoothScroll, StatCard, Switch, TierIcon,
                      draw_badge, draw_cover, label, load_pix, mkfont, tier_pix, white)

APP_NAME = "Game Launcher"
TIERS = ("plat", "gold", "silver", "bronze")


def fmt_date(ts):
    return time.strftime("%d %b %Y", time.localtime(ts)) if ts else ""


class ClickLabel(QLabel):
    clicked = Signal()

    def __init__(self, text, parent=None):
        super().__init__(_t(text), parent)
        self.setFont(mkfont(14, 600))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("color:#ffffff; background:transparent;")

    def mousePressEvent(self, e):
        self.clicked.emit()

    def enterEvent(self, e):
        self.setStyleSheet(f"color:{T.ac2.name()}; background:transparent;")

    def leaveEvent(self, e):
        self.setStyleSheet("color:#ffffff; background:transparent;")


class Flow(QWidget):
    """Lays fixed-size children out in wrapping rows."""

    def __init__(self, gap=14, parent=None):
        super().__init__(parent)
        self.gap = gap
        self.kids = []

    def add(self, w):
        w.setParent(self)
        w.show()
        self.kids.append(w)
        self._lay()

    def _lay(self):
        x = y = rowh = 0
        W = max(1, self.width())
        for w in self.kids:
            if x and x + w.width() > W:
                x, y, rowh = 0, y + rowh + self.gap, 0
            w.move(x, y)
            x += w.width() + self.gap
            rowh = max(rowh, w.height())
        h = y + rowh
        if self.minimumHeight() != h:
            self.setMinimumHeight(h)
            self.setMaximumHeight(h)

    def resizeEvent(self, e):
        self._lay()


class GameRow(QWidget):
    clicked = Signal(str)

    def __init__(self, row, parent=None):
        super().__init__(parent)
        self.r, self.hover = row, False
        self.setFixedHeight(96)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mousePressEvent(self, e):
        self.clicked.emit(self.r["gid"])

    def paintEvent(self, _e):
        r = self.r
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        box = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(QColor(10, 16, 40, 170 if self.hover else 140))
        p.setPen(QPen(T.ac_a(0.8 if self.hover else 0.3), 1.3))
        p.drawRoundedRect(box, 18, 18)
        th = QRectF(14, 10, 136, 76)
        if r.get("brand"):
            p.setBrush(T.ac_a(0.25))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(th, 12, 12)
            draw_icon(p, "gamepad", QRectF(th.center().x() - 18, th.center().y() - 18, 36, 36), "#ffffff")
        else:
            pm = load_pix(r.get("hero")) or load_pix(r.get("cover"))
            from PySide6.QtGui import QPainterPath
            path = QPainterPath()
            path.addRoundedRect(th, 12, 12)
            p.save()
            p.setClipPath(path)
            if pm:
                draw_cover(p, pm, th)
            else:
                g = QLinearGradient(th.topLeft(), th.bottomRight())
                g.setColorAt(0, hue_color(r["name"]))
                g.setColorAt(1, QColor("#0b1020"))
                p.fillRect(th, g)
                p.setPen(QColor("#ffffff"))
                p.setFont(mkfont(32, 700))
                p.drawText(th, Qt.AlignmentFlag.AlignCenter, (r["name"] or "?")[:1].upper())
            p.restore()
        W = self.width()
        tx = 168
        tiers_x = W - 20 - 4 * 62
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(18, 700))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(tx, 16, max(60, min(300, W * 0.30)), 28), Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(r["name"], Qt.TextElideMode.ElideRight, int(max(60, min(300, W * 0.30)))))
        p.drawPixmap(tx, 52, tier_pix("gold", 18))
        p.setFont(mkfont(13.5, 400))
        p.setPen(white(190))
        p.drawText(QRectF(tx + 24, 50, 260, 22), Qt.AlignmentFlag.AlignVCenter, _t(f"{r['done']} / {r['total']} Achievements"))
        bx = max(tx + 330, W * 0.5)
        bw = max(60, tiers_x - 70 - bx)
        bar = QRectF(bx, 43, bw, 9)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(white(36))
        p.drawRoundedRect(bar, 4.5, 4.5)
        if r["pc"] > 0:
            g = QLinearGradient(bar.topLeft(), bar.topRight())
            g.setColorAt(0, T.ac)
            g.setColorAt(1, T.ac2)
            p.setBrush(g)
            p.drawRoundedRect(QRectF(bar.left(), bar.top(), max(9, bw * r["pc"] / 100), 9), 4.5, 4.5)
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(15, 700))
        p.drawText(QRectF(bar.right() + 10, 34, 56, 28), Qt.AlignmentFlag.AlignVCenter, f"{r['pc']}%")
        p.setFont(mkfont(14, 600))
        for i, t in enumerate(TIERS):
            x = tiers_x + i * 62
            p.drawPixmap(int(x), 38, tier_pix(t, 20))
            p.drawText(QRectF(x + 24, 34, 36, 28), Qt.AlignmentFlag.AlignVCenter, str(r["t"][t]))


class RecentCard(QWidget):
    clicked = Signal(str)

    def __init__(self, it, parent=None):
        super().__init__(parent)
        self.it, self.hover = it, False
        self.setFixedSize(206, 196)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mousePressEvent(self, e):
        self.clicked.emit(self.it["gid"])

    def paintEvent(self, _e):
        it = self.it
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        box = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        from PySide6.QtGui import QPainterPath
        path = QPainterPath()
        path.addRoundedRect(box, 18, 18)
        p.save()
        p.setClipPath(path)
        p.fillRect(box, QColor(10, 16, 40, 190))
        art = QRectF(box.left(), box.top(), box.width(), 104)
        pm = load_pix(it.get("hero")) or load_pix(it.get("cover"))
        if pm:
            draw_cover(p, pm, art)
        else:
            g = QLinearGradient(art.topLeft(), art.bottomRight())
            g.setColorAt(0, T.ac_a(0.55))
            g.setColorAt(1, QColor("#0b1020"))
            p.fillRect(art, g)
        sh = QLinearGradient(art.topLeft(), art.bottomLeft())
        sh.setColorAt(0.4, QColor(0, 0, 0, 0))
        sh.setColorAt(1, QColor(0, 0, 0, 120))
        p.fillRect(art, sh)
        p.restore()
        draw_badge(p, 46, it["tier"], it["icon"], False, 12, 104 - 30)
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(14, 700))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(14, 116, 180, 20), Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(_t(it["name"]), Qt.TextElideMode.ElideRight, 178))
        p.setFont(mkfont(12, 400))
        p.setPen(white(165))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(14, 138, 180, 18), Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(it.get("gname", ""), Qt.TextElideMode.ElideRight, 178))
        p.drawPixmap(14, 166, tier_pix(it["tier"], 18))
        p.setPen(white(200))
        p.drawText(QRectF(38, 164, 80, 22), Qt.AlignmentFlag.AlignVCenter, f"{TIER_XP[it['tier']]} XP")
        p.drawText(QRectF(100, 164, 94, 22), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, _t(fmt_date(it.get("ts"))))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(T.ac_a(0.85 if self.hover else 0.3), 1.3))
        p.drawRoundedRect(box, 18, 18)


def aggregate(data):
    rows = [{"gid": "", "name": APP_NAME, "items": data["launcher"], "brand": True, "hero": "", "cover": ""}]
    for g in data["games"]:
        rows.append({"gid": g["id"], "name": g["name"], "items": g["items"], "hero": g["hero_path"], "cover": g["cover_path"]})
    all_items = []
    for r in rows:
        for i in r["items"]:
            d = dict(i)
            d.update(gid=r["gid"], gname=r["name"], hero=r["hero"], cover=r["cover"])
            all_items.append(d)
    done = [i for i in all_items if i["achieved"]]
    prog = [i for i in all_items if not i["achieved"] and i["cur"] > 0]
    lock = [i for i in all_items if not i["achieved"] and not i["cur"] > 0]
    for r in rows:
        r["done"] = sum(1 for i in r["items"] if i["achieved"])
        r["total"] = len(r["items"])
        r["pc"] = round(100 * r["done"] / r["total"]) if r["total"] else 0
        r["t"] = {t: 0 for t in TIERS}
        for i in r["items"]:
            if i["achieved"]:
                r["t"][i["tier"]] += 1
    return {"rows": rows, "all": all_items, "done": done, "prog": prog, "lock": lock,
            "xp": sum(TIER_XP[i["tier"]] for i in done)}


class AchPage(QWidget):
    open_game = Signal(str)      # "" = the launcher's own trophies
    go = Signal(str)             # switch sub-page
    saved = Signal(str)          # toast text

    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.be = backend
        self.scroll = SmoothScroll(self)
        self.inner = QWidget()
        self.lay = QVBoxLayout(self.inner)
        self.lay.setContentsMargins(8, 6, 40, 40)
        self.lay.setSpacing(0)
        self.scroll.setWidget(self.inner)
        self.sub = "overview"

    def resizeEvent(self, e):
        self.scroll.setGeometry(0, 0, self.width(), self.height())

    # ------------------------------------------------------------------ helpers
    def _clear(self):
        while self.lay.count():
            it = self.lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
            elif it.layout():
                self._drop(it.layout())

    def _drop(self, lay):
        while lay.count():
            it = lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()

    def _title(self, text, ic):
        row = QHBoxLayout()
        row.setSpacing(12)
        i = QLabel()
        i.setPixmap(icon(ic, 30, "#ffffff"))
        row.addWidget(i)
        row.addWidget(label(text, 27, 700))
        row.addStretch(1)
        self.lay.addLayout(row)
        self.lay.addSpacing(18)

    def _sec(self, text, ic, link=None):
        self.lay.addSpacing(26)
        row = QHBoxLayout()
        row.setSpacing(10)
        i = QLabel()
        i.setPixmap(icon(ic, 22, "#ffffff"))
        row.addWidget(i)
        row.addWidget(label(text, 19, 700))
        row.addStretch(1)
        if link:
            lk = ClickLabel("See All  ›")
            lk.clicked.connect(lambda: self.go.emit(link))
            row.addWidget(lk)
        self.lay.addLayout(row)
        self.lay.addSpacing(12)

    def _note(self, text):
        n = label(text, 14, 400, wrap=True, alpha=0.75)
        self.lay.addWidget(n)

    def _rows(self, rows):
        for r in rows:
            w = GameRow(r)
            w.clicked.connect(self.open_game)
            self.lay.addWidget(w)
            self.lay.addSpacing(10)

    # ------------------------------------------------------------------ pages
    def show_sub(self, sub, games, settings):
        self.sub = sub
        self._clear()
        A = aggregate(self.be.ach_overview())
        if sub == "games":
            self._title("All Games", "gamepad")
            self._rows(A["rows"])
        elif sub == "stats":
            self._stats(A, games)
        else:
            self._overview(A)
        self.lay.addStretch(1)
        self.scroll.scroll_to(0, instant=True)

    def _overview(self, A):
        total = len(A["all"])
        pc = round(100 * len(A["done"]) / total) if total else 0
        head = QHBoxLayout()
        head.setSpacing(30)
        left = QVBoxLayout()
        left.setSpacing(0)
        left.addWidget(Emblem(), 0, Qt.AlignmentFlag.AlignHCenter)
        el = label("Achievements", 20, 700, serif=True)
        el.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        left.addWidget(el)
        head.addLayout(left)
        panel = Panel(radius=22, border=0.3)
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(30, 26, 30, 26)
        pl.setSpacing(20)
        cols = QHBoxLayout()
        cols.setSpacing(10)
        for t, n, lab in (("plat", total, "Total Achievements"), ("gold", len(A["done"]), "Completed"),
                          ("silver", len(A["prog"]), "In Progress"), ("bronze", len(A["lock"]), "Locked")):
            c = QVBoxLayout()
            c.setSpacing(4)
            c.addWidget(TierIcon(t, 30), 0, Qt.AlignmentFlag.AlignHCenter)
            nl = label(str(n), 28, 700)
            nl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            c.addWidget(nl)
            ll = label(lab, 13, 400, alpha=0.75)
            ll.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            c.addWidget(ll)
            cols.addLayout(c, 1)
        pl.addLayout(cols)
        br = QHBoxLayout()
        br.setSpacing(14)
        br.addWidget(Bar(pc / 100, 10), 1)
        br.addWidget(label(f"{pc}%", 17, 700))
        pl.addLayout(br)
        head.addWidget(panel, 1)
        self.lay.addLayout(head)
        self._sec("Recent Achievements", "clock")
        rec = sorted((i for i in A["done"] if i.get("ts")), key=lambda i: -i["ts"])[:9]
        if rec:
            fl = Flow(16)
            for i in rec:
                c = RecentCard(i)
                c.clicked.connect(self.open_game)
                fl.add(c)
            self.lay.addWidget(fl)
        else:
            self._note("Nothing unlocked yet. Add a game, start it, mark a favorite… trophies unlock as you use the launcher.")
        self._sec("Game Achievements", "star", link="games")
        top = sorted(A["rows"], key=lambda r: (-r["pc"], -r["done"]))[:3]
        self._rows(top)

    def _stats(self, A, games):
        self._title("Stats", "stats")
        tot = sum(g.get("playtime", 0) for g in games)
        launches = sum(g.get("launches", 0) for g in games)
        favs = sum(1 for g in games if g.get("fav"))
        fl = Flow(14)
        for ic, lab, val in (("clock", "Total play time", fmt_long(tot)), ("play", "Game launches", str(launches)),
                             ("gamepad", "Games in library", str(len(games))), ("heart", "Favorites", str(favs)),
                             ("trophy", "Trophies earned", f"{len(A['done'])} / {len(A['all'])}"),
                             ("star", "Total XP", str(A["xp"]))):
            fl.add(StatCard(ic, lab, val))
        self.lay.addWidget(fl)
        self._sec("Most played", "stats")
        top = sorted((g for g in games if g.get("playtime", 0) > 0), key=lambda g: -g["playtime"])[:6]
        if top:
            mx = top[0]["playtime"]
            for g in top:
                self._hbar(g["name"], max(0.03, g["playtime"] / mx), fmt_long(g["playtime"]))
        else:
            self._note("No play time yet. Turn on “Count play time” in Achievements → Settings.")
        self._sec("Trophies by tier", "trophy")
        tc = {t: 0 for t in TIERS}
        for i in A["done"]:
            tc[i["tier"]] += 1
        tmax = max(1, max(tc.values()))
        for t in TIERS:
            self._hbar(_t(TIER_NAME[t]), tc[t] / tmax, str(tc[t]))

    def _hbar(self, name, frac, val):
        row = QHBoxLayout()
        row.setSpacing(14)
        nm = label(name, 14.5, 600)
        nm.setFixedWidth(210)
        nm.setText(QFontMetrics(nm.font()).elidedText(name, Qt.TextElideMode.ElideRight, 205))
        row.addWidget(nm)
        row.addWidget(Bar(frac, 10), 1)
        v = label(val, 14.5, 600, alpha=0.85)
        v.setFixedWidth(90)
        v.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        row.addWidget(v)
        self.lay.addLayout(row)
        self.lay.addSpacing(12)
