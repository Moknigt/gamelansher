"""The tiny hidden helper (PART 3).  `python main.py --track <gameid>`  /  `GameLauncher.exe --track <gameid>`

It has NO window and does NOT import Qt. It only exists while a game is open, and only when the user
turned on "Count play time" and/or "Open the launcher again when I close the game" in Settings.
With both off, nothing of the launcher stays running: the launcher starts the game itself and closes.

What it does: starts the game, counts play time (optional), exits as soon as the game is closed,
then opens the launcher again (optional).
"""
import os
import subprocess
import sys
import time

from . import paths
from .store import find_game, load_db, mutate

DEVNULL = subprocess.DEVNULL
DETACH = (0x00000008 | 0x00000200 | 0x08000000) if paths.IS_WIN else 0
NOWIN = 0x08000000 if paths.IS_WIN else 0

POLL_FAST = 3          # seconds between checks while the game process we started is alive
POLL_SLOW = 8          # seconds between checks when we have to look for the game by folder
APPEAR_WAIT = 120      # how long we wait for the game to show up (launchers that start the real game later)
MIN_REAL_RUN = 30      # a process that ran at least this long and ended = the real game ended


def helper_command(*args):
    """The command line that starts this program again (as the helper, or as the launcher)."""
    if paths.FROZEN:
        return [sys.executable, *args]
    main_py = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "main.py")
    return [sys.executable, main_py, *args]


def spawn_detached(cmd, cwd=None):
    env = dict(os.environ)
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"      # must not reuse the parent's temp folder
    kw = dict(stdin=DEVNULL, stdout=DEVNULL, stderr=DEVNULL, close_fds=True, env=env, cwd=cwd)
    if paths.IS_WIN:
        kw["creationflags"] = DETACH
    else:
        kw["start_new_session"] = True
    return subprocess.Popen(cmd, **kw)


def folder_has_running(folder):
    """True if some process is running from inside `folder` (for launchers that start the real game)."""
    prefix = os.path.normcase(os.path.abspath(folder)).rstrip("\\/") + os.sep
    try:
        import psutil
        me = os.getpid()
        for p in psutil.process_iter(["exe"]):
            try:
                exe = p.info.get("exe")
                if exe and p.pid != me and os.path.normcase(exe).startswith(prefix):
                    return True
            except Exception:
                pass
        return False
    except ImportError:
        pass
    if paths.IS_WIN:
        ps = ("$d=$env:GL_DIR; if (Get-Process | Where-Object { $_.Path -and "
              "$_.Path.StartsWith($d,[StringComparison]::OrdinalIgnoreCase) }) {'1'} else {'0'}")
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                               stdin=DEVNULL, capture_output=True, text=True, timeout=40,
                               env=dict(os.environ, GL_DIR=prefix), creationflags=NOWIN)
            return r.stdout.strip() == "1"
        except Exception:
            return False
    return False


def add_playtime(gid, secs):
    if secs <= 0:
        return

    def fn(db):
        try:
            g = find_game(db, gid)
        except KeyError:
            return
        g["playtime"] = int(g.get("playtime", 0) + secs)
    mutate(fn)


def reopen_launcher():
    try:
        spawn_detached(helper_command())
    except Exception:
        pass


def run_tracker(gid):
    """Blocks until the game is closed. Reads the two settings itself."""
    db = load_db()
    count = bool(db["settings"].get("track_play"))
    reopen = bool(db["settings"].get("reopen_after"))
    try:
        g = find_game(db, gid)
    except KeyError:
        if reopen:
            reopen_launcher()
        return
    path = g["path"]
    folder = os.path.dirname(path)
    try:
        _watch(gid, path, folder, count)
    finally:
        if reopen:
            reopen_launcher()


def _watch(gid, path, folder, count):
    t0 = time.time()
    popen = None
    try:
        if path.lower().endswith(".exe"):
            popen = subprocess.Popen([path], cwd=folder)
        else:
            raise OSError("use shell")
    except OSError:
        try:
            if paths.IS_WIN:
                os.startfile(path)          # shortcuts, .bat files and games that ask for admin rights
            else:
                popen = subprocess.Popen([path], cwd=folder)
        except Exception:
            return
    popen_end = [None]

    def alive():
        if popen is not None:
            if popen.poll() is None:
                return True
            if popen_end[0] is None:
                popen_end[0] = time.time()
            if popen_end[0] - t0 >= MIN_REAL_RUN:      # a real game process that ran a while and ended
                return False
        return folder_has_running(folder)              # stub launcher or shortcut: watch the game folder

    started = last_seen = last_flush = None
    deadline = t0 + APPEAR_WAIT
    while True:
        now = time.time()
        if alive():
            if started is None:
                started = last_flush = now
            last_seen = now
            if count and now - last_flush >= 60:
                add_playtime(gid, now - last_flush)
                last_flush = now
        else:
            if started is not None:
                if count:
                    add_playtime(gid, last_seen - last_flush)
                return
            if now > deadline:
                return
        time.sleep(POLL_FAST if (popen is not None and popen.poll() is None) else POLL_SLOW)
