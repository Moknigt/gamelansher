"""Everything the interface needs from the data side. The UI talks ONLY to this class.

PART 1 (this version): reading/saving games.json, favorites, rename/remove, simple add (no online picture),
launcher trophies + per-game trophies, simple Play (starts the game, then the launcher closes).
PART 2 (this version): smart name guess, Steam search, art / logo / description download, real Steam achievements
(cached for offline, manual ticks saved with a date), retry of missing pictures when the internet is back.
PART 3 (this version): optional hidden helper (play time / reopen launcher), gamepad (gamepad.py), packaging.
Methods that belong to a later part raise NotYet; the interface shows the message as a toast.
Methods that use the network block, so the interface calls them through worker.run_async.
"""
import os
import shutil
import subprocess
import threading
import time
import uuid

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import QApplication

from . import paths, steam, tracker
from .store import DB_LOCK, find_game, load_db, mutate, save_db
from .trophies import GAME_DEFS, GLOBAL_DEFS, eval_defs, sync_trophies

DEVNULL = subprocess.DEVNULL
DETACH = (0x00000008 | 0x00000200 | 0x08000000) if paths.IS_WIN else 0


class NotYet(Exception):
    """A feature that is planned for a later part."""


def _art(name):
    if not name:
        return ""
    p = os.path.join(paths.ART_DIR, os.path.basename(name))
    return p if os.path.isfile(p) else ""


def public(g):
    """A game as the interface sees it (adds ready-to-use file paths and trophy counts)."""
    d = dict(g)
    d["hero_path"], d["cover_path"], d["logo_path"] = _art(g.get("hero")), _art(g.get("cover")), _art(g.get("logo"))
    d["installed"] = os.path.isfile(g.get("path", ""))
    tr = eval_defs(GAME_DEFS, g, g.get("trophies") or {}, "Unlock every trophy for this game")
    d["tro_total"] = len(tr)
    d["tro_unlocked"] = sum(1 for i in tr if i["achieved"])
    return d


def patch_game(gid, changes):
    """Saves changes on a game. Art files that get replaced are deleted from disk."""
    def fn(db):
        g = find_game(db, gid)
        for k in ("hero", "cover", "logo"):
            if k in changes and g.get(k) and g.get(k) != changes[k]:
                p = _art(g[k])
                if p:
                    try:
                        os.remove(p)
                    except OSError:
                        pass
        g.update(changes)
        return dict(g)
    return mutate(fn)


class Backend(QObject):
    new_trophies = Signal(list)

    # ------------------------------------------------------------------ reading
    def games(self):
        self.sync()
        return [public(g) for g in load_db()["games"]]

    def settings(self):
        return load_db()["settings"]

    def sync(self):
        new = sync_trophies()
        if new:
            self.new_trophies.emit(new)
        return new

    def db_mtime(self):
        try:
            return os.path.getmtime(paths.DB_FILE)
        except OSError:
            return 0.0

    # ------------------------------------------------------------------ trophies
    def launcher_trophies(self):
        db = load_db()
        items = eval_defs(GLOBAL_DEFS, db, db.get("trophies") or {}, "Unlock every launcher trophy")
        return {"items": items, "unlocked": sum(1 for i in items if i["achieved"]), "total": len(items)}

    def ach_overview(self):
        """{'launcher': [items], 'games': [{id, name, cover_path, hero_path, items}]}"""
        self.sync()
        db = load_db()
        launcher = eval_defs(GLOBAL_DEFS, db, db.get("trophies") or {}, "Unlock every launcher trophy")
        games = []
        for g in db["games"]:
            pg = public(g)
            items = eval_defs(GAME_DEFS, g, g.get("trophies") or {}, "Unlock every trophy for this game")
            games.append({"id": g["id"], "name": g.get("name", ""), "cover_path": pg["cover_path"],
                          "hero_path": pg["hero_path"], "items": items})
        return {"launcher": launcher, "games": games}

    def game_achievements(self, gid):
        """What the trophy drawer shows for one game (may use the network: call it through run_async).
        custom = the launcher's own trophies for it; items = the game's real (Steam) achievements.
        mode: 'steam' (real progress, or the last saved list when offline) | 'manual' (tick them yourself) | 'none'."""
        db = load_db()
        g = find_game(db, gid)
        custom = eval_defs(GAME_DEFS, g, g.get("trophies") or {}, "Unlock every trophy for this game")
        res = {"custom": custom, **self._steam_items(db, g)}
        return res

    def _steam_items(self, db, g):
        gid, appid = g["id"], g.get("appid")
        if not appid:
            return {"mode": "none", "items": [], "total": 0, "unlocked": 0,
                    "note": "Pick this game's Steam page first (Edit game > Steam page) to see its achievements."}
        key = db["settings"].get("steam_key", "").strip()
        sid = db["settings"].get("steam_id", "").strip()
        note = ""
        if key and sid:
            try:
                items = steam.steam_achievements(appid, key, sid)
                un = sum(1 for i in items if i["achieved"])
                patch_game(gid, {"ach_cache": items, "ach_total": len(items), "ach_unlocked": un})
                return {"mode": "steam", "items": items, "total": len(items), "unlocked": un,
                        "note": "" if items else "This game has no achievements."}
            except Exception:
                if g.get("ach_cache"):          # offline: the last list saved on this PC
                    its = g["ach_cache"]
                    return {"mode": "steam", "items": its, "total": len(its), "unlocked": g.get("ach_unlocked", 0),
                            "note": "No connection, so this is the last list saved on this PC."}
                note = ("Couldn't read your Steam progress. This works for games you own on Steam, and your "
                        "Steam profile's game details must be Public. ")
        done = g.get("ach_done") or {}
        base, fresh = None, False
        try:                                    # every achievement of the game, straight from Steam (no key needed)
            base = steam.steam_public_achievements(appid)
            if base:
                patch_game(gid, {"ach_pub": base, "ach_total": len(base)})
                fresh = True
        except Exception:
            pass
        if not base:
            base = g.get("ach_pub") or [{"id": a["name"], "name": a["name"], "desc": "", "icon": a.get("icon", ""),
                                         "achieved": False} for a in g.get("ach_highlight", [])]
        items = [dict(a, achieved=bool(done.get(a["id"]))) for a in base]
        total = len(items) or g.get("ach_total", 0)
        if items:
            note += ("All of the game's achievements. Tap one to tick it yourself, or add your Steam API key "
                     "in Settings to see your real Steam progress.")
            if not fresh:
                note = "No connection, showing the last saved list. " + note
        else:
            note += "No achievements found for this game."
        return {"mode": "manual", "items": items, "total": total,
                "unlocked": sum(1 for i in items if i["achieved"]), "note": note}

    def ach_toggle(self, gid, ach_id):
        """Ticks / unticks an achievement by hand. Saved on this PC with the date, no internet needed."""
        def fn(db):
            d = find_game(db, gid).setdefault("ach_done", {})
            if d.get(ach_id):
                d.pop(ach_id, None)
            else:
                d[ach_id] = time.time()
        mutate(fn)

    # ------------------------------------------------------------------ writing
    def toggle_fav(self, gid):
        def fn(db):
            g = find_game(db, gid)
            g["fav"] = not g.get("fav")
        mutate(fn)

    def rename(self, gid, name):
        name = (name or "").strip()
        if name:       # renamed = the user chose this name, the automatic lookup must not change it
            def fn(db):
                g = find_game(db, gid)
                if name != g.get("name"):
                    g.update({"name": name, "renamed": True})
            mutate(fn)

    def remove(self, gid):
        def fn(db):
            g = find_game(db, gid)
            for k in ("hero", "cover", "logo"):
                p = _art(g.get(k))
                if p:
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            db["games"] = [x for x in db["games"] if x.get("id") != gid]
        mutate(fn)

    def add_game(self, path, name=None, online=True, item=None, use_online_name=True):
        """Adds the game (needs internet when `online`: use run_async).
        name            the name the user typed (None = guess it from the file)
        online          False = do not look for a picture/description at all (the user will pick his own)
        item            a search result the user picked (from online_search) - used instead of guessing
        use_online_name True = take the name of the online match, False = keep `name` exactly as typed
        Offline, the game is still added (without a picture) and the background retry fills it in later.
        The returned game has an extra key `note` when something needs explaining."""
        path = os.path.abspath(path)
        if not os.path.isfile(path) or not path.lower().endswith(paths.GAME_EXTS):
            raise ValueError("Choose a game file (.exe, .lnk, .bat or .cmd).")
        for g in load_db()["games"]:
            if os.path.normcase(g.get("path", "")) == os.path.normcase(path):
                raise ValueError(g.get("name", "This game") + " is already in the launcher.")
        gid = uuid.uuid4().hex[:12]
        guess = steam.best_guess(path)
        typed = (name or "").strip()
        keep_name = bool(typed) and not use_online_name
        g = {"id": gid, "name": typed or guess, "path": path, "added": time.time(), "fav": False,
             "launches": 0, "playtime": 0, "last_played": 0, "appid": None, "desc": "", "genres": [],
             "ach_done": {}, "ach_total": 0, "ach_highlight": [], "meta_tried": time.time(),
             "auto_art": bool(online), "renamed": keep_name}
        note = ""
        if online:
            m, offline = None, False
            if item is not None:
                ch = steam.meta_for_item(gid, item)
                if ch:
                    if item.get("source", "steam") == "steam":
                        ch["appid"] = int(item["id"])
                    g.update(ch)
                    if use_online_name and not typed:
                        g["name"] = item["name"]
                else:
                    note = "Couldn't download the picture right now. It will try again by itself, or use Edit game."
                    g["meta_tried"] = 0
            else:
                m, offline = steam.find_by_name(typed) if (typed and typed != guess) else steam.find_steam_match(path)
                if offline:
                    note = "No internet, so the game was added without a picture. It looks again by itself when you are online."
                    g["meta_tried"] = 0
                elif m:
                    if use_online_name and not g["renamed"]:
                        g["name"] = m["name"]
                    g.update(steam.fetch_meta(gid, m["id"]))
                else:
                    note = "Couldn't find a picture for this game online. Open Edit game to search by name or pick your own image."

        def fn(db):
            for x in db["games"]:                       # added twice while we were searching?
                if os.path.normcase(x.get("path", "")) == os.path.normcase(path):
                    raise ValueError(x.get("name", "This game") + " is already in the launcher.")
            db["games"].append(g)
        mutate(fn)
        out = public(g)
        out["note"] = note
        return out

    def set_custom_art(self, gid, image_path):
        """Uses an image from the PC as the game's background."""
        if not os.path.isfile(image_path):
            raise ValueError("That file was not found.")
        os.makedirs(paths.ART_DIR, exist_ok=True)
        name = f"{gid}_custom_{int(time.time())}" + (os.path.splitext(image_path)[1].lower() or ".jpg")
        shutil.copyfile(image_path, os.path.join(paths.ART_DIR, name))

        def fn(db):
            g = find_game(db, gid)
            old = _art(g.get("hero")) if g.get("custom_hero") else ""
            g["hero"], g["custom_hero"] = name, True
            if old:
                try:
                    os.remove(old)
                except OSError:
                    pass
        mutate(fn)

    def reset_art(self, gid):
        """Back to the Steam picture (needs internet: use run_async)."""
        g = find_game(load_db(), gid)
        if not g.get("appid"):
            raise ValueError("Pick a Steam page first.")
        ch = steam.fetch_meta(gid, g["appid"], False)
        if not ch.get("hero"):
            raise ValueError("Couldn't download the Steam picture. Check your internet and try again.")
        patch_game(gid, ch)

    def steam_search(self, term):
        """-> {"items": [{id, name}]} Steam only (needs internet: use run_async)."""
        term = (term or "").strip()
        if not term:
            return {"items": []}
        items = steam.steam_search(term)
        if items is None:
            raise ValueError("Can't reach Steam - check your internet connection.")
        return {"items": items}

    def online_search(self, term):
        """-> {"items": [{source: steam|gog|wiki, id, name, img}]}  Steam + GOG + Wikipedia (needs internet: use run_async)."""
        term = (term or "").strip()
        if not term:
            return {"items": []}
        items, offline = steam.online_search(term)
        if offline:
            raise ValueError("Can't reach the internet - check your connection.")
        return {"items": items}

    def match_online(self, gid, item, use_name=False):
        """Links the game to a search result of any source: downloads art, logo, description (needs internet)."""
        g = find_game(load_db(), gid)
        ch = steam.meta_for_item(gid, item, bool(g.get("custom_hero")))
        if not ch:
            raise ValueError("Couldn't download a picture from that result. Try another one or check your internet.")
        if item.get("source", "steam") == "steam":
            ch["appid"] = int(item["id"])
        if use_name and item.get("name"):
            ch["name"], ch["renamed"] = item["name"], True
        patch_game(gid, ch)

    def set_auto_art(self, gid, on):
        """On: the launcher may look for the picture/name by itself. Off: it never touches this game's picture."""
        mutate(lambda db: find_game(db, gid).update({"auto_art": bool(on)}))

    def match_steam(self, gid, appid):
        """Links the game to a Steam page and downloads art, logo, description (needs internet: use run_async)."""
        self.match_online(gid, {"source": "steam", "id": int(appid), "name": ""})

    # ------------------------------------------------------------------ background retry
    def start_meta_retry(self):
        """While the launcher is open: games without a picture get it (and the proper name) by themselves
        as soon as the internet works. The window notices the change in games.json and refreshes."""
        if getattr(self, "_retry", None):
            return
        self._stop = threading.Event()
        self._retry = threading.Thread(target=self._retry_loop, daemon=True)
        self._retry.start()

    def stop_meta_retry(self):
        if getattr(self, "_stop", None):
            self._stop.set()

    def _retry_loop(self):
        if self._stop.wait(2):
            return
        while not self._stop.is_set():
            try:
                now, todo = time.time(), []
                for g in load_db()["games"]:
                    if g.get("custom_hero") or g.get("auto_art") is False:
                        continue
                    tried = g.get("meta_tried", 0)
                    if not g.get("appid"):
                        if now - tried > (60 if not tried else 3600):      # added offline: fast; no match: hourly
                            todo.append(g)
                    elif (not g.get("hero") and not g.get("cover") or g.get("hero_v") != 3) and now - tried > 300:
                        todo.append(g)
            except Exception:
                todo = []
            for g in todo:
                if self._stop.is_set():
                    return
                try:
                    if g.get("appid"):
                        ch = steam.fetch_meta(g["id"], g["appid"])
                    else:
                        m, offline = steam.find_steam_match(g["path"], g["name"] if g.get("renamed") else None)
                        if offline:
                            break
                        ch = {"meta_tried": time.time()}
                        if m:
                            ch = steam.fetch_meta(g["id"], m["id"])
                            if not g.get("renamed"):
                                ch["name"] = m["name"]
                    patch_game(g["id"], ch)
                except Exception:
                    pass
            self._stop.wait(60)

    def set_setting(self, **kw):
        def fn(db):
            db["settings"].update(kw)
        mutate(fn)

    def set_ui(self, ui):
        def fn(db):
            db["settings"]["ui"] = dict(ui)
        mutate(fn)

    def flag(self, name):
        """Remembers that the user did something (for the 'Open the Library' style trophies)."""
        def fn(db):
            db.setdefault("flags", {})[name] = True
        if not (load_db().get("flags") or {}).get(name):
            mutate(fn)

    # ------------------------------------------------------------------ play
    def play(self, gid):
        """Counts the launch, then starts the game and closes the launcher.
        Both helper options OFF (default): the launcher starts the game itself and closes - nothing stays running.
        "Count play time" and/or "Open the launcher again" ON: the launcher starts a tiny hidden helper
        (see tracker.py) that starts the game, waits for it to close, then does what was chosen."""
        db = load_db()
        g = find_game(db, gid)
        path = g["path"]
        if not os.path.isfile(path):
            raise ValueError("The game file is missing: " + path)

        def count(db):
            gg = find_game(db, gid)
            gg["launches"] = gg.get("launches", 0) + 1
            gg["last_played"] = time.time()
            hr = time.localtime().tm_hour
            if 0 <= hr < 5:
                db.setdefault("flags", {})["night_owl"] = True
            if 5 <= hr < 9:
                db.setdefault("flags", {})["early_bird"] = True
        mutate(count)
        st = db["settings"]
        if st.get("track_play") or st.get("reopen_after"):
            try:
                tracker.spawn_detached(tracker.helper_command("--track", gid))
            except OSError:
                raise ValueError("Couldn't start the helper. Turn off the helper options in Settings and try again.")
        else:
            folder = os.path.dirname(path)
            try:
                if paths.IS_WIN and not path.lower().endswith(".exe"):
                    os.startfile(path)                   # shortcuts and .bat files
                else:
                    kw = dict(cwd=folder, stdin=DEVNULL, stdout=DEVNULL, stderr=DEVNULL, close_fds=True)
                    if paths.IS_WIN:
                        kw["creationflags"] = DETACH
                    else:
                        kw["start_new_session"] = True
                    subprocess.Popen([path], **kw)
            except OSError:
                if not paths.IS_WIN:
                    raise ValueError("Couldn't start the game.")
                os.startfile(path)                       # games that ask for admin rights
        QTimer.singleShot(900, QApplication.quit)        # nothing of the launcher window stays running
