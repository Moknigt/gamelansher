"""Shared building blocks: panels, buttons, nav bars, bars/rings, trophy badges, overlays."""
import math
import os

from PySide6.QtCore import (QEasingCurve, QPoint, QPointF, QPropertyAnimation, QRect, QRectF, QSize, Qt, QTimer,
                            QVariantAnimation, QObject, Signal, QAbstractAnimation)
from PySide6.QtGui import (QColor, QFont, QFontMetrics, QLinearGradient, QPainter, QPainterPath,
                           QPen, QPixmap, QRadialGradient)
from PySide6.QtWidgets import (QAbstractButton, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel,
                               QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

from .icons import PATHS, draw_icon, icon
from .theme import T, mix
from .i18n import tr as _t
from .util import TIER_COLORS, hue_color

AA = QPainter.RenderHint.Antialiasing
SMOOTH = QPainter.RenderHint.SmoothPixmapTransform
WHITE = QColor(255, 255, 255)
_W = {400: QFont.Weight.Normal, 500: QFont.Weight.Medium, 600: QFont.Weight.DemiBold,
      700: QFont.Weight.Bold, 800: QFont.Weight.ExtraBold}


def mkfont(px, weight=400, serif=False, spacing=0.0):
    f = QFont()
    f.setFamilies(["Cinzel", "Trajan Pro", "Georgia", "Times New Roman"] if serif
                  else ["Segoe UI", "Roboto", "Helvetica Neue", "Arial"])
    f.setPixelSize(int(px))
    f.setWeight(_W.get(weight, QFont.Weight.Normal))
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return f


def white(a=255):
    return QColor(255, 255, 255, a)


def label(text="", px=14, weight=400, color="#ffffff", wrap=False, serif=False, alpha=1.0, parent=None):
    lb = QLabel(_t(text), parent)
    lb.setFont(mkfont(px, weight, serif))
    c = QColor(color)
    lb.setStyleSheet(f"color: rgba({c.red()},{c.green()},{c.blue()},{int(alpha * 255)}); background: transparent;")
    lb.setWordWrap(wrap)
    return lb


# ----------------------------------------------------------------------------- images
_PIX = {}


def load_pix(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        key = (path, os.path.getmtime(path))
    except OSError:
        return None
    pm = _PIX.get(key)
    if pm is None:
        pm = QPixmap(path)
        pm = pm if not pm.isNull() else False
        if len(_PIX) > 60:
            _PIX.clear()
        _PIX[key] = pm
    return pm or None


def draw_cover(p, pm, rect):
    """Draw `pm` so it fills `rect` completely (centered crop), like CSS background-size: cover."""
    p.setRenderHint(SMOOTH)
    pw, ph = pm.width(), pm.height()
    sc = max(rect.width() / pw, rect.height() / ph)
    sw, sh = rect.width() / sc, rect.height() / sc
    p.drawPixmap(rect, pm, QRectF((pw - sw) / 2, (ph - sh) / 2, sw, sh))


def paint_cover(p, rect, game, radius, prefer="cover"):
    """A rounded game picture (or a colored letter tile when the game has no picture)."""
    path = QPainterPath()
    path.addRoundedRect(rect, radius, radius)
    p.save()
    p.setClipPath(path)
    order = ("cover_path", "hero_path") if prefer == "cover" else ("hero_path", "cover_path")
    pm = load_pix(game.get(order[0])) or load_pix(game.get(order[1]))
    if pm:
        draw_cover(p, pm, rect)
    else:
        g = QLinearGradient(rect.topLeft(), rect.bottomRight())
        g.setColorAt(0, hue_color(game.get("name", "?")))
        g.setColorAt(1, QColor("#0b1020"))
        p.fillRect(rect, g)
        p.setPen(WHITE)
        p.setFont(mkfont(rect.height() * 0.4, 700))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, (game.get("name") or "?").strip()[:1].upper())
    sheen = QLinearGradient(rect.topLeft(), rect.bottomRight())
    sheen.setColorAt(0, white(50))
    sheen.setColorAt(0.38, white(0))
    sheen.setColorAt(1, QColor(0, 0, 0, 55))
    p.fillRect(rect, sheen)
    p.restore()
    p.setPen(QPen(white(36), 1))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRoundedRect(rect, radius, radius)


def anim_for(on):
    return 0 if not T.anim_on else on


# ----------------------------------------------------------------------------- panels & buttons
class Panel(QWidget):
    """Rounded, tinted, glowing panel (the 'glass' look)."""

    def __init__(self, parent=None, radius=22, border=0.38):
        super().__init__(parent)
        self.radius, self.border = radius, border
        T.changed.connect(self.update)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0, T.panel_top)
        g.setColorAt(1, T.panel_bot)
        p.setBrush(g)
        p.setPen(QPen(T.ac_a(self.border), 1.5))
        p.drawRoundedRect(r, self.radius, self.radius)
        p.setPen(QPen(white(28), 1))
        p.drawLine(QPointF(r.left() + self.radius, r.top() + 1.5), QPointF(r.right() - self.radius, r.top() + 1.5))


class Btn(QAbstractButton):
    """kind: primary | ghost | danger | round | icon"""

    def __init__(self, text="", icon_name="", kind="ghost", d=46, icon_on="", parent=None):
        super().__init__(parent)
        self.icon_name, self.icon_on, self.kind, self.d = icon_name, icon_on, kind, d
        self.hover, self.active = False, False
        self.spins = icon_name == "gear"                  # the settings gear turns on hover and spins on click
        self.rot, self._turns = 0.0, 0
        self._rot_an = QVariantAnimation(self)
        self._rot_an.valueChanged.connect(self._set_rot)
        if self.spins:
            self.clicked.connect(self._spin_click)
        self.setText(_t(text))
        self.setFont(mkfont(16, 600))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        T.changed.connect(self.update)
        self.refit()

    def set_label(self, text):
        self.setText(_t(text))
        self.refit()

    def refit(self):
        self.setFixedSize(self.sizeHint())

    def sizeHint(self):
        if self.kind in ("round", "icon"):
            return QSize(self.d, self.d)
        w = QFontMetrics(self.font()).horizontalAdvance(self.text())
        iw = 27 if self.icon_name else 0
        pad = 46 if self.kind == "primary" else 26
        return QSize(w + iw + pad * 2, 48 if self.kind == "primary" else 44)

    def _set_rot(self, v):
        self.rot = float(v)
        self.update()

    def _rot_to(self, ms, curve):
        end = self._turns * 360.0 + (90.0 if self.hover else 0.0)
        self._rot_an.stop()
        if not T.anim_on:
            self.rot = end
            self.update()
            return
        self._rot_an.setDuration(T.dur(ms))
        self._rot_an.setEasingCurve(curve)
        self._rot_an.setStartValue(self.rot)
        self._rot_an.setEndValue(end)
        self._rot_an.start()

    def _spin_click(self):
        self._turns += 1
        self._rot_to(700, QEasingCurve.Type.OutCubic)

    def enterEvent(self, e):
        self.hover = True
        if self.spins:
            self._rot_to(380, QEasingCurve.Type.OutBack)
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        if self.spins:
            self._rot_to(380, QEasingCurve.Type.OutCubic)
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        if self.isDown():
            p.translate(r.center())
            p.scale(0.95, 0.95)
            p.translate(-r.center())
        k, h = self.kind, self.hover
        pen = Qt.PenStyle.NoPen
        if k == "primary":
            g = QLinearGradient(r.topLeft(), r.bottomLeft())
            g.setColorAt(0, mix(T.ac, WHITE, 0.4 if h else 0.24))
            g.setColorAt(1, mix(T.ac, WHITE, 0.12 if h else 0))
            brush = g
        elif k == "danger":
            brush = QColor(235, 70, 85, 190) if h else QColor(220, 60, 60, 102)
        elif k == "icon":
            brush = T.ac_a(0.45) if h else QColor(10, 16, 40, 128)
            pen = QPen(T.ac_a(0.8) if h else white(41), 1.5)
        else:
            brush = QColor(255, 107, 129, 72) if (k == "round" and self.active) else white(77 if h else 41)
        p.setBrush(brush)
        p.setPen(pen)
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        col = T.onac if k == "primary" else WHITE
        name = self.icon_on if (self.active and self.icon_on) else self.icon_name
        if self.active and self.icon_on:
            col = QColor("#ff8da0")
        if k in ("round", "icon"):
            isz = 22 if self.d >= 44 else 18
            if self.spins and self.rot:
                p.setRenderHint(SMOOTH)
                p.translate(r.center())
                p.rotate(self.rot)
                p.translate(-r.center())
            draw_icon(p, name, QRectF(r.center().x() - isz / 2, r.center().y() - isz / 2, isz, isz), col)
            return
        fm = QFontMetrics(self.font())
        tw = fm.horizontalAdvance(self.text())
        iw = 27 if name else 0
        x = r.center().x() - (iw + tw) / 2
        if name:
            draw_icon(p, name, QRectF(x, r.center().y() - 9, 18, 18), col)
        p.setPen(col)
        p.setFont(self.font())
        p.drawText(QRectF(x + iw, r.top(), tw + 4, r.height()), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, self.text())


class Switch(QAbstractButton):
    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setFixedSize(44, 24)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._x = 1.0 if checked else 0.0
        self._an = QVariantAnimation(self)
        T.tune(self._an, 160, "fade")
        self._an.valueChanged.connect(self._set)
        self.toggled.connect(self._go)

    def _set(self, v):
        self._x = float(v)
        self.update()

    def _go(self, on):
        self._an.stop()
        if not T.anim_on:
            self._x = 1.0 if on else 0.0
            self.update()
            return
        self._an.setStartValue(self._x)
        self._an.setEndValue(1.0 if on else 0.0)
        self._an.start()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(mix(QColor(90, 96, 120), T.ac, self._x))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        p.setBrush(WHITE)
        d = r.height() - 6
        p.drawEllipse(QRectF(r.left() + 3 + self._x * (r.width() - d - 6), r.top() + 3, d, d))


# ----------------------------------------------------------------------------- navigation (tabs + side list)
def lerp_col(a, b, t):
    """Blend two QColors including alpha (t = 0..1)."""
    t = max(0.0, min(1.0, t))
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t), int(a.alpha() + (b.alpha() - a.alpha()) * t))


class NavGroup(QWidget):
    """One painted widget for the top tabs (style 'tab') or the left options (style 'side').
    The indicator glides to the active item, hover is eased (not instant), and when the list itself
    changes (Home -> Library) the side list slides + fades in."""
    selected = Signal(str)
    add_clicked = Signal()

    def __init__(self, style="tab", parent=None):
        super().__init__(parent)
        self.style_, self.items, self.cur, self.add = style, [], None, False
        self.rects, self.hover, self.hv = [], -1, []
        self.ind = QRectF()
        self._sig = None
        self._alpha = 1.0
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._an = QVariantAnimation(self)                      # the indicator glides (duration/easing = animation style)
        T.tune(self._an, 420, "nav")
        self._an.valueChanged.connect(self._ind_to)
        self._fade = QVariantAnimation(self)
        T.tune(self._fade, 340, "fade")
        self._fade.setStartValue(0.0)
        self._fade.setEndValue(1.0)
        self._fade.valueChanged.connect(self._fade_to)
        self._ht = QTimer(self)                                 # eases the hover amount of every item
        self._ht.setInterval(15)
        self._ht.timeout.connect(self._hover_tick)
        T.changed.connect(self.update)

    def _font(self):
        return mkfont(15.5 if self.style_ == "tab" else 15, 600)

    def set_items(self, items, cur, add=False, width=190):
        """items: [(key, icon, text)]. Called on every refresh: when the list is the same as before the
        indicator glides to `cur`; when the list changed (other page) it is placed at once and the list fades in."""
        items = list(items)
        sig = (tuple(i[0] for i in items), add, width)
        same, first = sig == self._sig, self._sig is None
        self._sig = sig
        self.items, self.add = items, add
        fm = QFontMetrics(self._font())
        self.rects = []
        if self.style_ == "tab":
            x = 5.0
            for _k, _i, t in self.items:
                w = 16 + 23 + 10 + fm.horizontalAdvance(_t(t)) + 20
                self.rects.append(QRectF(x, 5, w, 42))
                x += w + 2
            self.setFixedSize(int(x + 3), 52)
        else:
            y = 0.0
            for _ in self.items:
                self.rects.append(QRectF(0, y, width, 50))
                y += 58
            if add:
                y += 2
                self.rects.append(QRectF(0, y, width, 50))
                y += 58
            self.setFixedSize(width, int(max(0, y - 8)))
        if len(self.hv) != len(self.rects):
            self.hv = [0.0] * len(self.rects)
        if same:
            self.set_current(cur)
        else:
            self.set_current(cur, instant=True)
            if not first and self.style_ == "side" and T.anim_on:
                self._fade.stop()
                self._fade.start()

    def _idx(self, key):
        for i, it in enumerate(self.items):
            if it[0] == key:
                return i
        return -1

    def set_current(self, key, instant=False):
        self.cur = key
        i = self._idx(key)
        if i < 0:
            self.ind = QRectF()
            self.update()
            return
        target = self.rects[i]
        if instant or not T.anim_on or self.ind.isNull():
            self._an.stop()
            self.ind = QRectF(target)
            self.update()
            return
        if self.ind == target:
            return
        self._an.stop()
        self._an.setStartValue(QRectF(self.ind))
        self._an.setEndValue(QRectF(target))
        self._an.start()

    def _ind_to(self, v):
        self.ind = QRectF(v)
        self.update()

    def _fade_to(self, v):
        self._alpha = float(v)
        self.update()

    def _hover_tick(self):
        busy = False
        for i in range(len(self.hv)):
            tgt = 1.0 if i == self.hover else 0.0
            d = tgt - self.hv[i]
            if abs(d) < 0.02:
                self.hv[i] = tgt
            else:
                self.hv[i] += d * T.hover_k
                busy = True
        self.update()
        if not busy:
            self._ht.stop()

    def _kick(self):
        if T.anim_on:
            if not self._ht.isActive():
                self._ht.start()
        else:
            self.hv = [1.0 if i == self.hover else 0.0 for i in range(len(self.hv))]
            self.update()

    def _hit(self, pos):
        for i, r in enumerate(self.rects):
            if r.contains(pos):
                return i
        return -1

    def mouseMoveEvent(self, e):
        h = self._hit(e.position())
        if h != self.hover:
            self.hover = h
            self._kick()

    def leaveEvent(self, e):
        self.hover = -1
        self._kick()

    def mousePressEvent(self, e):
        i = self._hit(e.position())
        if i < 0:
            return
        if i >= len(self.items):
            self.add_clicked.emit()
        else:
            self.selected.emit(self.items[i][0])

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        tab = self.style_ == "tab"
        if not tab:
            p.setOpacity(self._alpha)
            p.translate((self._alpha - 1.0) * 26, 0)
        if tab:
            c = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
            p.setBrush(QColor(8, 12, 32, 140))
            p.setPen(QPen(white(30), 1))
            p.drawRoundedRect(c, 19, 19)
        if not self.ind.isNull():
            r = self.ind
            g = QLinearGradient(r.topLeft(), r.bottomLeft())
            if tab:
                g.setColorAt(0, T.ac)
                g.setColorAt(1, T.ac_a(0.74))
                p.setPen(Qt.PenStyle.NoPen)
            else:
                g.setColorAt(0, T.ac_a(0.5))
                g.setColorAt(1, T.ac_a(0.16))
                p.setPen(QPen(T.ac2, 1.5))
            p.setBrush(g)
            p.drawRoundedRect(r.adjusted(0.8, 0.8, -0.8, -0.8), 14, 14)
        p.setFont(self._font())
        for i, r in enumerate(self.rects):
            is_add = i >= len(self.items)
            key, ic, text = ("", "plus", "Add Game") if is_add else self.items[i]
            on = key == self.cur and not is_add
            h = self.hv[i] if i < len(self.hv) else 0.0
            if tab:
                if h > 0.01 and not on:
                    p.setBrush(white(int(20 * h)))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.drawRoundedRect(r, 14, 14)
                col = T.onac if on else white(int(184 + 71 * h))
                draw_icon(p, ic, QRectF(r.left() + 16, r.center().y() - 11.5, 23, 23), col)
                p.setPen(col)
                p.drawText(QRectF(r.left() + 49, r.top(), r.width() - 49, r.height()), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, _t(text))
            else:
                dx = 0.0 if on else 3.0 * h
                rr = r.adjusted(0.8, 0.8, -0.8, -0.8).translated(dx, 0)
                if is_add:
                    p.setPen(QPen(T.ac_a(0.55 + 0.25 * h), 1.5, Qt.PenStyle.DashLine))
                    p.setBrush(T.ac_a(0.1 + 0.08 * h))
                    p.drawRoundedRect(rr, 14, 14)
                elif not on:
                    p.setPen(QPen(lerp_col(white(23), T.ac_a(0.7), h), 1.5))
                    p.setBrush(lerp_col(white(10), white(16), h))
                    p.drawRoundedRect(rr, 14, 14)
                col = WHITE if on else lerp_col(white(204), WHITE, h)
                draw_icon(p, ic, QRectF(r.left() + 14 + dx, r.center().y() - 10.5, 21, 21), col)
                p.setPen(col)
                p.drawText(QRectF(r.left() + 48 + dx, r.top(), r.width() - 56, r.height()), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, _t(text))


# ----------------------------------------------------------------------------- progress + trophies
class Bar(QWidget):
    def __init__(self, value=0.0, h=9, parent=None):
        super().__init__(parent)
        self.v = 0.0
        self.setFixedHeight(h)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._an = QVariantAnimation(self)
        T.tune(self._an, 800, "fade")
        self._an.valueChanged.connect(self._set)
        self.set_value(value)

    def _set(self, v):
        self.v = float(v)
        self.update()

    def set_value(self, v):
        v = max(0.0, min(1.0, v))
        if not T.anim_on:
            self.v = v
            self.update()
            return
        self._an.stop()
        self._an.setStartValue(self.v)
        self._an.setEndValue(v)
        self._an.start()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect())
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(white(36))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        if self.v > 0.001:
            w = max(r.height(), r.width() * self.v)
            g = QLinearGradient(r.topLeft(), r.topRight())
            g.setColorAt(0, T.ac)
            g.setColorAt(1, T.ac2)
            p.setBrush(g)
            p.drawRoundedRect(QRectF(r.left(), r.top(), w, r.height()), r.height() / 2, r.height() / 2)


class Ring(QWidget):
    def __init__(self, frac=0.0, d=84, parent=None):
        super().__init__(parent)
        self.frac = frac
        self.setFixedSize(d, d)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(5, 5, -5, -5)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(white(31), 7))
        p.drawEllipse(r)
        p.setPen(QPen(T.ac, 7, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(r, 90 * 16, int(-self.frac * 360 * 16))
        p.setPen(WHITE)
        p.setFont(mkfont(21, 700))
        p.drawText(QRectF(self.rect()), Qt.AlignmentFlag.AlignCenter, f"{int(round(self.frac * 100))}%")


def tier_pix(tier, size, locked=False):
    col = "#7b8190" if locked else TIER_COLORS.get(tier, TIER_COLORS["bronze"])[0]
    return icon("trophy_on", size, col)


class TierIcon(QWidget):
    """Small colored trophy (bronze/silver/gold/platinum)."""

    def __init__(self, tier, size=24, locked=False, parent=None):
        super().__init__(parent)
        self.pm = tier_pix(tier, size, locked)
        self.locked = locked
        self.setFixedSize(size, size)

    def paintEvent(self, _e):
        p = QPainter(self)
        if self.locked:
            p.setOpacity(0.55)
        p.drawPixmap(0, 0, self.pm)


def draw_badge(p, d, tier, ic, locked=False, ox=0.0, oy=0.0):
    """Round medal of size d at (ox, oy)."""
    main, light, dark = TIER_COLORS.get(tier, TIER_COLORS["bronze"])
    p.save()
    if locked:
        main, light, dark = "#8b909c", "#b9bdc6", "#575b66"
        p.setOpacity(p.opacity() * 0.55)
    p.translate(ox, oy)
    g = QRadialGradient(QPointF(d * 0.32, d * 0.26), d * 0.95)
    g.setColorAt(0, QColor(light))
    g.setColorAt(0.58, QColor(main))
    g.setColorAt(1, QColor(dark))
    p.setBrush(g)
    p.setPen(QPen(white(90), 2))
    p.drawEllipse(QRectF(1, 1, d - 2, d - 2))
    s = d * 0.5
    draw_icon(p, ic if ic in PATHS else "trophy", QRectF((d - s) / 2, (d - s) / 2, s, s),
              "#05324a" if tier == "plat" else "#181004")
    p.restore()


class TrophyBadge(QWidget):
    """Round medal with a symbol inside; gray when locked."""

    def __init__(self, tier="bronze", ic="trophy", locked=False, d=50, parent=None):
        super().__init__(parent)
        self.tier, self.ic, self.locked, self.d = tier, ic, locked, d
        self.setFixedSize(d, d)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        draw_badge(p, self.d, self.tier, self.ic, self.locked)


class LogoMark(QWidget):
    def __init__(self, d=46, parent=None):
        super().__init__(parent)
        self.setFixedSize(d, d)
        T.changed.connect(self.update)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, mix(T.base, T.ac, 0.35))
        g.setColorAt(1, T.ac)
        p.setBrush(g)
        p.setPen(QPen(T.ac2_a(0.7), 1.5))
        p.drawRoundedRect(r, 13, 13)
        draw_icon(p, "gamepad", QRectF(r.center().x() - 13, r.center().y() - 13, 26, 26), WHITE)


class Emblem(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(196, 196)
        T.changed.connect(self.update)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        c = QPointF(98, 98)
        g = QRadialGradient(c, 96)
        g.setColorAt(0, T.ac_a(0.55))
        g.setColorAt(1, T.ac_a(0))
        p.fillRect(self.rect(), g)
        ring = QRectF(26, 26, 144, 144)
        p.setBrush(QColor(10, 16, 40, 150))
        p.setPen(QPen(T.ac2, 2.5))
        p.drawEllipse(ring)
        draw_icon(p, "trophy_on", QRectF(58, 58, 80, 80), "#f2c14e")


class StatCard(QWidget):
    """Small glass card: icon + label on top, bold value below."""
    clicked = Signal()

    def __init__(self, ic, lab, value, clickable=False, parent=None):
        super().__init__(parent)
        self.ic, self.lab, self.value, self.clickable, self.hover = ic, lab, value, clickable, False
        if clickable:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        fm1, fm2 = QFontMetrics(mkfont(12.5, 400)), QFontMetrics(mkfont(19, 700))
        w = max(118, 20 + 22 + fm1.horizontalAdvance(lab) + 20, fm2.horizontalAdvance(value) + 40)
        self.setFixedSize(w, 66)
        T.changed.connect(self.update)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mousePressEvent(self, e):
        if self.clickable:
            self.clicked.emit()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(QColor(10, 16, 40, 158))
        p.setPen(QPen(T.ac_a(0.8 if (self.hover and self.clickable) else 0.3), 1.2))
        p.drawRoundedRect(r, 16, 16)
        draw_icon(p, self.ic, QRectF(20, 12, 15, 15), white(204))
        p.setPen(white(204))
        p.setFont(mkfont(12.5, 400))
        p.drawText(QRectF(42, 10, r.width() - 44, 19), Qt.AlignmentFlag.AlignVCenter, _t(self.lab))
        p.setPen(WHITE)
        p.setFont(mkfont(19, 700))
        p.drawText(QRectF(20, 29, r.width() - 24, 30), Qt.AlignmentFlag.AlignVCenter, _t(self.value))


def chip(text, parent=None):
    lb = QLabel(_t(text), parent)
    lb.setFont(mkfont(12.5, 400))
    lb.setStyleSheet("background: rgba(255,255,255,30); color:#fff; border-radius:13px; padding:5px 12px;")
    return lb


# ----------------------------------------------------------------------------- scrolling + fading
class SmoothScroll(QScrollArea):
    """Vertical scroll area: no bars, animated wheel scrolling, transparent."""

    def __init__(self, parent=None, horizontal=False):
        super().__init__(parent)
        self.horizontal = horizontal
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.viewport().setAutoFillBackground(False)
        self._an = QVariantAnimation(self)
        T.tune(self._an, 240, "ease")                 # no overshoot: this drives a scroll position
        self._an.valueChanged.connect(lambda v: self._bar().setValue(int(v)))
        self._target = 0

    def setWidget(self, w):
        super().setWidget(w)
        w.setAutoFillBackground(False)             # QScrollArea turns it on itself, so this must come after

    def _bar(self):
        return self.horizontalScrollBar() if self.horizontal else self.verticalScrollBar()

    def scroll_to(self, v, instant=False):
        bar = self._bar()
        v = max(0, min(bar.maximum(), int(v)))
        self._target = v
        if instant or not T.anim_on:
            self._an.stop()
            bar.setValue(v)
            return
        self._an.stop()
        self._an.setStartValue(bar.value())
        self._an.setEndValue(v)
        self._an.start()

    def wheelEvent(self, e):
        d = e.angleDelta().y() or e.angleDelta().x()
        bar = self._bar()
        base = self._target if self._an.state() == QAbstractAnimation.State.Running else bar.value()
        self.scroll_to(base - d * 0.9)
        e.accept()


class FadeSwap(QObject):
    """Fade a widget out, change its content, fade back in."""

    def __init__(self, widget):
        super().__init__(widget)
        self.eff = QGraphicsOpacityEffect(widget)
        self.eff.setOpacity(1.0)          # Qt's default is 0.7
        widget.setGraphicsEffect(self.eff)
        self.out = QPropertyAnimation(self.eff, b"opacity", self)
        T.tune(self.out, 90, "fade")
        self.out.setEndValue(0.0)
        self.inn = QPropertyAnimation(self.eff, b"opacity", self)
        T.tune(self.inn, 240, "fade")
        self.inn.setEndValue(1.0)
        self.out.finished.connect(self._mid)
        self._fn = None

    def swap(self, fn):
        if not T.anim_on:
            fn()
            self.eff.setOpacity(1.0)
            return
        self._fn = fn
        self.inn.stop()
        if self.out.state() != QAbstractAnimation.State.Running:
            self.out.setStartValue(self.eff.opacity())
            self.out.start()

    def _mid(self):
        fn, self._fn = self._fn, None
        if fn:
            fn()
        self.inn.setStartValue(0.0)
        self.inn.start()


class PageFx(QObject):
    """Plays how a page enters, following the animation style (Settings > Animations):
    fade / rise / slide / pop (rise with overshoot) / zoom. It only moves the widget and fades it, then puts it back.
    Never raises: if anything goes wrong the page is simply shown without the effect."""
    DUR = {"fade": 260, "rise": 380, "slide": 420, "pop": 460, "zoom": 420}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.w, self.eff, self._base, self._style = None, None, QRect(), "fade"
        self._curve = QEasingCurve()
        self._an = QVariantAnimation(self)
        self._an.setStartValue(0.0)
        self._an.setEndValue(1.0)
        self._an.setEasingCurve(QEasingCurve.Type.Linear)
        self._an.valueChanged.connect(self._step)
        self._an.finished.connect(self._end)

    def play(self, widget, style=None):
        self._end()
        style = style or T.page_style
        if widget is None or not T.anim_on or style not in self.DUR:
            return
        try:
            base = QRect(widget.geometry())
            if base.width() < 50 or base.height() < 50:
                return
            self.w, self._base, self._style = widget, base, style
            self._curve = T.curve("main")
            self.eff = QGraphicsOpacityEffect(widget)
            self.eff.setOpacity(0.0)
            widget.setGraphicsEffect(self.eff)
            self._an.setDuration(T.dur(self.DUR[style]))
            self._an.start()
        except Exception:
            self._end()

    def _step(self, t):
        w, eff = self.w, self.eff
        if w is None or eff is None:
            return
        try:
            t = float(t)
            k = self._curve.valueForProgress(t)
            eff.setOpacity(max(0.0, min(1.0, t * 1.6)))
            b, s = self._base, self._style
            if s == "zoom":
                i = int(min(b.width(), b.height()) * 0.035 * (1.0 - k))
                w.setGeometry(b.adjusted(i, i, -i, -i))
            elif s == "slide":
                w.setGeometry(b.translated(int(70 * (1.0 - k)), 0))
            elif s == "pop":
                w.setGeometry(b.translated(0, int(44 * (1.0 - k))))
            elif s == "rise":
                w.setGeometry(b.translated(0, int(26 * (1.0 - k))))
        except RuntimeError:                              # the page was deleted while animating
            self.w = self.eff = None

    def _end(self):
        w, self.w, self.eff = self.w, None, None
        self._an.stop()
        if w is None:
            return
        try:
            w.setGraphicsEffect(None)
            p = w.parentWidget()
            w.setGeometry(0, 0, p.width(), p.height()) if p else w.setGeometry(self._base)
        except RuntimeError:
            pass


# ----------------------------------------------------------------------------- overlays
class Toast(QLabel):
    def __init__(self, parent):
        super().__init__(parent)
        self.setFont(mkfont(14, 600))
        self.setStyleSheet("background:#ffffff; color:#0a0d16; border-radius:20px; padding:12px 22px;")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.eff = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.eff)
        self.eff.setOpacity(0)
        self.hide()
        self.an = QPropertyAnimation(self.eff, b"opacity", self)
        T.tune(self.an, 220, "fade")
        self.t = QTimer(self)
        self.t.setSingleShot(True)
        self.t.timeout.connect(self._out)
        self.an.finished.connect(lambda: self.hide() if self.eff.opacity() < 0.05 else None)

    def say(self, text, ms=3000):
        self.setText(_t(str(text)))
        self.setMaximumWidth(int(self.parent().width() * 0.8))
        self.adjustSize()
        self.move((self.parent().width() - self.width()) // 2, self.parent().height() - self.height() - 26)
        self.raise_()
        self.show()
        self.an.stop()
        self.an.setStartValue(self.eff.opacity())
        self.an.setEndValue(1.0)
        self.an.start()
        self.t.start(ms)

    def _out(self):
        self.an.stop()
        self.an.setStartValue(self.eff.opacity())
        self.an.setEndValue(0.0)
        self.an.start()


class Busy(QWidget):
    """Full-window 'please wait' layer with a spinner."""

    def __init__(self, parent):
        super().__init__(parent)
        self.msg, self.angle = "", 0
        self.hide()
        self.t = QTimer(self)
        self.t.timeout.connect(self._tick)

    def _tick(self):
        self.angle = (self.angle + 9) % 360
        self.update()

    def start(self, msg):
        self.msg = msg
        self.setGeometry(self.parent().rect())
        self.raise_()
        self.show()
        self.t.start(16)

    def stop(self):
        self.t.stop()
        self.hide()

    def mousePressEvent(self, e):
        e.accept()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.fillRect(self.rect(), QColor(4, 6, 12, 210))
        c = QPointF(self.width() / 2, self.height() / 2 - 24)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(white(51), 4))
        p.drawEllipse(c, 22, 22)
        p.setPen(QPen(T.ac2, 4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(QRectF(c.x() - 22, c.y() - 22, 44, 44), int(-self.angle * 16), 90 * 16)
        p.setPen(WHITE)
        p.setFont(mkfont(22, 600))
        p.drawText(QRectF(0, c.y() + 40, self.width(), 40), Qt.AlignmentFlag.AlignCenter, _t(self.msg))


class TrophyPop(QWidget):
    """The 'Trophy earned' banner that slides down from the top."""

    def __init__(self, parent):
        super().__init__(parent)
        from .sfx import sfx
        self.sfx = sfx
        self.queue = []
        self.busy = False
        self.title, self.sub, self.tier, self.ic = "", "", "bronze", "trophy"
        self.setFixedSize(420, 68)
        self.hide()
        self.an = QPropertyAnimation(self, b"pos", self)
        self.an.setDuration(450)
        self.an.setEasingCurve(QEasingCurve.Type.OutBack)

    def add(self, items):
        if not T.prefs.get("popups"):
            return
        self.queue.extend(items or [])
        self._run()

    def _run(self):
        if self.busy or not self.queue:
            return
        self.busy = True
        n = self.queue.pop(0)
        self.tier, self.ic = n.get("tier") or "bronze", n.get("icon") or "trophy"
        self.title = n.get("name", "")
        self.sub = n.get("sub") or ("Platinum trophy earned!" if self.tier == "plat" else
                                    ("Trophy earned · " + n["game"]) if n.get("game") else "Trophy earned")
        x = (self.parent().width() - self.width()) // 2
        self.move(x, -90)
        self.raise_()
        self.show()
        self.update()
        self.an.stop()
        self.an.setStartValue(self.pos())
        self.an.setEndValue(QPoint(x, 22))
        self.an.start()
        if T.prefs.get("popsfx"):
            self.sfx.play("pop", force=True)
        QTimer.singleShot(4300, self._leave)

    def _leave(self):
        self.an.stop()
        self.an.setStartValue(self.pos())
        self.an.setEndValue(QPoint(self.x(), -90))
        self.an.start()
        QTimer.singleShot(500, self._done)

    def _done(self):
        self.hide()
        self.busy = False
        self._run()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(QColor(14, 18, 32, 248))
        p.setPen(QPen(white(51), 1))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        draw_badge(p, 44, self.tier, self.ic, False, 14, 12)
        p.setPen(white(166))
        p.setFont(mkfont(12, 400))
        p.drawText(QRectF(72, 10, r.width() - 84, 18), Qt.AlignmentFlag.AlignVCenter, _t(self.sub))
        p.setPen(WHITE)
        p.setFont(mkfont(16, 700))
        p.drawText(QRectF(72, 30, r.width() - 84, 26), Qt.AlignmentFlag.AlignVCenter, _t(self.title))
