"""Arabic translation (no Qt in here). tr(text) returns the Arabic text when the language is Arabic, else the same text.

Everything the user reads goes through tr(): exact sentences come from AR, sentences with a name/number inside
(\"Added Hollow Knight\", \"3 games\") are handled by PREFIX / SUFFIX / PATTERNS. Text that is not known (game names,
file paths, numbers) is returned unchanged. The language is chosen in Settings and applied after a restart.
"""
import re

LANG = "en"


def set_lang(code):
    global LANG
    LANG = "ar" if code == "ar" else "en"


AR = {
    # ---- tabs / side lists / footer
    "Home": "الرئيسية", "Library": "المكتبة", "Favorites": "المفضلة", "Achievements": "الإنجازات",
    "All Games": "كل الألعاب", "Recently Played": "لُعبت مؤخراً", "Most Played": "الأكثر لعباً",
    "Installed": "المثبّتة", "Recently Added": "أُضيفت مؤخراً", "All Favorites": "كل المفضلة",
    "Stats": "الإحصائيات", "Settings": "الإعدادات", "Add Game": "إضافة لعبة", "Navigate": "تنقّل",
    "Select": "اختيار", "Back": "رجوع", "Play": "تشغيل", "Exit": "خروج", "Search": "بحث",
    "Search games": "ابحث عن لعبة", "Search ( / )": "بحث ( / )", "Welcome": "أهلاً بك",
    "Nothing here yet": "لا يوجد شيء هنا بعد", "Nothing here yet.": "لا يوجد شيء هنا بعد.",
    "No games match your search.": "لا توجد ألعاب تطابق بحثك.",
    "No favorites here yet. Select a game and press F, or use the heart button.":
        "لا توجد مفضلة بعد. اختر لعبة واضغط F أو استخدم زر القلب.",
    "Press + and choose the game's .exe file. It shows up here with its picture. The game stays where it is.":
        "اضغط + واختر ملف اللعبة (.exe). ستظهر هنا بصورتها. اللعبة تبقى في مكانها.",
    "Play, favorite or add games and they will show up in this list.":
        "العب أو أضف ألعاباً إلى المفضلة وستظهر في هذه القائمة.",
    "Play Time": "وقت اللعب", "Play time": "وقت اللعب", "Last played": "آخر مرة لُعبت", "Last Played": "آخر مرة لُعبت",
    "Recently added": "أُضيفت مؤخراً", "Times Played": "عدد مرات التشغيل", "New": "جديدة", "Played": "لُعبت",
    "Not played yet": "لم تُلعب بعد", "Never": "أبداً", "Most played": "الأكثر لعباً",
    # ---- messages / busy / toasts
    "Loading trophies…": "جاري تحميل الإنجازات…", "Searching…": "جاري البحث…", "Adding the game…": "جاري إضافة اللعبة…",
    "Searching Steam, GOG and Wikipedia…": "جاري البحث في Steam و GOG و Wikipedia…",
    "Getting the picture…": "جاري تحميل الصورة…", "Getting the Steam picture…": "جاري تحميل صورة Steam…",
    "Background changed": "تم تغيير الخلفية", "Using the Steam picture": "يتم استخدام صورة Steam",
    "Couldn't link this game.": "تعذّر ربط هذه اللعبة.", "Couldn't get the Steam picture.": "تعذّر تحميل صورة Steam.",
    "Search failed.": "فشل البحث.", "Saved": "تم الحفظ",
    "Choose the game's file": "اختر ملف اللعبة", "Choose a background image": "اختر صورة للخلفية",
    "Games (*.exe *.lnk *.bat *.cmd);;All files (*)": "ألعاب (*.exe *.lnk *.bat *.cmd);;كل الملفات (*)",
    "Images (*.png *.jpg *.jpeg *.webp *.bmp);;All files (*)": "صور (*.png *.jpg *.jpeg *.webp *.bmp);;كل الملفات (*)",
    # ---- backend messages
    "Choose a game file (.exe, .lnk, .bat or .cmd).": "اختر ملف لعبة (.exe أو .lnk أو .bat أو .cmd).",
    "That file was not found.": "لم يتم العثور على الملف.", "Pick a Steam page first.": "اختر صفحة Steam أولاً.",
    "Couldn't download the Steam picture. Check your internet and try again.":
        "تعذّر تحميل صورة Steam. تأكد من الإنترنت وحاول مرة أخرى.",
    "Can't reach Steam - check your internet connection.": "لا يمكن الوصول إلى Steam - تأكد من الإنترنت.",
    "Can't reach the internet - check your connection.": "لا يمكن الوصول إلى الإنترنت - تأكد من الاتصال.",
    "Couldn't download a picture from that result. Try another one or check your internet.":
        "تعذّر تحميل صورة من هذه النتيجة. جرّب نتيجة أخرى أو تأكد من الإنترنت.",
    "Couldn't download the picture right now. It will try again by itself, or use Edit game.":
        "تعذّر تحميل الصورة الآن. سيحاول مرة أخرى تلقائياً، أو استخدم تعديل اللعبة.",
    "No internet, so the game was added without a picture. It looks again by itself when you are online.":
        "لا يوجد إنترنت، فأُضيفت اللعبة بدون صورة. سيبحث عنها تلقائياً عند الاتصال.",
    "Couldn't find a picture for this game online. Open Edit game to search by name or pick your own image.":
        "لم نجد صورة لهذه اللعبة على الإنترنت. افتح تعديل اللعبة للبحث باسم آخر أو اختر صورتك.",
    "Couldn't start the helper. Turn off the helper options in Settings and try again.":
        "تعذّر تشغيل المساعد. أوقف خيارات المساعد من الإعدادات وحاول مرة أخرى.",
    "Couldn't start the game.": "تعذّر تشغيل اللعبة.", "This game": "هذه اللعبة",
    "Unlock every trophy for this game": "افتح كل إنجازات هذه اللعبة",
    "Unlock every launcher trophy": "افتح كل إنجازات اللانشر",
    "No achievements found for this game.": "لا توجد إنجازات لهذه اللعبة.",
    "This game has no achievements.": "هذه اللعبة ليس لها إنجازات.",
    "Pick this game's Steam page first (Edit game > Steam page) to see its achievements.":
        "اختر صفحة Steam لهذه اللعبة أولاً (تعديل اللعبة) لتظهر إنجازاتها.",
    "All of the game's achievements. Tap one to tick it yourself, or add your Steam API key in Settings to see your real Steam progress.":
        "كل إنجازات اللعبة. اضغط على أي إنجاز لتعلّمه بنفسك، أو أضف مفتاح Steam API في الإعدادات لترى تقدمك الحقيقي.",
    "Couldn't read your Steam progress. This works for games you own on Steam, and your Steam profile's game details must be Public. ":
        "تعذّر قراءة تقدمك في Steam. هذا يعمل للألعاب التي تملكها على Steam، ويجب أن تكون تفاصيل الألعاب في ملفك عامة. ",
    "No connection, showing the last saved list. ": "لا يوجد اتصال، يتم عرض آخر قائمة محفوظة. ",
    "No connection, so this is the last list saved on this PC.": "لا يوجد اتصال، هذه آخر قائمة محفوظة على هذا الجهاز.",
    # ---- dialogs
    "Add a game": "إضافة لعبة", "Add game": "إضافة اللعبة", "Edit game": "تعديل اللعبة", "Cancel": "إلغاء",
    "Choose .exe…": "اختر ملف .exe…", "Stay": "ابقَ", "Remove": "حذف", "Remove this game?": "حذف هذه اللعبة؟",
    "Close": "إغلاق", "Save": "حفظ", "Done": "تم", "Name": "الاسم", "Refresh": "تحديث",
    "Choose the game's .exe file (a shortcut, .bat or .cmd also works). The game stays where it is; the launcher only remembers where it is.":
        "اختر ملف اللعبة (.exe، ويمكن أيضاً اختصار أو .bat أو .cmd). تبقى اللعبة في مكانها، واللانشر يتذكر مكانها فقط.",
    "Next you can check the name, choose whether the picture comes from the internet, or search for it by another name.":
        "بعد ذلك يمكنك مراجعة الاسم، واختيار هل الصورة من الإنترنت، أو البحث عنها باسم آخر.",
    "The launcher will close. Your games and settings stay saved.": "سيُغلق اللانشر. ألعابك وإعداداتك تبقى محفوظة.",
    "Type the game's name as it is online": "اكتب اسم اللعبة كما هو على الإنترنت",
    "Get the picture and info from the internet": "جلب الصورة والمعلومات من الإنترنت",
    "Off: the game is added with no picture and the launcher never looks for one by itself (you can still choose your own image in Edit game).":
        "إيقاف: تُضاف اللعبة بدون صورة ولن يبحث اللانشر عن صورة تلقائياً (يمكنك اختيار صورتك من تعديل اللعبة).",
    "Use the game's name from the internet": "استخدام اسم اللعبة من الإنترنت",
    "Off: your name above stays exactly as you typed it.": "إيقاف: يبقى الاسم الذي كتبته كما هو.",
    "Optional. Searches Steam, GOG and Wikipedia - tap a result to use its picture.":
        "اختياري. يبحث في Steam و GOG و Wikipedia - اضغط على نتيجة لاستخدام صورتها.",
    "NOT THE RIGHT GAME? SEARCH BY ANOTHER NAME": "ليست اللعبة الصحيحة؟ ابحث باسم آخر",
    "Nothing found. Try another spelling or a shorter name.": "لا توجد نتائج. جرّب إملاءً آخر أو اسماً أقصر.",
    "Look for the picture and name on the internet by itself": "البحث عن الصورة والاسم على الإنترنت تلقائياً",
    "Off: the launcher never changes this game's picture or name on its own.":
        "إيقاف: لن يغيّر اللانشر صورة هذه اللعبة أو اسمها من تلقاء نفسه.",
    "Also use the found game's name": "استخدام اسم اللعبة التي وُجدت أيضاً",
    "Search online (Steam, GOG, Wikipedia, Google)": "بحث على الإنترنت (Steam و GOG و Wikipedia و Google)",
    "Choose my own background image…": "اختيار صورة خلفية خاصة بي…", "Use Steam art": "استخدام صورة Steam",
    "Remove from launcher": "حذف من اللانشر", "No online match yet": "لا يوجد ربط بالإنترنت بعد",
    "Add to favorites": "إضافة إلى المفضلة", "Remove from favorites": "إزالة من المفضلة",
    # ---- settings (popup)
    "THEME": "السمة (الألوان)", "Animations": "الحركات", "Floating particles": "الجسيمات المتطايرة",
    "Background brightness": "سطوع الخلفية", "Sound & clock": "الصوت والساعة", "Sound effects": "المؤثرات الصوتية",
    "Volume": "مستوى الصوت", "24-hour clock": "ساعة 24 ساعة", "APPEARANCE": "المظهر", "LANGUAGE": "اللغة",
    "SOUND": "الصوت", "CLOCK": "الساعة",
    "Opening the launcher again after a game, play-time counting, trophy pop-ups and the Steam key are in Achievements → Settings.":
        "إعادة فتح اللانشر بعد اللعبة، وحساب وقت اللعب، وإشعارات الإنجازات ومفتاح Steam موجودة في الإنجازات ← الإعدادات.",
    "Restart the launcher to finish switching the language.": "أعد تشغيل اللانشر لإكمال تغيير اللغة.",
    "Midnight": "منتصف الليل", "Aurora": "الشفق", "Ruby": "ياقوتي", "Violet": "بنفسجي", "Sunset": "غروب", "Mono": "رمادي",
    "Ocean": "محيط", "Emerald": "زمردي", "Rose": "وردي", "Gold": "ذهبي", "Crimson": "قرمزي", "Lime": "ليموني",
    "Teal": "فيروزي", "Sky": "سماوي", "Indigo": "نيلي", "Coffee": "قهوة",
    # ---- achievements page / settings page
    "Recent Achievements": "أحدث الإنجازات", "Game Achievements": "إنجازات الألعاب", "Trophies by tier": "الإنجازات حسب الفئة",
    "When I start a game": "عند تشغيل لعبة", "Open the launcher again when I close the game": "إعادة فتح اللانشر عند إغلاق اللعبة",
    "On: the launcher window closes while you play (so it uses no graphics or window memory) and a tiny hidden helper with no window waits in the background. When you close the game the launcher opens again by itself. Off: the launcher closes completely and stays closed.":
        "تشغيل: تُغلق نافذة اللانشر أثناء اللعب (فلا تستهلك ذاكرة الرسوميات) وينتظر مساعد صغير مخفي بدون نافذة في الخلفية. عند إغلاق اللعبة يفتح اللانشر مرة أخرى تلقائياً. إيقاف: يُغلق اللانشر تماماً ويبقى مغلقاً.",
    "Count play time": "حساب وقت اللعب",
    "Uses the same tiny hidden helper while the game is open. Needed for play-time trophies and the Stats page.":
        "يستخدم نفس المساعد الصغير المخفي أثناء فتح اللعبة. ضروري لإنجازات وقت اللعب وصفحة الإحصائيات.",
    "Trophies": "الإنجازات", "Show a pop-up when I earn a trophy": "إظهار إشعار عند الحصول على إنجاز",
    "Play a sound with the pop-up": "تشغيل صوت مع الإشعار", "Steam (optional)": "Steam (اختياري)",
    "32 characters": "32 حرفاً", "17 digits": "17 رقماً", "Save Steam details": "حفظ بيانات Steam",
    "See All  ›": "عرض الكل  ›", "Total Achievements": "إجمالي الإنجازات", "Completed": "مكتملة", "In Progress": "قيد التقدم",
    "Locked": "مقفلة",
    "Nothing unlocked yet. Add a game, start it, mark a favorite… trophies unlock as you use the launcher.":
        "لم يُفتح شيء بعد. أضف لعبة، شغّلها، أضفها للمفضلة… الإنجازات تُفتح أثناء استخدامك للانشر.",
    "Total play time": "إجمالي وقت اللعب", "Game launches": "مرات تشغيل الألعاب", "Games in library": "الألعاب في المكتبة",
    "Trophies earned": "الإنجازات المكتسبة", "Total XP": "إجمالي XP",
    "No play time yet. Turn on “Count play time” in Achievements → Settings.":
        "لا يوجد وقت لعب بعد. فعّل «حساب وقت اللعب» من الإنجازات ← الإعدادات.",
    "With both options off, nothing of the launcher keeps running while you play. With them on, only the tiny helper does.":
        "عند إيقاف الخيارين لا يبقى شيء من اللانشر يعمل أثناء اللعب. عند تشغيلهما يعمل المساعد الصغير فقط.",
    "Steam API key": "مفتاح Steam API", "Your SteamID64": "معرّف SteamID64 الخاص بك",
    "Only needed to see your real achievements for games you own on Steam. Get a free key at steamcommunity.com/dev/apikey and find your SteamID64 at steamid.io. Your Steam profile's “Game details” must be Public.":
        "ضروري فقط لرؤية إنجازاتك الحقيقية للألعاب التي تملكها على Steam. احصل على مفتاح مجاني من steamcommunity.com/dev/apikey وابحث عن SteamID64 في steamid.io. يجب أن تكون «تفاصيل الألعاب» في ملفك عامة.",
    # ---- drawer
    "Trophies you earn just by using the launcher.": "إنجازات تحصل عليها بمجرد استخدام اللانشر.",
    "Launcher trophies": "إنجازات اللانشر", "Trophies for this game": "إنجازات هذه اللعبة", "Game trophies": "إنجازات اللعبة",
    "Play-time trophies need “Count play time” turned on in Achievements → Settings.":
        "إنجازات وقت اللعب تحتاج تفعيل «حساب وقت اللعب» من الإنجازات ← الإعدادات.",
    "Steam achievements · synced": "إنجازات Steam · تمت المزامنة", "Steam achievements": "إنجازات Steam",
    # ---- trophy pop-up
    "Platinum trophy earned!": "تم الحصول على إنجاز بلاتيني!", "Trophy earned": "تم الحصول على إنجاز",
    "Bronze": "برونزي", "Silver": "فضي", "Gold ": "ذهبي ", "Platinum": "بلاتيني",
    "Under a minute": "أقل من دقيقة", "just now": "الآن",
    # ---- launcher trophies
    "Welcome Aboard": "أهلاً بك معنا", "Add your first game to the library": "أضف أول لعبة إلى المكتبة",
    "Collector": "جامع الألعاب", "Have 5 games in your library": "امتلك 5 ألعاب في مكتبتك",
    "Game Vault": "خزنة الألعاب", "Have 15 games in your library": "امتلك 15 لعبة في مكتبتك",
    "Player One": "اللاعب الأول", "Start a game from the launcher": "شغّل لعبة من اللانشر",
    "Variety Pack": "تنوّع", "Start 5 different games": "شغّل 5 ألعاب مختلفة",
    "Close to My Heart": "قريبة من قلبي", "Mark a game as a favorite": "أضف لعبة إلى المفضلة",
    "Interior Designer": "مصمم ديكور", "Set your own background image for a game": "اختر صورة خلفية خاصة بلعبة",
    "Connected": "متصل", "Add your Steam key and ID in Settings": "أضف مفتاح Steam ومعرّفك في الإعدادات",
    "Night Owl": "بومة الليل", "Start a game between midnight and 5 AM": "شغّل لعبة بين منتصف الليل والخامسة فجراً",
    "Explorer": "مستكشف", "Open the Library": "افتح المكتبة", "Detective": "محقق", "Search for a game": "ابحث عن لعبة",
    "Tweaker": "مُعدِّل", "Open Settings": "افتح الإعدادات", "Stylist": "مصمم", "Change the theme": "غيّر السمة",
    "Sound Check": "فحص الصوت", "Switch the sound effects on or off": "شغّل المؤثرات الصوتية أو أوقفها",
    "Keyboard Warrior": "محارب الكيبورد", "Move around with the arrow keys": "تنقّل بأسهم الكيبورد",
    "Controller Ready": "الذراع جاهز", "Use a gamepad": "استخدم ذراع ألعاب", "Curator": "المنسّق",
    "Have 3 favorite games": "امتلك 3 ألعاب مفضلة", "Early Bird": "الطائر المبكر",
    "Start a game between 5 and 9 AM": "شغّل لعبة بين الخامسة والتاسعة صباحاً",
    "Creature of Habit": "كائن العادات", "Start games 25 times in total": "شغّل الألعاب 25 مرة إجمالاً",
    "Getting Hooked": "بداية الإدمان", "Play 10 hours in total": "العب 10 ساعات إجمالاً",
    "No Days Off": "بلا إجازات", "Play 100 hours in total": "العب 100 ساعة إجمالاً",
    # ---- per-game trophies
    "First Launch": "أول تشغيل", "Start this game from the launcher": "شغّل هذه اللعبة من اللانشر",
    "Regular": "منتظم", "Start this game 10 times": "شغّل هذه اللعبة 10 مرات", "Loyal Fan": "معجب وفيّ",
    "Start this game 25 times": "شغّل هذه اللعبة 25 مرة", "Warming Up": "إحماء", "Play for 30 minutes": "العب 30 دقيقة",
    "One More Hour": "ساعة أخرى", "Play for 1 hour": "العب ساعة", "Hooked": "مدمن", "Play for 5 hours": "العب 5 ساعات",
    "Veteran": "محترف", "Play for 20 hours": "العب 20 ساعة", "Legend": "أسطورة", "Play for 50 hours": "العب 50 ساعة",
    "Favorite": "المفضلة", "Add this game to your favorites": "أضف هذه اللعبة إلى المفضلة",
    "Your Style": "ذوقك", "Set your own background image": "اختر صورة خلفية خاصة بك", "Matched": "تم الربط",
    "Link this game to its Steam page": "اربط هذه اللعبة بصفحتها على Steam",
    # ---- round 6: pictures you can tap, Google search
    "Background": "الخلفية", "Game tile": "مربع اللعبة", "Tap to change": "اضغط للتغيير", "Tap to choose": "اضغط للاختيار",
    "Tap a picture to choose your own. A picture you choose is never replaced by an online one.":
        "اضغط على صورة لتختار صورتك. الصورة التي تختارها لا يستبدلها اللانشر بصورة من الإنترنت أبداً.",
    "Tap a picture to change it. A picture you choose is never replaced by an online one.":
        "اضغط على صورة لتغييرها. الصورة التي تختارها لا يستبدلها اللانشر بصورة من الإنترنت أبداً.",
    "Use online pictures again": "استخدام صور الإنترنت من جديد",
    "NOT THE RIGHT GAME? PICK ANOTHER RESULT": "ليست اللعبة الصحيحة؟ اختر نتيجة أخرى",
    "Searching Steam, GOG, Wikipedia and Google…": "جاري البحث في Steam و GOG و Wikipedia و Google…",
    "Choose a picture for the game tile": "اختر صورة لمربع اللعبة",
    "Game picture changed": "تم تغيير صورة اللعبة", "Using the online pictures": "تم استخدام صور الإنترنت",
    "Google": "Google", "Web": "الويب", "Web image": "صورة من الويب",
    "That file is not a picture the launcher can open (use PNG, JPG, WEBP or BMP).":
        "هذا الملف ليس صورة يستطيع اللانشر فتحها (استخدم PNG أو JPG أو WEBP أو BMP).",
    "Couldn't save the picture. Check the free space on your disk.": "تعذّر حفظ الصورة. تأكد من المساحة الفارغة على القرص.",
    "Refused to save an empty games list over a library with games. Nothing was changed.":
        "تم رفض حفظ قائمة ألعاب فارغة فوق مكتبة فيها ألعاب. لم يتغير شيء.",
}

# text that starts / ends with a fixed English part and has a name or number in the rest
PREFIX = {
    "Last played ": "آخر مرة لُعبت ", "Game file: ": "ملف اللعبة: ", "Unlocked ": "فُتح ", "Sort by: ": "ترتيب حسب: ",
    "Currently matched to Steam app ": "مرتبطة حالياً بتطبيق Steam رقم ", "Trophy earned · ": "تم الحصول على إنجاز · ",
    "Added ": "تمت إضافة ", "Matched to ": "تم الربط مع ",
    "The game file is missing: ": "ملف اللعبة مفقود: ", "Selected: ": "تم اختيار: ",
}
SUFFIX = {
    " is already in the launcher.": " موجودة بالفعل في اللانشر.", " played": " لُعبت", " unlocked": " مفتوحة",
    " · tap to tick": " · اضغط للتعليم", "% of players": "% من اللاعبين",
}
PATTERNS = [
    (re.compile(r"^Starting (.*)…$"), lambda m: "جاري تشغيل %s…" % m.group(1)),
    (re.compile(r"^(\d+) Achievements?$"), lambda m: "%s إنجاز" % m.group(1)),
    (re.compile(r"^(\d+) games?$", re.I), lambda m: "%s لعبة" % m.group(1)),
    (re.compile(r"^(\d+) / (\d+) Achievements$"), lambda m: "%s / %s إنجاز" % (m.group(1), m.group(2))),
    (re.compile(r"^Search: “(.*)”$"), lambda m: "بحث: “%s”" % m.group(1)),
    (re.compile(r"^Close (.*)\?$"), lambda m: "إغلاق %s؟" % m.group(1)),
    (re.compile(r"^“(.*)” will be removed from the launcher\. The game itself is NOT deleted\.$"),
     lambda m: "ستُحذف «%s» من اللانشر. اللعبة نفسها لا تُحذف." % m.group(1)),
    (re.compile(r"^(\d+) days? ago$"), lambda m: "منذ %s يوم" % m.group(1)),
    (re.compile(r"^Selected: (.*) \((.*)\)\. It will be used for the picture\.$"),
     lambda m: "تم اختيار: %s (%s). سيُستخدم لصورة اللعبة." % (m.group(1), m.group(2))),
]
# ---- Settings screen (themes, animation styles, data & backups)
AR.update({
    "Overview": "نظرة عامة", "Themes": "السمات", "Colors of the whole launcher": "ألوان اللانشر كله",
    "How things move": "طريقة حركة الأشياء", "Display & Sound": "العرض والصوت",
    "Language, clock, brightness, sound": "اللغة والساعة والإضاءة والصوت",
    "Games & Trophies": "الألعاب والكؤوس", "What happens when you start a game": "ماذا يحدث عند تشغيل لعبة",
    "Steam": "ستيم", "Real achievements from your Steam account": "إنجازاتك الحقيقية من حساب ستيم",
    "Your data": "بياناتك", "Backups of your games list": "نسخ احتياطية لقائمة ألعابك",
    "‹  Settings": "‹  الإعدادات",
    "Pick a section. Everything is saved the moment you change it.": "اختر قسماً. كل شيء يُحفظ فور تغييره.",
    "Tap a theme to use it. The whole launcher changes color at once.": "اضغط على سمة لاستخدامها. يتغير لون اللانشر كله فوراً.",
    "Choose how the launcher moves. Hover a style to see it move; click to use it.":
        "اختر طريقة حركة اللانشر. مرّر الماوس على أي نمط لتراه يتحرك، واضغط لاستخدامه.",
    "The style changes how pages come in, how the menu highlight glides, scrolling, switches, and the background fade. “Off” turns all of it off.":
        "النمط يغيّر دخول الصفحات وانزلاق تحديد القائمة والتمرير والمفاتيح وتلاشي الخلفية. «إيقاف» يطفئ كل ذلك.",
    "Smooth": "ناعم", "Soft glide. The default.": "انزلاق هادئ. الافتراضي.",
    "Snappy": "سريع", "Fast and crisp, no waiting.": "سريع وحاد، بدون انتظار.",
    "Bouncy": "نطّاط", "Springy, things overshoot a little.": "مرن، الأشياء تتجاوز مكانها قليلاً ثم ترجع.",
    "Slide": "انزلاق", "Pages slide in from the side.": "الصفحات تدخل من الجانب.",
    "Zoom": "تكبير", "Pages zoom in softly.": "الصفحات تكبر بهدوء.",
    "Dreamy": "حالم", "Slow and floaty.": "بطيء وعائم.",
    "Off": "إيقاف", "No animations at all.": "بدون أي حركات.",
    "Language": "اللغة", "Screen": "الشاشة", "Sound": "الصوت", "12-hour clock": "ساعة 12 ساعة",
    "Small lights drifting in the background.": "أضواء صغيرة تطفو في الخلفية.",
    "Pop-ups": "الإشعارات",
    "On: the launcher window closes while you play and a tiny hidden helper with no window waits in the background. When you close the game the launcher opens again by itself. Off: the launcher closes completely and stays closed.":
        "عند التفعيل: تُغلق نافذة اللانشر أثناء اللعب ويبقى مساعد صغير مخفي بدون نافذة في الخلفية. وعند إغلاق اللعبة يفتح اللانشر من جديد تلقائياً. عند الإيقاف: يُغلق اللانشر تماماً ويبقى مغلقاً.",
    "Optional. Only needed to see your real achievements for games you own on Steam.":
        "اختياري. مطلوب فقط لرؤية إنجازاتك الحقيقية للألعاب التي تملكها على ستيم.",
    "Get a free key at steamcommunity.com/dev/apikey and find your SteamID64 at steamid.io. Your Steam profile's “Game details” must be Public.":
        "احصل على مفتاح مجاني من steamcommunity.com/dev/apikey وابحث عن SteamID64 في steamid.io. ويجب أن تكون «تفاصيل الألعاب» في ملفك على ستيم عامة.",
    "Not set up": "غير مُعدّ",
    "Your games list is backed up automatically every time it changes, so an update or a crash can't wipe it.":
        "قائمة ألعابك تُنسخ احتياطياً تلقائياً كلما تغيّرت، فلا يمكن لتحديث أو عطل أن يمسحها.",
    "Backups": "النسخ الاحتياطية", "newest": "الأحدث", "Back up now": "انسخ احتياطياً الآن",
    "Restore last backup": "استرجاع آخر نسخة", "Click again to restore": "اضغط مرة أخرى للاسترجاع",
    "Open data folder": "فتح مجلد البيانات", "Backup saved": "تم حفظ النسخة",
    "Nothing to back up yet": "لا يوجد شيء للنسخ بعد",
    "No backup with games was found.": "لم يتم العثور على نسخة تحتوي على ألعاب.",
    "No backups yet. One is made the next time your library changes.": "لا توجد نسخ بعد. تُنشأ واحدة عند تغيّر مكتبتك.",
    "Restore puts back the newest backup that has games. Your current file is kept in the backups folder, never deleted.":
        "الاسترجاع يعيد أحدث نسخة فيها ألعاب. ملفك الحالي يبقى في مجلد النسخ ولا يُحذف أبداً.",
    "The games file could not be read": "تعذّرت قراءة ملف الألعاب",
})
PATTERNS.extend([
    (re.compile(r"^(\d+) themes$"), lambda m: "%s سمة" % m.group(1)),
    (re.compile(r"^(\d+) styles$"), lambda m: "%s أنماط" % m.group(1)),
    (re.compile(r"^(\d+) games$"), lambda m: "%s لعبة" % m.group(1)),
    (re.compile(r"^(\d+) backups$"), lambda m: "%s نسخة احتياطية" % m.group(1)),
    (re.compile(r"^(\d+) games · (\d+) backups$"), lambda m: "%s لعبة · %s نسخة احتياطية" % (m.group(1), m.group(2))),
    (re.compile(r"^Restored (\d+) games from the backup$"), lambda m: "تم استرجاع %s لعبة من النسخة الاحتياطية" % m.group(1)),
])
_LONG = sorted((k for k in AR if len(k) >= 25), key=len, reverse=True)


def tr(text):
    """Arabic text when the language is Arabic, otherwise the text itself."""
    if LANG != "ar" or not text or not isinstance(text, str):
        return text
    hit = AR.get(text)
    if hit:
        return hit
    for rx, fn in PATTERNS:
        m = rx.match(text)
        if m:
            return fn(m)
    for pre, ar in PREFIX.items():
        if text.startswith(pre):
            return ar + tr(text[len(pre):])
    for suf, ar in SUFFIX.items():
        if text.endswith(suf) and len(text) > len(suf):
            return tr(text[:-len(suf)]) + ar
    if any(k in text for k in _LONG):          # several sentences glued together
        for k in _LONG:
            if k in text:
                text = text.replace(k, AR[k])
    return text
