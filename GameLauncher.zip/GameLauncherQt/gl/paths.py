import os
import sys

IS_WIN = os.name == "nt"
FROZEN = bool(getattr(sys, "frozen", False))        # True when running as the PyInstaller .exe
# Same folder as the old WebView version, so your games and settings carry over.
DATA_DIR = os.environ.get("GL_DATA_DIR") or os.path.join(os.path.expanduser("~"), ".mygamelauncher")
ART_DIR = os.path.join(DATA_DIR, "art")
DB_FILE = os.path.join(DATA_DIR, "games.json")
GAME_EXTS = (".exe", ".lnk", ".bat", ".cmd")
