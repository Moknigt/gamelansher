"""Steam / online helpers (PART 2). Ported from the old GameLauncher.pyw. No Qt and no UI in here.

Everything that touches the network lives in this file. The functions are plain and blocking,
so the interface runs them in a worker thread (see worker.py).
"""
import difflib
import json
import os
import re
import time
import urllib.parse
import urllib.request

from . import paths

UA = "Mozilla/5.0 (GameLauncher)"


class Offline(Exception):
    """Steam could not be reached."""


# ----------------------------------------------------------------------------- web helpers
def http_get(url, timeout=8, binary=False):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    return data if binary else json.loads(data.decode("utf-8"))


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def steam_search(term):
    """Returns a list of {id, name}, or None when Steam can't be reached."""
    url = "https://store.steampowered.com/api/storesearch/?" + urllib.parse.urlencode(
        {"term": term, "l": "english", "cc": "us"})
    try:
        d = http_get(url)
    except Exception:
        return None
    out = []
    for i in d.get("items", []):
        if i.get("type", "app") == "app" and i.get("id"):
            out.append({"id": int(i["id"]), "name": i.get("name", "")})
    return out[:8]


def best_match(term, items):
    best, score = None, 0.0
    for it in items or []:
        r = difflib.SequenceMatcher(None, norm(term), norm(it["name"])).ratio()
        if r > score:
            best, score = it, r
    return best if best and score >= 0.6 else None


def download_first(urls, base):
    """Downloads the first URL that works into the art folder. Returns the file name or None."""
    for u in urls:
        if not u:
            continue
        try:
            data = http_get(u, timeout=10, binary=True)
        except Exception:
            continue
        if len(data) < 2000:
            continue
        ext = os.path.splitext(urllib.parse.urlparse(u).path)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".webp"):
            ext = ".jpg"
        fn = "%s_%d%s" % (base, int(time.time() * 1000) % 10**9, ext)
        os.makedirs(paths.ART_DIR, exist_ok=True)
        with open(os.path.join(paths.ART_DIR, fn), "wb") as f:
            f.write(data)
        return fn
    return None


def fetch_meta(gid, appid, keep_custom_hero=True, custom_hero=False, custom_cover=False):
    """Collects art + info for a Steam app. Returns a dict of changes for the game."""
    appid = int(appid)
    ch = {"appid": appid, "meta_tried": time.time()}
    info = {}
    try:
        d = http_get("https://store.steampowered.com/api/appdetails?appids=%d&l=english" % appid)
        node = d.get(str(appid), {})
        if node.get("success"):
            info = node.get("data", {})
    except Exception:
        pass
    if info:
        ch["desc"] = info.get("short_description", "")
        ch["genres"] = [x.get("description", "") for x in info.get("genres", [])][:3]
        ch["developer"] = ", ".join(info.get("developers", [])[:2])
        ach = info.get("achievements") or {}
        ch["ach_total"] = ach.get("total", 0)
        ch["ach_highlight"] = [{"name": a.get("name", ""), "icon": a.get("path", "")}
                               for a in ach.get("highlighted", [])]
    cdn = "https://cdn.akamai.steamstatic.com/steam/apps/%d/" % appid
    if not (custom_hero and keep_custom_hero):
        shots = [x.get("path_full", "") for x in (info.get("screenshots") or [])[:1]]
        fn = download_first([cdn + "library_hero_2x.jpg", cdn + "library_hero.jpg"] + shots +
                            [info.get("background_raw", ""), cdn + "page_bg_raw.jpg", info.get("header_image", "")],
                            gid + "_hero")      # sharp, natural-colour artwork first (not the blurred blue page background)
        if fn:
            ch["hero"] = fn
            ch["custom_hero"] = False
            ch["hero_v"] = 3
    if not custom_cover:                                         # a cover the user chose is never replaced
        fn = download_first([cdn + "library_600x900.jpg", info.get("header_image", "")], gid + "_cover")
        if fn:
            ch["cover"] = fn
    fn = download_first([cdn + "logo.png"], gid + "_logo")       # transparent game logo for the Home screen
    if fn:
        ch["logo"] = fn
    return ch


# ----------------------------------------------------------------------------- smart name guess
GENERIC = {"game", "launcher", "start", "run", "main", "play", "client", "app", "bin", "win64",
           "win32", "x64", "x86", "shipping", "binaries", "setup", "autorun"}

JUNK_RE = re.compile(r"\b(codex|skidrow|plaza|reloaded|flt|gog|fitgirl|dodi|repack|razor1911|cpy|hoodlum|tenoke|prophet|"
                     r"goldberg|steamrip|rune|elamigos|kaos|empress|darksiders|crack(?:ed)?|multi\d*|update|build|setup|"
                     r"portable|dlcs?|bonus|v?\d+(?:\.\d+)+\w*|\d{5,}|win64|win32|x64|x86|shipping|nosteam|nodrm)\b", re.I)
EDITION_RE = re.compile(r"\b(goty|game of the year|definitive|complete|deluxe|ultimate|gold|standard|remastered|"
                        r"enhanced|edition|collection|anniversary)\b", re.I)
SKIP_DIRS = GENERIC | {"games", "program files", "program files (x86)", "steamapps", "common", "windows", "downloads",
                       "desktop", "steam", "gog games", "epic games", "repacks", "install", "installed", "data",
                       "documents"}


def guess_name(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    parent = os.path.dirname(path)
    name = stem
    if stem.lower() in GENERIC or len(stem) < 4:
        p = parent
        while p and os.path.basename(p).lower() in GENERIC:
            p = os.path.dirname(p)
        name = os.path.basename(p) or stem
    name = re.sub(r"[-_.]+", " ", name)
    name = re.sub(r"\b(win64|win32|shipping|x64|x86)\b", "", name, flags=re.I)
    return re.sub(r"\s+", " ", name).strip() or stem


def clean_title(s, strip_edition=False):
    """'Elden.Ring.v1.02-CODEX' -> 'Elden Ring', 'EldenRing' -> 'Elden Ring'."""
    s = re.sub(r"\[.*?\]|\(.*?\)", " ", s)
    s = JUNK_RE.sub(" ", s)
    if not re.search(r"[\s._+-]", s.strip()):
        s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s)
    s = JUNK_RE.sub(" ", re.sub(r"[-_.+]+", " ", s))
    if strip_edition:
        s = EDITION_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def name_candidates(path):
    """Possible game names from the exe name and the folders above it, best guess first."""
    parts = [os.path.splitext(os.path.basename(path))[0]]
    p = os.path.dirname(path)
    for _ in range(3):
        b = os.path.basename(p)
        if not b:
            break
        parts.append(b)
        p = os.path.dirname(p)
    out = []
    for x in parts:
        for strip in (False, True):
            c = clean_title(x, strip)
            if len(c) >= 3 and c.lower() not in SKIP_DIRS and c not in out:
                out.append(c)
    return out[:6]


def best_guess(path):
    """The name to show before (or without) a Steam match."""
    return (name_candidates(path) or [guess_name(path)])[0]


def name_score(cand, item):
    a, b = norm(cand), norm(item)
    if not a or not b:
        return 0.0
    r = difflib.SequenceMatcher(None, a, b).ratio()
    ta, tb = set(a.split()), set(b.split())
    if (ta <= tb or tb <= ta) and min(len(a), len(b)) >= 4:      # one name contains the other
        r = max(r, 0.85 - 0.05 * abs(len(ta) - len(tb)))
    return r


def find_steam_match(path, name=None):
    """Searches Steam with every name guess (`name`, when given, is tried first). Returns (match or None, offline)."""
    best, bs, queries = None, 0.0, 0
    cands = ([name.strip()] if name and name.strip() else []) + name_candidates(path)
    for c in cands:
        words = c.split()
        for q in ([c] + ([" ".join(words[:2])] if len(words) > 3 else [])):
            if queries >= 6:
                break
            queries += 1
            items = steam_search(q)
            if items is None:
                return None, True
            for it in items:
                sc = name_score(c, it["name"])
                if sc > bs:
                    best, bs = it, sc
        if bs >= 0.9:
            break
    return (best if bs >= 0.55 else None), False


# ----------------------------------------------------------------------------- real achievements
def steam_achievements(appid, key, sid):
    """Reads the game's achievement list + the player's progress (needs the API key and SteamID64).
    Returns a list of {id, name, desc, icon, achieved}. Raises on any network / permission problem."""
    base = "https://api.steampowered.com/ISteamUserStats/"
    schema = http_get(base + "GetSchemaForGame/v2/?" + urllib.parse.urlencode(
        {"key": key, "appid": appid, "l": "english"}))
    defs = schema.get("game", {}).get("availableGameStats", {}).get("achievements", [])
    pl = http_get(base + "GetPlayerAchievements/v1/?" + urllib.parse.urlencode(
        {"key": key, "steamid": sid, "appid": appid, "l": "english"}))
    done = {a.get("apiname"): bool(a.get("achieved")) for a in pl.get("playerstats", {}).get("achievements", [])}
    items = []
    for d in defs:
        ok = done.get(d.get("name"), False)
        items.append({"id": d.get("name"), "name": d.get("displayName", d.get("name")),
                      "desc": d.get("description", ""),
                      "icon": d.get("icon") if ok else d.get("icongray") or d.get("icon"),
                      "achieved": ok})
    items.sort(key=lambda x: not x["achieved"])
    return items


# ----------------------------------------------------------------------------- all achievements, no API key
def _html(s):
    import html as _h
    return _h.unescape(re.sub(r"<[^>]+>", "", s or "")).strip()


def steam_public_achievements(appid):
    """The game's FULL achievement list from Steam's public stats page (no key / login needed).
    Returns [{id, name, desc, icon, achieved: False, rare}]. Raises on network problems."""
    req = urllib.request.Request(
        "https://steamcommunity.com/stats/%d/achievements/?l=english" % int(appid),
        headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(req, timeout=12) as r:
        page = r.read().decode("utf-8", "replace")
    return parse_achievement_page(page)


def parse_achievement_page(page):
    items = []
    for blk in re.split(r'<div class="achieveRow\b', page)[1:]:
        blk = blk.split('<div style="clear', 1)[0]
        img = re.search(r'<img[^>]+src="([^"]+)"', blk)
        name = re.search(r"<h3[^>]*>(.*?)</h3>", blk, re.S)
        desc = re.search(r"<h5[^>]*>(.*?)</h5>", blk, re.S)
        pct = re.search(r'achievePercent[^>]*>\s*([\d.,]+)\s*%', blk)
        if not name:
            continue
        n = _html(name.group(1))
        try:
            rare = float(pct.group(1).replace(",", ".")) < 10.0 if pct else False
        except ValueError:
            rare = False
        items.append({"id": n, "name": n, "desc": _html(desc.group(1)) if desc else "",
                      "icon": img.group(1) if img else "", "achieved": False, "rare": rare})
    return items


# ----------------------------------------------------------------------------- other places to search (not only Steam)
def _https(u):
    u = u or ""
    return "https:" + u if u.startswith("//") else u


def gog_search(term):
    """GOG store search (no key). Returns a list of {source, id, name, img} or None when it can't be reached."""
    url = "https://embed.gog.com/games/ajax/filtered?" + urllib.parse.urlencode(
        {"mediaType": "game", "search": term, "limit": 8})
    try:
        d = http_get(url)
    except Exception:
        return None
    out = []
    for it in d.get("products", []) or []:
        if it.get("id") and it.get("title"):
            out.append({"source": "gog", "id": int(it["id"]), "name": it["title"], "img": _https(it.get("image", ""))})
    return out[:6]


def wiki_search(term):
    """Wikipedia search for the game's page + its main picture (usually the box art). Returns a list or None."""
    url = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
        "action": "query", "format": "json", "generator": "search", "gsrsearch": term + " video game",
        "gsrlimit": 6, "prop": "pageimages", "piprop": "original", "redirects": 1})
    try:
        d = http_get(url)
    except Exception:
        return None
    pages = sorted((d.get("query", {}).get("pages", {}) or {}).values(), key=lambda x: x.get("index", 99))
    out = []
    for pg in pages:
        img = (pg.get("original") or {}).get("source", "")
        if img and pg.get("title"):
            out.append({"source": "wiki", "id": pg["title"], "name": pg["title"], "img": img})
    return out[:4]


# ----------------------------------------------------------------------------- the whole web (Google first)
WEB_SOURCES = ("google", "web", "img")          # google = Google page results, web = DuckDuckGo fallback, img = image search
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/124.0 Safari/537.36")


def http_text(url, timeout=8, limit=600_000, ua=BROWSER_UA):
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(limit).decode("utf-8", "replace")


def fetch_bytes(url, limit=4_000_000):
    """Small download for result thumbnails (None when it fails)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": BROWSER_UA})
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.read(limit)
    except Exception:
        return None


_TITLE_TAIL = re.compile(r"\s*[-|\u2013\u2014:\u00b7]\s*(wikipedia|steam|steamdb|gog(\.com)?|igdb|metacritic|ign|"
                         r"fandom|wiki|pcgamingwiki|epic games.*|official.*|buy.*|download.*|free.*|on steam|"
                         r"on pc|for pc|xbox.*|playstation.*|nintendo.*|youtube|reddit|amazon.*|g2a|instant gaming)\b.*$",
                         re.I)


_TITLE_ON = re.compile(r"\s+(on|for|at)\s+(steam|pc|gog(\.com)?|epic games store|xbox|playstation|nintendo switch|"
                       r"metacritic|igdb)\b.*$", re.I)


def clean_result_title(t):
    """'Elden Ring - Wikipedia' -> 'Elden Ring'. Keeps the original when the cleaning would leave nothing."""
    t = _html(t)
    c = t
    for _ in range(3):
        n = _TITLE_ON.sub("", _TITLE_TAIL.sub("", c)).strip(" -|:\u2013\u2014")
        if n == c:
            break
        c = n
    if len(c) > 60 and re.search(r"\s[-|\u2013\u2014]\s", c):
        c = re.split(r"\s[-|\u2013\u2014]\s", c)[0]
    return c.strip() if len(c.strip()) >= 2 else t[:60]


def _skip_host(u):
    h = urllib.parse.urlparse(u).netloc.lower()
    return (not h) or any(x in h for x in ("google.", "gstatic.", "youtube.", "facebook.", "twitter.", "x.com",
                                           "instagram.", "pinterest.", "tiktok."))


def google_search(term):
    """Google web results for '<term> video game' (best effort: Google sometimes refuses scripts).
    Returns a list of {source:'google', id:url, name, page} or None when it could not be read."""
    url = "https://www.google.com/search?" + urllib.parse.urlencode({"q": term + " video game", "hl": "en", "num": 10})
    try:
        page = http_text(url)
    except Exception:
        return None
    out, seen = [], set()
    for m in re.finditer(r'<a[^>]+href="(?:/url\?q=)?(https?://[^"&]+)[^"]*"[^>]*>\s*(?:<[^>]+>\s*)*<h3[^>]*>(.*?)</h3>',
                         page, re.S):
        u, title = urllib.parse.unquote(m.group(1)), m.group(2)
        if _skip_host(u) or u in seen:
            continue
        seen.add(u)
        out.append({"source": "google", "id": u, "page": u, "name": clean_result_title(title), "img": ""})
    return out[:6] if out else None


def ddg_search(term):
    """DuckDuckGo web results (used when Google could not be read). Same item shape as google_search."""
    try:
        page = http_text("https://html.duckduckgo.com/html/?" + urllib.parse.urlencode({"q": term + " video game"}))
    except Exception:
        return None
    out, seen = [], set()
    for m in re.finditer(r'class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        u = m.group(1)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(u).query).get("uddg")
        u = urllib.parse.unquote(q[0]) if q else u
        if not u.startswith("http") or _skip_host(u) or u in seen:
            continue
        seen.add(u)
        out.append({"source": "web", "id": u, "page": u, "name": clean_result_title(m.group(2)), "img": ""})
    return out[:6] if out else None


def image_search(term):
    """Image search (Bing's image page, no key). Returns [{source:'img', id, name, img, thumb}] or None."""
    url = "https://www.bing.com/images/async?" + urllib.parse.urlencode(
        {"q": term + " video game", "first": 0, "count": 24, "mmasync": 1, "adlt": "moderate"})
    try:
        page = http_text(url, limit=900_000)
    except Exception:
        return None
    import html as _h
    out, seen = [], set()
    for m in re.finditer(r'\sm="(\{[^"]+\})"', page):
        try:
            d = json.loads(_h.unescape(m.group(1)))
        except ValueError:
            continue
        full = d.get("murl", "")
        if not full.startswith("http") or full in seen:
            continue
        seen.add(full)
        out.append({"source": "img", "id": full, "img": full, "thumb": d.get("turl", ""),
                    "name": clean_result_title(d.get("t", "") or term), "page": d.get("purl", "")})
    return out[:8] if out else None


def og_image(page_url):
    """The main picture of a web page (its og:image / twitter:image), or ''."""
    try:
        page = http_text(page_url, timeout=8, limit=400_000)
    except Exception:
        return ""
    for pat in (r'<meta[^>]+property=["\']og:image(?::secure_url)?["\'][^>]+content=["\']([^"\']+)',
                r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']',
                r'<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\']([^"\']+)'):
        m = re.search(pat, page, re.I)
        if m:
            import html as _h
            return urllib.parse.urljoin(page_url, _h.unescape(m.group(1)))
    return ""


def image_ratio(path):
    """width / height of an image file (1.0 when it cannot be read)."""
    try:
        from PySide6.QtGui import QImageReader
        sz = QImageReader(path).size()
        return sz.width() / sz.height() if sz.width() and sz.height() else 1.0
    except Exception:
        return 1.0


def web_meta(gid, item, custom_hero=False, custom_cover=False):
    """Uses the picture of a web result: a wide picture becomes the background, a tall or square one the tile.
    Returns the changes for the game ({} when no picture could be downloaded)."""
    url = item.get("img") or og_image(item.get("page") or item.get("id", ""))
    if not url:
        return {}
    fn = download_first([url], gid + "_web")
    if not fn:
        return {}
    wide = image_ratio(os.path.join(paths.ART_DIR, fn)) >= 1.25
    ch = {"meta_tried": time.time()}
    if wide and not custom_hero:
        ch.update({"hero": fn, "custom_hero": False, "hero_v": 3})
        if not custom_cover:
            ch["cover"] = ""
    elif not wide and not custom_cover:
        ch["cover"] = fn
        if not custom_hero:
            ch.update({"hero": "", "custom_hero": False})
    else:                                           # the slot this picture would fill belongs to the user: keep it
        try:
            os.remove(os.path.join(paths.ART_DIR, fn))
        except OSError:
            pass
        return {}
    return ch


def online_search(term):
    """Searches Steam, GOG, Wikipedia, Google (web results) and web images, all at the same time.
    Returns (items, offline). Every item: {source, id, name, img, thumb?, page?}."""
    from concurrent.futures import ThreadPoolExecutor
    jobs = {"steam": steam_search, "gog": gog_search, "wiki": wiki_search, "google": google_search, "img": image_search}
    with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
        futs = {k: ex.submit(fn, term) for k, fn in jobs.items()}
        res = {k: f.result() for k, f in futs.items()}
    if res["google"] is None:                       # Google refused: use another web search instead
        res["google"] = ddg_search(term)
    if all(v is None for v in res.values()):
        return [], True
    out = [dict(i, source="steam", img="", thumb="https://cdn.akamai.steamstatic.com/steam/apps/%d/header.jpg" % i["id"])
           for i in (res["steam"] or [])[:4]]
    out += (res["gog"] or [])[:2] + (res["wiki"] or [])[:2]
    out += (res["google"] or [])[:4] + (res["img"] or [])[:6]
    return out, False


def gog_meta(gid, item, custom_hero=False, custom_cover=False):
    """Art + info for a GOG game. Returns the changes for the game (empty dict when nothing could be downloaded)."""
    ch = {"meta_tried": time.time()}
    info = {}
    try:
        info = http_get("https://api.gog.com/products/%d?expand=description" % int(item["id"]))
    except Exception:
        pass
    imgs = info.get("images") or {}
    base = _https(item.get("img", ""))
    if not custom_hero:
        fn = download_first([_https(imgs.get("background", "")), _https(imgs.get("backgroundImage", ""))], gid + "_hero")
        if fn:
            ch.update({"hero": fn, "custom_hero": False, "hero_v": 3})
    if not custom_cover:
        fn = download_first([base + "_product_card_v2_mobile_slider_639.jpg" if base else "",
                             base + ".jpg" if base else "", _https(imgs.get("logo2x", ""))], gid + "_cover")
        if fn:
            ch["cover"] = fn
    fn = download_first([_https(imgs.get("logo2x", "")), _https(imgs.get("logo", ""))], gid + "_logo")
    if fn:
        ch["logo"] = fn
    lead = _html((info.get("description") or {}).get("lead", ""))
    if lead:
        ch["desc"] = lead[:400]
    return ch if len(ch) > 1 else {}


def wiki_meta(gid, item, custom_hero=False, custom_cover=False):
    """Uses the Wikipedia picture as the game's cover (box art is portrait, so the old wide picture is cleared)."""
    if custom_cover:
        return {}
    fn = download_first([item.get("img", "")], gid + "_cover")
    if not fn:
        return {}
    ch = {"meta_tried": time.time(), "cover": fn}
    if not custom_hero:
        ch.update({"hero": "", "custom_hero": False})
    return ch


def meta_for_item(gid, item, custom_hero=False, custom_cover=False):
    """Art + info for a search result of any source. Returns a dict of changes ({} = nothing downloaded)."""
    src = item.get("source", "steam")
    if src == "gog":
        return gog_meta(gid, item, custom_hero, custom_cover)
    if src == "wiki":
        return wiki_meta(gid, item, custom_hero, custom_cover)
    if src in WEB_SOURCES:
        return web_meta(gid, item, custom_hero, custom_cover)
    ch = fetch_meta(gid, int(item["id"]), True, custom_hero, custom_cover)
    return ch if ("desc" in ch or "hero" in ch or "cover" in ch) else {}


def find_by_name(name):
    """Best Steam match for a name the user typed. Returns (match or None, offline)."""
    items = steam_search(name)
    if items is None:
        return None, True
    best, bs = None, 0.0
    for it in items:
        sc = name_score(name, it["name"])
        if sc > bs:
            best, bs = it, sc
    return (best if bs >= 0.55 else None), False
