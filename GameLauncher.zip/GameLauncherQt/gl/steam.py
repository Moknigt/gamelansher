"""Steam / online helpers (PART 2). Ported from the old GameLauncher.pyw. No Qt and no UI in here.

Everything that touches the network lives in this file. The functions are plain and blocking,
so the interface runs them in a worker thread (see worker.py).
"""
import difflib
import json
import os
import re
import time
import urllib.parse
import urllib.request

from . import paths

UA = "Mozilla/5.0 (GameLauncher)"


class Offline(Exception):
    """Steam could not be reached."""


# ----------------------------------------------------------------------------- web helpers
def http_get(url, timeout=8, binary=False):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    return data if binary else json.loads(data.decode("utf-8"))


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def steam_search(term):
    """Returns a list of {id, name}, or None when Steam can't be reached."""
    url = "https://store.steampowered.com/api/storesearch/?" + urllib.parse.urlencode(
        {"term": term, "l": "english", "cc": "us"})
    try:
        d = http_get(url)
    except Exception:
        return None
    out = []
    for i in d.get("items", []):
        if i.get("type", "app") == "app" and i.get("id"):
            out.append({"id": int(i["id"]), "name": i.get("name", "")})
    return out[:8]


def best_match(term, items):
    best, score = None, 0.0
    for it in items or []:
        r = difflib.SequenceMatcher(None, norm(term), norm(it["name"])).ratio()
        if r > score:
            best, score = it, r
    return best if best and score >= 0.6 else None


def download_first(urls, base):
    """Downloads the first URL that works into the art folder. Returns the file name or None."""
    for u in urls:
        if not u:
            continue
        try:
            data = http_get(u, timeout=10, binary=True)
        except Exception:
            continue
        if len(data) < 2000:
            continue
        ext = os.path.splitext(urllib.parse.urlparse(u).path)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".webp"):
            ext = ".jpg"
        fn = "%s_%d%s" % (base, int(time.time() * 1000) % 10**9, ext)
        os.makedirs(paths.ART_DIR, exist_ok=True)
        with open(os.path.join(paths.ART_DIR, fn), "wb") as f:
            f.write(data)
        return fn
    return None


def fetch_meta(gid, appid, keep_custom_hero=True, custom_hero=False):
    """Collects art + info for a Steam app. Returns a dict of changes for the game."""
    appid = int(appid)
    ch = {"appid": appid, "meta_tried": time.time()}
    info = {}
    try:
        d = http_get("https://store.steampowered.com/api/appdetails?appids=%d&l=english" % appid)
        node = d.get(str(appid), {})
        if node.get("success"):
            info = node.get("data", {})
    except Exception:
        pass
    if info:
        ch["desc"] = info.get("short_description", "")
        ch["genres"] = [x.get("description", "") for x in info.get("genres", [])][:3]
        ch["developer"] = ", ".join(info.get("developers", [])[:2])
        ach = info.get("achievements") or {}
        ch["ach_total"] = ach.get("total", 0)
        ch["ach_highlight"] = [{"name": a.get("name", ""), "icon": a.get("path", "")}
                               for a in ach.get("highlighted", [])]
    cdn = "https://cdn.akamai.steamstatic.com/steam/apps/%d/" % appid
    if not (custom_hero and keep_custom_hero):
        shots = [x.get("path_full", "") for x in (info.get("screenshots") or [])[:1]]
        fn = download_first([cdn + "library_hero_2x.jpg", cdn + "library_hero.jpg"] + shots +
                            [info.get("background_raw", ""), cdn + "page_bg_raw.jpg", info.get("header_image", "")],
                            gid + "_hero")      # sharp, natural-colour artwork first (not the blurred blue page background)
        if fn:
            ch["hero"] = fn
            ch["custom_hero"] = False
            ch["hero_v"] = 3
    fn = download_first([cdn + "library_600x900.jpg", info.get("header_image", "")], gid + "_cover")
    if fn:
        ch["cover"] = fn
    fn = download_first([cdn + "logo.png"], gid + "_logo")       # transparent game logo for the Home screen
    if fn:
        ch["logo"] = fn
    return ch


# ----------------------------------------------------------------------------- smart name guess
GENERIC = {"game", "launcher", "start", "run", "main", "play", "client", "app", "bin", "win64",
           "win32", "x64", "x86", "shipping", "binaries", "setup", "autorun"}

JUNK_RE = re.compile(r"\b(codex|skidrow|plaza|reloaded|flt|gog|fitgirl|dodi|repack|razor1911|cpy|hoodlum|tenoke|prophet|"
                     r"goldberg|steamrip|rune|elamigos|kaos|empress|darksiders|crack(?:ed)?|multi\d*|update|build|setup|"
                     r"portable|dlcs?|bonus|v?\d+(?:\.\d+)+\w*|\d{5,}|win64|win32|x64|x86|shipping|nosteam|nodrm)\b", re.I)
EDITION_RE = re.compile(r"\b(goty|game of the year|definitive|complete|deluxe|ultimate|gold|standard|remastered|"
                        r"enhanced|edition|collection|anniversary)\b", re.I)
SKIP_DIRS = GENERIC | {"games", "program files", "program files (x86)", "steamapps", "common", "windows", "downloads",
                       "desktop", "steam", "gog games", "epic games", "repacks", "install", "installed", "data",
                       "documents"}


def guess_name(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    parent = os.path.dirname(path)
    name = stem
    if stem.lower() in GENERIC or len(stem) < 4:
        p = parent
        while p and os.path.basename(p).lower() in GENERIC:
            p = os.path.dirname(p)
        name = os.path.basename(p) or stem
    name = re.sub(r"[-_.]+", " ", name)
    name = re.sub(r"\b(win64|win32|shipping|x64|x86)\b", "", name, flags=re.I)
    return re.sub(r"\s+", " ", name).strip() or stem


def clean_title(s, strip_edition=False):
    """'Elden.Ring.v1.02-CODEX' -> 'Elden Ring', 'EldenRing' -> 'Elden Ring'."""
    s = re.sub(r"\[.*?\]|\(.*?\)", " ", s)
    s = JUNK_RE.sub(" ", s)
    if not re.search(r"[\s._+-]", s.strip()):
        s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s)
    s = JUNK_RE.sub(" ", re.sub(r"[-_.+]+", " ", s))
    if strip_edition:
        s = EDITION_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def name_candidates(path):
    """Possible game names from the exe name and the folders above it, best guess first."""
    parts = [os.path.splitext(os.path.basename(path))[0]]
    p = os.path.dirname(path)
    for _ in range(3):
        b = os.path.basename(p)
        if not b:
            break
        parts.append(b)
        p = os.path.dirname(p)
    out = []
    for x in parts:
        for strip in (False, True):
            c = clean_title(x, strip)
            if len(c) >= 3 and c.lower() not in SKIP_DIRS and c not in out:
                out.append(c)
    return out[:6]


def best_guess(path):
    """The name to show before (or without) a Steam match."""
    return (name_candidates(path) or [guess_name(path)])[0]


def name_score(cand, item):
    a, b = norm(cand), norm(item)
    if not a or not b:
        return 0.0
    r = difflib.SequenceMatcher(None, a, b).ratio()
    ta, tb = set(a.split()), set(b.split())
    if (ta <= tb or tb <= ta) and min(len(a), len(b)) >= 4:      # one name contains the other
        r = max(r, 0.85 - 0.05 * abs(len(ta) - len(tb)))
    return r


def find_steam_match(path):
    """Searches Steam with every name guess. Returns (match or None, offline)."""
    best, bs, queries = None, 0.0, 0
    for c in name_candidates(path):
        words = c.split()
        for q in ([c] + ([" ".join(words[:2])] if len(words) > 3 else [])):
            if queries >= 6:
                break
            queries += 1
            items = steam_search(q)
            if items is None:
                return None, True
            for it in items:
                sc = name_score(c, it["name"])
                if sc > bs:
                    best, bs = it, sc
        if bs >= 0.9:
            break
    return (best if bs >= 0.55 else None), False


# ----------------------------------------------------------------------------- real achievements
def steam_achievements(appid, key, sid):
    """Reads the game's achievement list + the player's progress (needs the API key and SteamID64).
    Returns a list of {id, name, desc, icon, achieved}. Raises on any network / permission problem."""
    base = "https://api.steampowered.com/ISteamUserStats/"
    schema = http_get(base + "GetSchemaForGame/v2/?" + urllib.parse.urlencode(
        {"key": key, "appid": appid, "l": "english"}))
    defs = schema.get("game", {}).get("availableGameStats", {}).get("achievements", [])
    pl = http_get(base + "GetPlayerAchievements/v1/?" + urllib.parse.urlencode(
        {"key": key, "steamid": sid, "appid": appid, "l": "english"}))
    done = {a.get("apiname"): bool(a.get("achieved")) for a in pl.get("playerstats", {}).get("achievements", [])}
    items = []
    for d in defs:
        ok = done.get(d.get("name"), False)
        items.append({"id": d.get("name"), "name": d.get("displayName", d.get("name")),
                      "desc": d.get("description", ""),
                      "icon": d.get("icon") if ok else d.get("icongray") or d.get("icon"),
                      "achieved": ok})
    items.sort(key=lambda x: not x["achieved"])
    return items


# ----------------------------------------------------------------------------- all achievements, no API key
def _html(s):
    import html as _h
    return _h.unescape(re.sub(r"<[^>]+>", "", s or "")).strip()


def steam_public_achievements(appid):
    """The game's FULL achievement list from Steam's public stats page (no key / login needed).
    Returns [{id, name, desc, icon, achieved: False, rare}]. Raises on network problems."""
    req = urllib.request.Request(
        "https://steamcommunity.com/stats/%d/achievements/?l=english" % int(appid),
        headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(req, timeout=12) as r:
        page = r.read().decode("utf-8", "replace")
    return parse_achievement_page(page)


def parse_achievement_page(page):
    items = []
    for blk in re.split(r'<div class="achieveRow\b', page)[1:]:
        blk = blk.split('<div style="clear', 1)[0]
        img = re.search(r'<img[^>]+src="([^"]+)"', blk)
        name = re.search(r"<h3[^>]*>(.*?)</h3>", blk, re.S)
        desc = re.search(r"<h5[^>]*>(.*?)</h5>", blk, re.S)
        pct = re.search(r'achievePercent[^>]*>\s*([\d.,]+)\s*%', blk)
        if not name:
            continue
        n = _html(name.group(1))
        try:
            rare = float(pct.group(1).replace(",", ".")) < 10.0 if pct else False
        except ValueError:
            rare = False
        items.append({"id": n, "name": n, "desc": _html(desc.group(1)) if desc else "",
                      "icon": img.group(1) if img else "", "achieved": False, "rare": rare})
    return items
