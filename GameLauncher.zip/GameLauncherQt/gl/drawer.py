"""The trophy drawer: a 470 px panel that slides in from the right (launcher trophies or one game's trophies)."""
import time

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, QRectF, Qt, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QFontMetrics, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget

from .icons import draw_icon
from .theme import T, mix
from .util import TIER_NAME, fmt_prog
from .widgets import (AA, Bar, Btn, Ring, SmoothScroll, TierIcon, draw_badge, label, mkfont, white)

W = 470
APP_NAME = "Game Launcher"


class TroRow(QWidget):
    """One trophy: medal, name, description, progress bar or unlock date, and a check or tier tag."""
    clicked = Signal(str)

    def __init__(self, a, real=False, clickable=False, parent=None):
        super().__init__(parent)
        self.a, self.real, self.clickable, self.hover = a, real, clickable, False
        self.setFixedHeight(88 if (not real and not a["achieved"]) else 78)
        if clickable:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mousePressEvent(self, e):
        if self.clickable:
            self.clicked.emit(self.a["id"])

    def paintEvent(self, _e):
        a = self.a
        p = QPainter(self)
        p.setRenderHint(AA)
        done = a["achieved"]
        box = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(white(22 if (self.hover and self.clickable) else 12))
        p.setPen(QPen(white(26), 1))
        p.drawRoundedRect(box, 16, 16)
        right = box.right() - 14
        if self.real:
            ic = QRectF(14, (self.height() - 50) / 2, 50, 50)
            p.setBrush(T.ac_a(0.35) if done else white(18))
            p.setPen(QPen(T.ac2_a(0.7) if done else white(30), 1.2))
            p.drawRoundedRect(ic, 12, 12)
            draw_icon(p, "trophy_on" if done else "trophy", ic.adjusted(11, 11, -11, -11),
                      "#f2c14e" if done else white(130))
        else:
            draw_badge(p, 50, a["tier"], a["icon"], not done, 14, (self.height() - 50) / 2)
        tx = 78
        tag_w = 0
        if done:
            draw_icon(p, "check", QRectF(right - 22, self.height() / 2 - 11, 22, 22), "#6be08a")
            tag_w = 30
        elif not self.real:
            p.setFont(mkfont(12, 600))
            t = TIER_NAME[a["tier"]]
            tw = QFontMetrics(p.font()).horizontalAdvance(t) + 20
            tr = QRectF(right - tw, self.height() / 2 - 12, tw, 24)
            p.setBrush(white(24))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(tr, 12, 12)
            p.setPen(white(210))
            p.drawText(tr, Qt.AlignmentFlag.AlignCenter, t)
            tag_w = tw + 8
        avail = int(right - tx - tag_w - 6)
        p.setPen(QColor("#ffffff") if done else white(190))
        p.setFont(mkfont(15, 700))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(tx, 9, avail, 22), Qt.AlignmentFlag.AlignVCenter, fm.elidedText(a["name"], Qt.TextElideMode.ElideRight, avail))
        p.setFont(mkfont(12.5, 400))
        p.setPen(white(165))
        fm = QFontMetrics(p.font())
        desc = a.get("desc", "")
        if a.get("rare"):
            desc = (desc + " · " if desc else "") + f"{a['rare']}% of players"
        p.drawText(QRectF(tx, 32, avail, 18), Qt.AlignmentFlag.AlignVCenter, fm.elidedText(desc, Qt.TextElideMode.ElideRight, avail))
        if self.real:
            return
        if done:
            if a.get("ts"):
                p.setFont(mkfont(12, 400))
                p.setPen(white(140))
                p.drawText(QRectF(tx, 52, avail, 18), Qt.AlignmentFlag.AlignVCenter,
                           "Unlocked " + time.strftime("%d %b %Y", time.localtime(a["ts"])))
        else:
            frac = a["cur"] / a["target"] if a.get("target") else 0
            bar = QRectF(tx, 57, avail - 90, 7)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(white(36))
            p.drawRoundedRect(bar, 3.5, 3.5)
            if frac > 0:
                g = QLinearGradient(bar.topLeft(), bar.topRight())
                g.setColorAt(0, T.ac)
                g.setColorAt(1, T.ac2)
                p.setBrush(g)
                p.drawRoundedRect(QRectF(bar.left(), bar.top(), max(7, bar.width() * frac), 7), 3.5, 3.5)
            p.setFont(mkfont(11.5, 400))
            p.setPen(white(150))
            p.drawText(QRectF(bar.right() + 10, 50, 82, 20), Qt.AlignmentFlag.AlignVCenter, fmt_prog(a))


class Drawer(QWidget):
    closed = Signal()
    toggle = Signal(str)      # tick a real achievement (manual mode)
    refresh = Signal()

    def __init__(self, parent):
        super().__init__(parent)
        self.dim = 0.0
        self.hide()
        self.panel = QWidget(self)
        self.panel.setFixedWidth(W)
        self.scroll = SmoothScroll(self.panel)
        self.inner = QWidget()
        self.lay = QVBoxLayout(self.inner)
        self.lay.setContentsMargins(26, 22, 26, 30)
        self.lay.setSpacing(0)
        self.scroll.setWidget(self.inner)
        self.x_btn = Btn("", "cross", "icon", 40, parent=self.panel)
        self.x_btn.clicked.connect(self.close_)
        self._pos = QPropertyAnimation(self.panel, b"pos", self)
        self._pos.setDuration(380)
        self._pos.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._pos.finished.connect(self._after)
        self._dim = QVariantAnimation(self)
        self._dim.setDuration(380)
        self._dim.valueChanged.connect(self._set_dim)
        self._closing = False

    def is_open(self):
        return self.isVisible() and not self._closing

    def _set_dim(self, v):
        self.dim = float(v)
        self.update()

    # ------------------------------------------------------------------ show / hide
    def _layout(self):
        h = self.height()
        self.panel.setFixedHeight(h)
        self.scroll.setGeometry(0, 0, W, h)
        self.x_btn.move(W - 40 - 18, 18)
        self.x_btn.raise_()

    def resizeEvent(self, e):
        self._layout()
        if self.isVisible() and not self._closing and self._pos.state() != QPropertyAnimation.State.Running:
            self.panel.move(self.width() - W, 0)

    def open_(self):
        if self.is_open():
            return
        self.setGeometry(self.parent().rect())
        self._layout()
        self._closing = False
        self.raise_()
        self.show()
        end = QPoint(self.width() - W, 0)
        if not T.anim_on:
            self.panel.move(end)
            self.dim = 1.0
            return
        self._pos.stop()
        self._pos.setStartValue(QPoint(self.width(), 0))
        self._pos.setEndValue(end)
        self._pos.start()
        self._dim.stop()
        self._dim.setStartValue(self.dim)
        self._dim.setEndValue(1.0)
        self._dim.start()

    def close_(self):
        if not self.isVisible() or self._closing:
            return
        self._closing = True
        if not T.anim_on:
            self._after()
            return
        self._pos.stop()
        self._pos.setStartValue(self.panel.pos())
        self._pos.setEndValue(QPoint(self.width(), 0))
        self._pos.start()
        self._dim.stop()
        self._dim.setStartValue(self.dim)
        self._dim.setEndValue(0.0)
        self._dim.start()

    def _after(self):
        if self._closing:
            self._closing = False
            self.hide()
            self.dim = 0.0
            self.closed.emit()

    def mousePressEvent(self, e):
        if e.position().x() < self.panel.x():
            self.close_()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(3, 5, 12, int(150 * self.dim)))
        x = self.panel.x()
        r = QRectF(x, 0, W + 2, self.height())
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0, mix(T.base, T.ac, 0.14))
        g.setColorAt(1, mix(T.base, T.ac, 0.04))
        p.fillRect(r, g)
        p.setPen(QPen(T.ac_a(0.45), 1.5))
        p.drawLine(int(x), 0, int(x), self.height())

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.close_()

    # ------------------------------------------------------------------ content
    def _clear(self):
        while self.lay.count():
            it = self.lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
            elif it.layout():
                self._drop(it.layout())

    def _drop(self, lay):
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().setParent(None)
                it.widget().deleteLater()
            elif it.layout():
                self._drop(it.layout())

    def _head(self, title, sub, done, total, items):
        self.lay.addSpacing(44)
        row = QHBoxLayout()
        row.setSpacing(18)
        row.addWidget(Ring(done / total if total else 0, 90), 0, Qt.AlignmentFlag.AlignTop)
        col = QVBoxLayout()
        col.setSpacing(2)
        t = label(title, 22, 700, wrap=True)
        col.addWidget(t)
        col.addWidget(label(sub, 13, 400, wrap=True, alpha=0.7))
        col.addSpacing(8)
        tiers = QHBoxLayout()
        tiers.setSpacing(14)
        tc = {k: 0 for k in ("bronze", "silver", "gold", "plat")}
        for i in items:
            if i["achieved"]:
                tc[i["tier"]] += 1
        for k in ("bronze", "silver", "gold", "plat"):
            tiers.addWidget(TierIcon(k, 20))
            tiers.addWidget(label(str(tc[k]), 14, 600))
            tiers.addSpacing(2)
        tiers.addStretch(1)
        col.addLayout(tiers)
        row.addLayout(col, 1)
        self.lay.addLayout(row)

    def _section(self, text):
        self.lay.addSpacing(22)
        self.lay.addWidget(label(text.upper(), 12.5, 700, alpha=0.6))
        self.lay.addSpacing(10)

    def _note(self, text):
        self.lay.addWidget(label(text, 13.5, 400, wrap=True, alpha=0.75))
        self.lay.addSpacing(8)

    def _rows(self, items, real=False, clickable=False):
        for a in sorted(items, key=lambda a: not a["achieved"]):
            r = TroRow(a, real, clickable)
            r.clicked.connect(self.toggle)
            self.lay.addWidget(r)
            self.lay.addSpacing(8)

    def _footer(self, refresh):
        self.lay.addSpacing(14)
        row = QHBoxLayout()
        if refresh:
            b = Btn("Refresh", "", "ghost")
            b.clicked.connect(self.refresh)
            row.addWidget(b)
        b2 = Btn("Close", "", "ghost")
        b2.clicked.connect(self.close_)
        row.addWidget(b2)
        row.addStretch(1)
        self.lay.addLayout(row)
        self.lay.addStretch(1)

    def _done(self):
        self.open_()
        self.scroll.scroll_to(0, instant=True)

    def show_launcher(self, r):
        self._clear()
        items = r["items"]
        self._head(APP_NAME, "Trophies you earn just by using the launcher.", r["unlocked"], r["total"], items)
        self._section("Launcher trophies")
        self._rows(items)
        self._footer(False)
        self._done()

    def show_game(self, g, r, track_play):
        self._clear()
        cu = r.get("custom") or []
        self._head(g["name"], "Trophies for this game", sum(1 for x in cu if x["achieved"]), len(cu), cu)
        self._section("Game trophies")
        if not track_play and any(x["kind"] == "t" and not x["achieved"] for x in cu):
            self._note("Play-time trophies need “Count play time” turned on in Achievements → Settings.")
        self._rows(cu)
        items = r.get("items") or []
        if items or r.get("note"):
            mode = r.get("mode")
            self._section("Steam achievements · synced" if mode == "steam"
                          else "Steam achievements" + (" · tap to tick" if items else ""))
            if items:
                tot, un = r.get("total", 0), r.get("unlocked", 0)
                self.lay.addWidget(Bar(un / tot if tot else 0, 8))
                self.lay.addSpacing(6)
                self._note(f"{un} of {tot} unlocked")
            if r.get("note"):
                self._note(r["note"])
            self._rows(items, real=True, clickable=(mode == "manual"))
        self._footer(True)
        self._done()

    def show_error(self, title, msg):
        self._clear()
        self.lay.addSpacing(44)
        self.lay.addWidget(label(title, 22, 700, wrap=True))
        self.lay.addSpacing(10)
        self._note(msg)
        self._footer(False)
        self._done()
