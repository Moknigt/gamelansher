"""Small formatting helpers (ported from the old JS)."""
import time

from PySide6.QtGui import QColor

TIER_NAME = {"bronze": "Bronze", "silver": "Silver", "gold": "Gold", "plat": "Platinum"}
TIER_XP = {"bronze": 10, "silver": 20, "gold": 30, "plat": 100}
# (main, light, dark) colors of each trophy tier
TIER_COLORS = {
    "bronze": ("#cd7f32", "#f6c08a", "#8a5320"),
    "silver": ("#c8d0dc", "#ffffff", "#8993a3"),
    "gold": ("#f2c14e", "#fff3bd", "#b88418"),
    "plat": ("#8fe3ff", "#ffffff", "#3f9fd0"),
}


def hue_color(name):
    """Stable dark color for a game without a picture."""
    h = 0
    for c in name:
        h = (h * 31 + ord(c)) % 360
    return QColor.fromHslF(h / 360.0, 0.45, 0.32)


def fmt_long(s):
    s = int(s or 0)
    h, m = s // 3600, s % 3600 // 60
    return f"{h}h {m}m" if h else f"{m}m"


def fmt_dur(s):
    s = int(s or 0)
    h, m = s // 3600, s % 3600 // 60
    if h and m:
        return f"{h}h {m}m"
    return f"{h}h" if h else f"{m}m"


def fmt_prog(a):
    if a.get("kind") == "t":
        return f"{fmt_dur(a['cur'])} / {fmt_dur(a['target'])}"
    return f"{a['cur']} / {a['target']}"


def fmt_play(s):
    if not s:
        return "Not played yet"
    if s < 60:
        return "Under a minute"
    h, m = int(s) // 3600, int(s) % 3600 // 60
    return (f"{h}h " if h else "") + f"{m}m"


def fmt_ago(ts):
    if not ts:
        return ""
    d = time.time() - ts
    if d < 3600:
        return "just now"
    if d < 86400:
        return "today"
    n = int(d // 86400)
    return "yesterday" if n == 1 else f"{n} days ago"


def first_sentence(text):
    text = (text or "").strip()
    for i, ch in enumerate(text):
        if ch in ".!?" and i + 1 < len(text) and text[i + 1].isspace():
            return text[: i + 1]
    return text
