"""Modal host (dim layer + centered card) and the dialogs: add game, edit game, settings, exit, more menu."""
from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (QAbstractButton, QHBoxLayout, QLineEdit, QSlider, QVBoxLayout, QWidget, QGridLayout)

from .icons import draw_icon
from .theme import THEMES, T, mix
from . import i18n
from .i18n import tr as _t
from .widgets import AA, Btn, Switch, label, mkfont, white

APP_NAME = "Game Launcher"


class Card(QWidget):
    """Opaque rounded dialog card."""

    def __init__(self, width=540, parent=None):
        super().__init__(parent)
        self.setFixedWidth(width)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(30, 26, 30, 26)
        self.lay.setSpacing(0)
        if i18n.LANG == "ar":                     # dialogs read right-to-left in Arabic
            self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        T.changed.connect(self.update)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(mix(T.base, T.ac, 0.10))
        p.setPen(QPen(T.ac_a(0.5), 1.5))
        p.drawRoundedRect(r, 24, 24)

    def h2(self, text):
        self.lay.addWidget(label(text, 23, 700, wrap=True))
        self.lay.addSpacing(12)

    def text(self, t, px=14.5, alpha=0.85):
        self.lay.addWidget(label(t, px, 400, wrap=True, alpha=alpha))

    def sec(self, t):
        self.lay.addSpacing(16)
        self.lay.addWidget(label(t.upper(), 12.5, 700, alpha=0.6))
        self.lay.addSpacing(8)

    def buttons(self, *btns, left=None):
        self.lay.addSpacing(22)
        row = QHBoxLayout()
        row.setSpacing(10)
        if left is not None:
            row.addWidget(left)
        row.addStretch(1)
        for b in btns:
            row.addWidget(b)
        self.lay.addLayout(row)


class ModalHost(QWidget):
    closed = Signal()

    def __init__(self, parent):
        super().__init__(parent)
        self.card = None
        self.hide()
        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(20, 20, 20, 20)

    def is_open(self):
        return self.isVisible()

    def open_(self, card):
        self.close_(silent=True)
        self.card = card
        self.box.addWidget(card, 0, Qt.AlignmentFlag.AlignCenter)
        card.show()
        self.setGeometry(self.parent().rect())
        self.raise_()
        self.show()

    def close_(self, silent=False):
        if self.card is not None:
            self.box.removeWidget(self.card)
            self.card.setParent(None)
            self.card.deleteLater()
            self.card = None
        if self.isVisible():
            self.hide()
            if not silent:
                self.closed.emit()

    def mousePressEvent(self, e):
        if self.card is not None and not self.card.geometry().contains(e.position().toPoint()):
            self.close_()

    def paintEvent(self, _e):
        QPainter(self).fillRect(self.rect(), QColor(3, 5, 12, 175))


class OptRow(QAbstractButton):
    """A tappable row: icon + text."""

    def __init__(self, text, ic="", parent=None):
        super().__init__(parent)
        self.setText(_t(text))
        self.ic = ic
        self.hover = False
        self.setFixedHeight(48)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(T.ac_a(0.3) if self.hover else white(14))
        p.setPen(QPen(T.ac_a(0.8) if self.hover else white(26), 1.2))
        p.drawRoundedRect(r, 14, 14)
        x = 16
        if self.ic:
            draw_icon(p, self.ic, QRectF(16, r.center().y() - 10, 20, 20), "#ffffff")
            x = 48
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(15, 600))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(x, 0, r.width() - x - 10, self.height()), Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(self.text(), Qt.TextElideMode.ElideRight, int(r.width() - x - 14)))


class Swatch(QAbstractButton):
    def __init__(self, key, parent=None):
        super().__init__(parent)
        self.key = key
        self.setCheckable(True)
        self.setFixedSize(128, 44)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def paintEvent(self, _e):
        name, ac, ac2, _b, _o = THEMES[self.key]
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        p.setBrush(white(16))
        p.setPen(QPen(QColor(ac2) if self.isChecked() else white(30), 2 if self.isChecked() else 1.2))
        p.drawRoundedRect(r, 14, 14)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(ac))
        p.drawEllipse(QRectF(14, r.center().y() - 10, 20, 20))
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(13, 600))
        p.drawText(QRectF(42, 0, 84, self.height()), Qt.AlignmentFlag.AlignVCenter, _t(name))


class LangPill(QAbstractButton):
    """A checkable pill with a language name."""

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.setText(text)
        self.setCheckable(True)
        self.setFixedSize(150, 44)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        on = self.isChecked()
        p.setBrush(T.ac_a(0.35) if on else white(16))
        p.setPen(QPen(T.ac2 if on else white(30), 2 if on else 1.2))
        p.drawRoundedRect(r, 14, 14)
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(15, 600))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.text())


# ----------------------------------------------------------------------------- dialogs
def add_game_card():
    c = Card(520)
    c.h2("Add a game")
    c.text("Choose the game's .exe file (a shortcut, .bat or .cmd also works). The game stays where it is; "
           "the launcher only remembers where it is.")
    c.lay.addSpacing(10)
    c.text("Next you can check the name, choose whether the picture comes from the internet, or search for it "
           "by another name.", 13.5, 0.65)
    cancel = Btn("Cancel", "", "ghost")
    go = Btn("Choose .exe…", "plus", "primary")
    c.buttons(cancel, go)
    c.cancel, c.go = cancel, go
    return c


def confirm_exit_card():
    c = Card(480)
    c.h2(f"Close {APP_NAME}?")
    c.text("The launcher will close. Your games and settings stay saved.")
    stay = Btn("Stay", "", "ghost")
    yes = Btn("Exit", "power", "danger")
    c.buttons(stay, yes)
    c.stay, c.yes = stay, yes
    return c


def confirm_remove_card(name):
    c = Card(500)
    c.h2("Remove this game?")
    c.text(f"“{name}” will be removed from the launcher. The game itself is NOT deleted.")
    no = Btn("Cancel", "", "ghost")
    yes = Btn("Remove", "", "danger")
    c.buttons(no, yes)
    c.no, c.yes = no, yes
    return c


SRC_NAMES = {"steam": "Steam", "gog": "GOG", "wiki": "Wikipedia"}


def _switch_row(card, title, hint, on):
    row = QHBoxLayout()
    col = QVBoxLayout()
    col.setSpacing(2)
    col.addWidget(label(title, 14.5, 600, wrap=True))
    if hint:
        col.addWidget(label(hint, 12, 400, wrap=True, alpha=0.6))
    row.addLayout(col, 1)
    row.addSpacing(14)
    sw = Switch(on)
    row.addWidget(sw, 0, Qt.AlignmentFlag.AlignVCenter)
    card.lay.addLayout(row)
    card.lay.addSpacing(12)
    return sw


class ResultsMixin:
    """The search box + result list used by both the Add and the Edit card."""

    def _build_search(self, term):
        row = QHBoxLayout()
        row.setSpacing(10)
        self.e_search = QLineEdit(term)
        self.e_search.setPlaceholderText(_t("Type the game's name as it is online"))
        self.e_search.returnPressed.connect(self._find)
        row.addWidget(self.e_search, 1)
        b = Btn("Search", "search", "ghost")
        b.clicked.connect(self._find)
        row.addWidget(b)
        self.lay.addLayout(row)
        self.lay.addSpacing(8)
        self.res = QVBoxLayout()
        self.res.setSpacing(6)
        self.lay.addLayout(self.res)

    def _find(self):
        self.search.emit(self.e_search.text())

    def _clear_res(self):
        while self.res.count():
            it = self.res.takeAt(0)
            if it.widget():
                it.widget().setParent(None)
                it.widget().deleteLater()

    def say(self, text):
        self._clear_res()
        self.res.addWidget(label(text, 13.5, 400, wrap=True, alpha=0.7))

    def set_results(self, items):
        self._clear_res()
        if not items:
            self.say("Nothing found. Try another spelling or a shorter name.")
            return
        for it in items[:11]:
            o = OptRow("%s   \u00b7   %s" % (it["name"], SRC_NAMES.get(it.get("source", "steam"), "Steam")))
            o.clicked.connect(lambda _=False, i=it: self.pick.emit(i))
            self.res.addWidget(o)


class AddDetailsCard(Card, ResultsMixin):
    """Second step of Add game: name, internet picture yes/no, search by another name."""
    search = Signal(str)
    pick = Signal(object)
    add = Signal()
    cancel = Signal()

    def __init__(self, file_path, guess):
        super().__init__(580)
        self.item = None
        self.h2("Add game")
        self.lay.addWidget(label(file_path, 12, 400, wrap=True, alpha=0.55))
        self.lay.addSpacing(14)
        self.lay.addWidget(label("Name", 13, 400, alpha=0.7))
        self.lay.addSpacing(6)
        self.e_name = QLineEdit(guess)
        self.lay.addWidget(self.e_name)
        self.lay.addSpacing(16)
        self.sw_online = _switch_row(self, "Get the picture and info from the internet",
                                     "Off: the game is added with no picture and the launcher never looks for one by itself "
                                     "(you can still choose your own image in Edit game).", True)
        self.sw_name = _switch_row(self, "Use the game's name from the internet",
                                   "Off: your name above stays exactly as you typed it.", True)
        self.e_name.textEdited.connect(lambda _t: self.sw_name.setChecked(False))
        self.lay.addWidget(label("NOT THE RIGHT GAME? SEARCH BY ANOTHER NAME", 12.5, 700, alpha=0.6))
        self.lay.addSpacing(8)
        self._build_search(guess)
        self.say("Optional. Searches Steam, GOG and Wikipedia - tap a result to use its picture.")
        cancel = Btn("Cancel", "", "ghost")
        cancel.clicked.connect(self.cancel)
        go = Btn("Add game", "plus", "primary")
        go.clicked.connect(self.add)
        self.buttons(cancel, go)

    def chosen(self, item):
        """The user tapped a search result."""
        self.item = item
        self.sw_online.setChecked(True)
        self.say("Selected: %s (%s). It will be used for the picture." % (
            item["name"], SRC_NAMES.get(item.get("source", "steam"), "Steam")))
        if self.sw_name.isChecked():
            self.e_name.setText(item["name"])


class MoreCard(Card):
    fav = Signal()
    ach = Signal()
    edit = Signal()

    def __init__(self, g):
        super().__init__(440)
        self.h2(g["name"])
        for text, ic, sig in (("Remove from favorites" if g.get("fav") else "Add to favorites", "heart", self.fav),
                              ("Achievements", "trophy", self.ach), ("Edit game", "pencil", self.edit)):
            b = OptRow(text, ic)
            b.clicked.connect(sig)
            self.lay.addWidget(b)
            self.lay.addSpacing(8)


class EditCard(Card, ResultsMixin):
    save = Signal(str)
    search = Signal(str)
    pick = Signal(object)            # the chosen search result {source, id, name, img}
    image = Signal()
    steam_art = Signal()
    remove = Signal()
    dismiss = Signal()
    auto = Signal(bool)

    def __init__(self, g):
        super().__init__(580)
        self.h2("Edit game")
        self.lay.addWidget(label("Name", 13, 400, alpha=0.7))
        self.lay.addSpacing(6)
        self.e_name = QLineEdit(g["name"])
        self.lay.addWidget(self.e_name)
        self.lay.addSpacing(16)
        self.sw_auto = _switch_row(self, "Look for the picture and name on the internet by itself",
                                   "Off: the launcher never changes this game's picture or name on its own.",
                                   g.get("auto_art") is not False)
        self.sw_auto.toggled.connect(self.auto)
        self.lay.addWidget(label("Search online (Steam, GOG, Wikipedia) - gives the picture, description and achievements",
                                 13, 400, alpha=0.7, wrap=True))
        self.lay.addSpacing(6)
        self._build_search(g["name"])
        self.sw_name = _switch_row(self, "Also use the found game's name", "", False)
        self.say("Currently matched to Steam app " + str(g["appid"]) if g.get("appid") else "No online match yet")
        self.lay.addSpacing(6)
        r2 = QHBoxLayout()
        r2.setSpacing(10)
        b1 = Btn("Choose my own background image\u2026", "image", "ghost")
        b1.clicked.connect(self.image)
        b2 = Btn("Use Steam art", "", "ghost")
        b2.clicked.connect(self.steam_art)
        r2.addWidget(b1)
        r2.addWidget(b2)
        r2.addStretch(1)
        self.lay.addLayout(r2)
        self.lay.addSpacing(12)
        path = label("Game file: " + g.get("path", ""), 12, 400, wrap=True, alpha=0.55)
        self.lay.addWidget(path)
        rm = Btn("Remove from launcher", "", "danger")
        rm.clicked.connect(self.remove)
        cl = Btn("Close", "", "ghost")
        cl.clicked.connect(self.dismiss)
        sv = Btn("Save", "", "primary")
        sv.clicked.connect(lambda: self.save.emit(self.e_name.text()))
        self.buttons(cl, sv, left=rm)


class SettingsCard(Card):
    done = Signal()
    lang_changed = Signal(str)

    def __init__(self, backend, on_flag):
        super().__init__(640)
        self.be, self.flag = backend, on_flag
        self._persist = QTimer(self)
        self._persist.setSingleShot(True)
        self._persist.setInterval(350)
        self._persist.timeout.connect(lambda: self.be.set_ui(T.prefs))
        self.h2("Settings")
        # 1) colours
        self.lay.addWidget(label("THEME", 12.5, 700, alpha=0.6))
        self.lay.addSpacing(8)
        grid = QGridLayout()
        grid.setSpacing(8)
        self.sw = {}
        for i, k in enumerate(THEMES):
            s = Swatch(k)
            s.setChecked(T.prefs["theme"] == k)
            s.clicked.connect(lambda _=False, key=k: self._theme(key))
            self.sw[k] = s
            grid.addWidget(s, i // 4, i % 4)
        self.lay.addLayout(grid)
        # 2) look
        self.sec("Appearance")
        self._toggle("Animations", T.prefs["anim"] != "off", lambda v: self._set("anim", "on" if v else "off"))
        self._toggle("Floating particles", bool(T.prefs["particles"]), lambda v: self._set("particles", v))
        self._slider("Background brightness", 40, 110, T.prefs["dim"], lambda v: self._set("dim", v / 100))
        # 3) language
        self.sec("Language")
        row = QHBoxLayout()
        row.setSpacing(10)
        self.langs = {}
        for code, name in (("en", "English"), ("ar", "العربية")):
            b = LangPill(name)
            b.setChecked(T.prefs.get("lang", "en") == code)
            b.clicked.connect(lambda _=False, c=code: self._lang(c))
            self.langs[code] = b
            row.addWidget(b)
        row.addStretch(1)
        self.lay.addLayout(row)
        self.lay.addSpacing(10)
        # 4) sound + clock
        self.sec("Sound")
        self._toggle("Sound effects", bool(T.prefs["sfx"]), self._sfx)
        self._slider("Volume", 10, 100, T.prefs["vol"], lambda v: self._set("vol", v / 100))
        self.sec("Clock")
        self._toggle("24-hour clock", bool(T.prefs["clock24"]), lambda v: self._set("clock24", v))
        self.lay.addSpacing(4)
        self.text("Opening the launcher again after a game, play-time counting, trophy pop-ups and the Steam key are in Achievements → Settings.", 12.5, 0.6)
        ok = Btn("Done", "", "primary")
        ok.clicked.connect(self.done)
        self.buttons(ok)

    def _lang(self, code):
        if T.prefs.get("lang", "en") == code:
            self.langs[code].setChecked(True)
            return
        for k, b in self.langs.items():
            b.setChecked(k == code)
        self._set("lang", code)
        self.lang_changed.emit(code)

    def _toggle(self, text, on, fn):
        row = QHBoxLayout()
        row.addWidget(label(text, 15, 400), 1)
        s = Switch(on)
        s.toggled.connect(fn)
        row.addWidget(s)
        self.lay.addLayout(row)
        self.lay.addSpacing(10)

    def _slider(self, text, lo, hi, val, fn):
        row = QHBoxLayout()
        row.setSpacing(14)
        row.addWidget(label(text, 15, 400), 1)
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(lo, hi)
        s.setValue(int(round(float(val) * 100)))
        s.setFixedWidth(200)
        s.valueChanged.connect(fn)
        row.addWidget(s)
        self.lay.addLayout(row)
        self.lay.addSpacing(10)

    def _set(self, k, v):
        T.set(k, v)
        self._persist.start()

    def _theme(self, key):
        for k, s in self.sw.items():
            s.setChecked(k == key)
        self._set("theme", key)
        self.flag("theme")

    def _sfx(self, v):
        self.flag("sound")
        self._set("sfx", v)
        from .sfx import sfx
        sfx.ok()
