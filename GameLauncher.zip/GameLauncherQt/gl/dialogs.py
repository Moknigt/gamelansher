"""Modal host (dim layer + centered card) and the dialogs: add game, edit game, settings, exit, more menu."""
from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFontMetrics, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (QAbstractButton, QHBoxLayout, QLineEdit, QSlider, QVBoxLayout, QWidget, QGridLayout)

from . import steam
from .icons import draw_icon
from .theme import THEMES, T, mix
from .util import hue_color
from .worker import run_async
from . import i18n
from .i18n import tr as _t
from .widgets import AA, SMOOTH, Btn, SmoothScroll, Switch, draw_cover, label, load_pix, mkfont, white

APP_NAME = "Game Launcher"


class Card(QWidget):
    """Opaque rounded dialog card."""

    def __init__(self, width=540, parent=None):
        super().__init__(parent)
        self.setFixedWidth(width)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(30, 26, 30, 26)
        self.lay.setSpacing(0)
        if i18n.LANG == "ar":                     # dialogs read right-to-left in Arabic
            self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        T.changed.connect(self.update)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(mix(T.base, T.ac, 0.10))
        p.setPen(QPen(T.ac_a(0.5), 1.5))
        p.drawRoundedRect(r, 24, 24)

    def h2(self, text):
        self.lay.addWidget(label(text, 23, 700, wrap=True))
        self.lay.addSpacing(12)

    def text(self, t, px=14.5, alpha=0.85):
        self.lay.addWidget(label(t, px, 400, wrap=True, alpha=alpha))

    def sec(self, t):
        self.lay.addSpacing(16)
        self.lay.addWidget(label(t.upper(), 12.5, 700, alpha=0.6))
        self.lay.addSpacing(8)

    def buttons(self, *btns, left=None):
        self.lay.addSpacing(22)
        row = QHBoxLayout()
        row.setSpacing(10)
        if left is not None:
            row.addWidget(left)
        row.addStretch(1)
        for b in btns:
            row.addWidget(b)
        self.lay.addLayout(row)


class ModalHost(QWidget):
    closed = Signal()

    def __init__(self, parent):
        super().__init__(parent)
        self.card = None
        self.wrap = None
        self.hide()
        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(20, 20, 20, 20)

    def is_open(self):
        return self.isVisible()

    def open_(self, card):
        self.close_(silent=True)
        self.card = card
        self.setGeometry(self.parent().rect())
        avail = self.height() - 40
        need = max(card.sizeHint().height(), card.lay.totalHeightForWidth(card.width()))
        if need > avail > 240:                      # small screen: the card scrolls instead of being cut off
            self.wrap = SmoothScroll()
            self.wrap.setWidget(card)
            self.wrap.setFixedSize(card.width() + 2, avail)
            self.box.addWidget(self.wrap, 0, Qt.AlignmentFlag.AlignCenter)
        else:
            self.box.addWidget(card, 0, Qt.AlignmentFlag.AlignCenter)
        card.show()
        self.raise_()
        self.show()

    def close_(self, silent=False):
        if self.card is not None:
            top = self.wrap or self.card
            self.box.removeWidget(top)
            top.setParent(None)
            top.deleteLater()
            self.card = self.wrap = None
        if self.isVisible():
            self.hide()
            if not silent:
                self.closed.emit()

    def mousePressEvent(self, e):
        if self.card is not None and not (self.wrap or self.card).geometry().contains(e.position().toPoint()):
            self.close_()

    def paintEvent(self, _e):
        QPainter(self).fillRect(self.rect(), QColor(3, 5, 12, 175))


class OptRow(QAbstractButton):
    """A tappable row: icon + text."""

    def __init__(self, text, ic="", parent=None):
        super().__init__(parent)
        self.setText(_t(text))
        self.ic = ic
        self.hover = False
        self.setFixedHeight(48)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(T.ac_a(0.3) if self.hover else white(14))
        p.setPen(QPen(T.ac_a(0.8) if self.hover else white(26), 1.2))
        p.drawRoundedRect(r, 14, 14)
        x = 16
        if self.ic:
            draw_icon(p, self.ic, QRectF(16, r.center().y() - 10, 20, 20), "#ffffff")
            x = 48
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(15, 600))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(x, 0, r.width() - x - 10, self.height()), Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(self.text(), Qt.TextElideMode.ElideRight, int(r.width() - x - 14)))


class Swatch(QAbstractButton):
    def __init__(self, key, parent=None):
        super().__init__(parent)
        self.key = key
        self.setCheckable(True)
        self.setFixedSize(128, 44)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def paintEvent(self, _e):
        name, ac, ac2, _b, _o = THEMES[self.key]
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        p.setBrush(white(16))
        p.setPen(QPen(QColor(ac2) if self.isChecked() else white(30), 2 if self.isChecked() else 1.2))
        p.drawRoundedRect(r, 14, 14)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(ac))
        p.drawEllipse(QRectF(14, r.center().y() - 10, 20, 20))
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(13, 600))
        p.drawText(QRectF(42, 0, 84, self.height()), Qt.AlignmentFlag.AlignVCenter, _t(name))


class LangPill(QAbstractButton):
    """A checkable pill with a language name."""

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.setText(text)
        self.setCheckable(True)
        self.setFixedSize(150, 44)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        on = self.isChecked()
        p.setBrush(T.ac_a(0.35) if on else white(16))
        p.setPen(QPen(T.ac2 if on else white(30), 2 if on else 1.2))
        p.drawRoundedRect(r, 14, 14)
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(15, 600))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.text())


# ----------------------------------------------------------------------------- dialogs
def add_game_card():
    c = Card(520)
    c.h2("Add a game")
    c.text("Choose the game's .exe file (a shortcut, .bat or .cmd also works). The game stays where it is; "
           "the launcher only remembers where it is.")
    c.lay.addSpacing(10)
    c.text("Next you can check the name, choose whether the picture comes from the internet, or search for it "
           "by another name.", 13.5, 0.65)
    cancel = Btn("Cancel", "", "ghost")
    go = Btn("Choose .exe…", "plus", "primary")
    c.buttons(cancel, go)
    c.cancel, c.go = cancel, go
    return c


def confirm_exit_card():
    c = Card(480)
    c.h2(f"Close {APP_NAME}?")
    c.text("The launcher will close. Your games and settings stay saved.")
    stay = Btn("Stay", "", "ghost")
    yes = Btn("Exit", "power", "danger")
    c.buttons(stay, yes)
    c.stay, c.yes = stay, yes
    return c


def confirm_remove_card(name):
    c = Card(500)
    c.h2("Remove this game?")
    c.text(f"“{name}” will be removed from the launcher. The game itself is NOT deleted.")
    no = Btn("Cancel", "", "ghost")
    yes = Btn("Remove", "", "danger")
    c.buttons(no, yes)
    c.no, c.yes = no, yes
    return c


SRC_NAMES = {"steam": "Steam", "gog": "GOG", "wiki": "Wikipedia", "google": "Google", "web": "Web", "img": "Web image"}


def _switch_row(card, title, hint, on):
    row = QHBoxLayout()
    col = QVBoxLayout()
    col.setSpacing(2)
    col.addWidget(label(title, 14.5, 600, wrap=True))
    if hint:
        col.addWidget(label(hint, 12, 400, wrap=True, alpha=0.6))
    row.addLayout(col, 1)
    row.addSpacing(14)
    sw = Switch(on)
    row.addWidget(sw, 0, Qt.AlignmentFlag.AlignVCenter)
    card.lay.addLayout(row)
    card.lay.addSpacing(12)
    return sw


class ArtPicker(QAbstractButton):
    """A real picture (the game's background or its square tile). Tap it to choose another one."""

    def __init__(self, title, w, h, parent=None):
        super().__init__(parent)
        self.title, self.pm, self.hover, self.name = _t(title), None, False, "?"
        self.setFixedSize(w, h)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setMouseTracking(True)

    def set_path(self, path, name=None):
        self.pm = load_pix(path)
        self.name = name or self.name
        self.update()

    def set_pixmap(self, pm):
        self.pm = pm
        self.update()

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        clip = QPainterPath()
        clip.addRoundedRect(r, 16, 16)
        p.save()
        p.setClipPath(clip)
        if self.pm:
            draw_cover(p, self.pm, r)
        else:
            g = QLinearGradient(r.topLeft(), r.bottomRight())
            g.setColorAt(0, mix(T.base, T.ac, 0.30))
            g.setColorAt(1, QColor("#0b1020"))
            p.fillRect(r, g)
            draw_icon(p, "image", QRectF(r.center().x() - 16, r.center().y() - 24, 32, 32), white(150))
            p.setPen(white(150))
            p.setFont(mkfont(12, 600))
            p.drawText(QRectF(r.left(), r.center().y() + 14, r.width(), 20), Qt.AlignmentFlag.AlignCenter, _t("Tap to choose"))
        band = QRectF(r.left(), r.bottom() - 26, r.width(), 26)          # the name of the picture at the bottom
        p.fillRect(band, QColor(0, 0, 0, 150))
        p.setPen(white(235))
        p.setFont(mkfont(12, 700))
        p.drawText(band.adjusted(10, 0, -10, 0), Qt.AlignmentFlag.AlignVCenter, self.title)
        if self.hover:
            p.fillRect(r, QColor(0, 0, 0, 120))
            draw_icon(p, "pencil", QRectF(r.center().x() - 14, r.center().y() - 26, 28, 28), "#ffffff")
            p.setPen(QColor("#ffffff"))
            p.setFont(mkfont(13, 700))
            p.drawText(QRectF(r.left(), r.center().y() + 6, r.width(), 22), Qt.AlignmentFlag.AlignCenter, _t("Tap to change"))
        p.restore()
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(T.ac2 if self.hover else T.ac_a(0.6), 2 if self.hover else 1.5))
        p.drawRoundedRect(r, 16, 16)


_THUMBS = {}


class ResultRow(QAbstractButton):
    """One search result: small picture, name and where it was found."""
    H = 62

    def __init__(self, item, parent=None):
        super().__init__(parent)
        self.item, self.hover, self.pm, self.sel = item, False, None, False
        self.src = _t(SRC_NAMES.get(item.get("source", "steam"), "Steam"))
        self.setFixedHeight(self.H)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def set_pixmap(self, pm):
        self.pm = pm
        self.update()

    def set_selected(self, on):
        self.sel = on
        self.update()

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        on = self.hover or self.sel
        p.setBrush(T.ac_a(0.3) if on else white(14))
        p.setPen(QPen(T.ac2 if self.sel else T.ac_a(0.8) if self.hover else white(26), 2 if self.sel else 1.2))
        p.drawRoundedRect(r, 14, 14)
        if self.sel:
            draw_icon(p, "check", QRectF(r.right() - 34, r.center().y() - 11, 22, 22), "#ffffff")
        th = QRectF(r.left() + 8, r.top() + 8, 76, r.height() - 16)
        clip = QPainterPath()
        clip.addRoundedRect(th, 9, 9)
        p.save()
        p.setClipPath(clip)
        if self.pm:
            draw_cover(p, self.pm, th)
        else:
            g = QLinearGradient(th.topLeft(), th.bottomRight())
            g.setColorAt(0, hue_color(self.item.get("name", "?")))
            g.setColorAt(1, QColor("#0b1020"))
            p.fillRect(th, g)
            draw_icon(p, "search", QRectF(th.center().x() - 10, th.center().y() - 10, 20, 20), white(170))
        p.restore()
        x = th.right() + 14
        w = r.width() - x - (44 if self.sel else 12)
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(15, 600))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(x, r.top() + 9, w, 22), Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(self.item.get("name", ""), Qt.TextElideMode.ElideRight, int(w)))
        p.setPen(white(150))
        p.setFont(mkfont(12, 400))
        p.drawText(QRectF(x, r.top() + 32, w, 20), Qt.AlignmentFlag.AlignVCenter, self.src)


class ResultsMixin:
    """The search box + scrolling result list (with pictures) used by both the Add and the Edit card."""
    RES_H = 134

    def _build_search(self, term):
        row = QHBoxLayout()
        row.setSpacing(10)
        self.e_search = QLineEdit(term)
        self.e_search.setPlaceholderText(_t("Type the game's name as it is online"))
        self.e_search.returnPressed.connect(self._find)
        row.addWidget(self.e_search, 1)
        b = Btn("Search", "search", "ghost")
        b.clicked.connect(self._find)
        row.addWidget(b)
        self.lay.addLayout(row)
        self.lay.addSpacing(8)
        self._gen = 0
        self.res_box = QWidget()
        self.res = QVBoxLayout(self.res_box)
        self.res.setContentsMargins(0, 0, 0, 0)
        self.res.setSpacing(6)
        self.res.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.res_scroll = SmoothScroll()
        self.res_scroll.setWidget(self.res_box)
        self.res_scroll.setFixedHeight(self.RES_H)            # constant height: the card never jumps around
        self.lay.addWidget(self.res_scroll)

    def _find(self):
        self.search.emit(self.e_search.text())

    def _clear_res(self):
        self._gen += 1
        while self.res.count():
            w = self.res.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()

    def say(self, text):
        self._clear_res()
        self.res.addWidget(label(text, 13.5, 400, wrap=True, alpha=0.7))

    def set_results(self, items):
        self._clear_res()
        if not items:
            self.say("Nothing found. Try another spelling or a shorter name.")
            return
        gen = self._gen
        self.res_scroll.scroll_to(0, instant=True)
        for it in items[:20]:
            o = ResultRow(it)
            o.clicked.connect(lambda _=False, i=it: self.pick.emit(i))
            self.res.addWidget(o)
            url = it.get("thumb") or it.get("img")
            if url:
                self._load_thumb(o, url, gen)

    def _load_thumb(self, row, url, gen):
        if url in _THUMBS:
            row.set_pixmap(_THUMBS[url])
            return

        def done(data, err):
            if err is not None or not data or gen != self._gen:
                return
            pm = QPixmap()
            if pm.loadFromData(data):
                _THUMBS[url] = pm
                try:
                    row.set_pixmap(pm)
                except RuntimeError:              # the row was removed while the picture was loading
                    pass
        run_async(lambda: steam.fetch_bytes(url), done)


def preview_urls(item):
    """(background preview url, tile preview url) for a search result."""
    if item.get("source", "steam") == "steam":
        cdn = "https://cdn.akamai.steamstatic.com/steam/apps/%d/" % int(item["id"])
        return cdn + "library_hero.jpg", cdn + "library_600x900.jpg"
    u = item.get("img") or item.get("thumb") or ""
    return u, u


class AddDetailsCard(Card, ResultsMixin):
    """Second step of Add game: pictures (tap to change), name, internet picture yes/no, search."""
    search = Signal(str)
    pick = Signal(object)
    add = Signal()
    cancel = Signal()

    def __init__(self, file_path, guess):
        super().__init__(600)
        self.item = None
        self.hero_file = self.cover_file = None            # pictures the user chose from the PC
        self._pv = {"hero": None, "cover": None}           # previews that came from a search result
        self.h2("Add game")
        self.lay.addWidget(label(file_path, 12, 400, wrap=True, alpha=0.55))
        self.lay.addSpacing(14)
        pics = QHBoxLayout()
        pics.setSpacing(14)
        self.p_hero = ArtPicker("Background", 224, 112)
        self.p_cover = ArtPicker("Game tile", 112, 112)
        self.p_hero.clicked.connect(lambda: self.choose_art.emit("hero"))
        self.p_cover.clicked.connect(lambda: self.choose_art.emit("cover"))
        pics.addWidget(self.p_hero)
        pics.addWidget(self.p_cover)
        col = QVBoxLayout()
        col.addWidget(label("Tap a picture to choose your own. A picture you choose is never replaced by an online one.",
                            12, 400, wrap=True, alpha=0.6))
        col.addStretch(1)
        pics.addLayout(col, 1)
        self.lay.addLayout(pics)
        self.lay.addSpacing(14)
        self.lay.addWidget(label("Name", 13, 400, alpha=0.7))
        self.lay.addSpacing(6)
        self.e_name = QLineEdit(guess)
        self.lay.addWidget(self.e_name)
        self.lay.addSpacing(14)
        self.sw_online = _switch_row(self, "Get the picture and info from the internet", "", True)
        self.sw_name = _switch_row(self, "Use the game's name from the internet", "", True)
        self.e_name.textEdited.connect(lambda _t: self.sw_name.setChecked(False))
        self.lay.addWidget(label("NOT THE RIGHT GAME? PICK ANOTHER RESULT", 12.5, 700, alpha=0.6))
        self.lay.addSpacing(8)
        self._build_search(guess)
        self.say("Searching…")
        cancel = Btn("Cancel", "", "ghost")
        cancel.clicked.connect(self.cancel)
        go = Btn("Add game", "plus", "primary")
        go.clicked.connect(self.add)
        self.buttons(cancel, go)

    choose_art = Signal(str)

    def set_file(self, slot, path):
        """The user chose a picture from the PC for 'hero' (background) or 'cover' (tile)."""
        pk = self.p_hero if slot == "hero" else self.p_cover
        pm = load_pix(path)
        if pm is None:
            return False
        if slot == "hero":
            self.hero_file = path
        else:
            self.cover_file = path
        pk.set_pixmap(pm)
        return True

    def chosen(self, item):
        """The user tapped a search result: show its pictures in the two squares and remember it."""
        self.item = item
        self.sw_online.setChecked(True)
        for i in range(self.res.count()):                 # the list stays, so another result can still be picked
            w = self.res.itemAt(i).widget()
            if isinstance(w, ResultRow):
                w.set_selected(w.item is item)
        if self.sw_name.isChecked():
            self.e_name.setText(item["name"])
        hu, cu = preview_urls(item)
        gen = self._gen
        for slot, url, pk, mine in (("hero", hu, self.p_hero, self.hero_file), ("cover", cu, self.p_cover, self.cover_file)):
            if url and not mine:
                self._preview(pk, url, gen)

    def _preview(self, pk, url, gen):
        def done(data, err):
            if err is not None or not data:
                return
            pm = QPixmap()
            if pm.loadFromData(data):
                try:
                    pk.set_pixmap(pm)
                except RuntimeError:
                    pass
        run_async(lambda: steam.fetch_bytes(url), done)


class MoreCard(Card):
    fav = Signal()
    ach = Signal()
    edit = Signal()

    def __init__(self, g):
        super().__init__(440)
        self.h2(g["name"])
        for text, ic, sig in (("Remove from favorites" if g.get("fav") else "Add to favorites", "heart", self.fav),
                              ("Achievements", "trophy", self.ach), ("Edit game", "pencil", self.edit)):
            b = OptRow(text, ic)
            b.clicked.connect(sig)
            self.lay.addWidget(b)
            self.lay.addSpacing(8)


class EditCard(Card, ResultsMixin):
    RES_H = 84
    save = Signal(str)
    search = Signal(str)
    pick = Signal(object)            # the chosen search result {source, id, name, img}
    image = Signal()
    cover = Signal()
    steam_art = Signal()
    remove = Signal()
    dismiss = Signal()
    auto = Signal(bool)

    def refresh_pictures(self, g):
        """After a picture was changed: show the new ones."""
        self.p_hero.set_path(g.get("hero_path") or g.get("cover_path"), g.get("name"))
        self.p_cover.set_path(g.get("cover_path") or g.get("hero_path"), g.get("name"))

    def __init__(self, g):
        super().__init__(600)
        self.h2("Edit game")
        self.lay.addWidget(label("Name", 13, 400, alpha=0.7))
        self.lay.addSpacing(6)
        self.e_name = QLineEdit(g["name"])
        self.lay.addWidget(self.e_name)
        self.lay.addSpacing(14)
        pics = QHBoxLayout()                                 # the two real pictures: tap one to change it
        pics.setSpacing(14)
        self.p_hero = ArtPicker("Background", 224, 112)
        self.p_cover = ArtPicker("Game tile", 112, 112)
        self.p_hero.set_path(g.get("hero_path") or g.get("cover_path"), g.get("name"))
        self.p_cover.set_path(g.get("cover_path") or g.get("hero_path"), g.get("name"))
        self.p_hero.clicked.connect(self.image)
        self.p_cover.clicked.connect(self.cover)
        pics.addWidget(self.p_hero)
        pics.addWidget(self.p_cover)
        col = QVBoxLayout()
        col.addWidget(label("Tap a picture to change it. A picture you choose is never replaced by an online one.",
                            12, 400, wrap=True, alpha=0.6))
        col.addStretch(1)
        pics.addLayout(col, 1)
        self.lay.addLayout(pics)
        self.lay.addSpacing(8)
        b2 = Btn("Use online pictures again", "", "ghost")
        b2.clicked.connect(self.steam_art)
        self.lay.addWidget(b2, 0, Qt.AlignmentFlag.AlignLeft)
        self.lay.addSpacing(14)
        self.sw_auto = _switch_row(self, "Look for the picture and name on the internet by itself",
                                   "Off: the launcher never changes this game's picture or name on its own.",
                                   g.get("auto_art") is not False)
        self.sw_auto.toggled.connect(self.auto)
        self.lay.addWidget(label("Search online (Steam, GOG, Wikipedia, Google)",
                                 13, 400, alpha=0.7, wrap=True))
        self.lay.addSpacing(6)
        self._build_search(g["name"])
        self.sw_name = _switch_row(self, "Also use the found game's name", "", False)
        self.say("Currently matched to Steam app " + str(g["appid"]) if g.get("appid") else "No online match yet")
        self.lay.addSpacing(6)
        self.lay.addSpacing(12)
        path = label("Game file: " + g.get("path", ""), 12, 400, wrap=True, alpha=0.55)
        self.lay.addWidget(path)
        rm = Btn("Remove from launcher", "", "danger")
        rm.clicked.connect(self.remove)
        cl = Btn("Close", "", "ghost")
        cl.clicked.connect(self.dismiss)
        sv = Btn("Save", "", "primary")
        sv.clicked.connect(lambda: self.save.emit(self.e_name.text()))
        self.buttons(cl, sv, left=rm)
