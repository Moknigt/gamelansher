"""Colors, themes and UI preferences. Every widget reads colors from the single object `T`."""
import weakref

from PySide6.QtCore import QEasingCurve, QObject, Signal
from PySide6.QtGui import QColor

THEMES = {
    "midnight": ("Midnight", "#3a86ff", "#7be0ff", "#050816", "#ffffff"),
    "aurora": ("Aurora", "#1fd1a5", "#8ff5d8", "#03100e", "#032a22"),
    "ruby": ("Ruby", "#ff4d63", "#ffa0ab", "#14050a", "#ffffff"),
    "violet": ("Violet", "#9b6bff", "#d0b8ff", "#0c0618", "#ffffff"),
    "sunset": ("Sunset", "#ff8a3d", "#ffd08a", "#140a05", "#2a1100"),
    "mono": ("Mono", "#d9dde6", "#ffffff", "#08090c", "#0a0d16"),
    "ocean": ("Ocean", "#00b4d8", "#90e0ef", "#031018", "#021a24"),
    "emerald": ("Emerald", "#2ecc71", "#a8f0c6", "#04100a", "#03200f"),
    "rose": ("Rose", "#ff5ea8", "#ffb3d6", "#14050e", "#ffffff"),
    "gold": ("Gold", "#f2c14e", "#fff0b8", "#120d03", "#2a1e00"),
    "crimson": ("Crimson", "#d81f3a", "#ff8a99", "#12040a", "#ffffff"),
    "lime": ("Lime", "#a3e635", "#e1ffa0", "#0a1004", "#1a2900"),
    "teal": ("Teal", "#14b8a6", "#7ff0e3", "#031110", "#032a26"),
    "sky": ("Sky", "#38bdf8", "#bae6fd", "#04101a", "#032033"),
    "indigo": ("Indigo", "#6366f1", "#c0c2ff", "#07071a", "#ffffff"),
    "coffee": ("Coffee", "#c08552", "#f0cfa8", "#100a06", "#241205"),
}
# Animation styles (Settings > Animations). speed = multiplier on every duration, main/nav/fade = easing curves
# (a name, or (name, overshoot)); `fade` never overshoots because it drives opacities; page = how a page enters.
ANIMS = {
    "smooth": dict(name="Smooth", hint="Soft glide. The default.", speed=1.0, main="OutCubic",
                   nav=("OutBack", 0.8), fade="InOutSine", page="rise", hover=0.30),
    "snappy": dict(name="Snappy", hint="Fast and crisp, no waiting.", speed=0.55, main="OutQuad",
                   nav="OutQuad", fade="OutQuad", page="fade", hover=0.55),
    "bouncy": dict(name="Bouncy", hint="Springy, things overshoot a little.", speed=1.1, main=("OutBack", 1.3),
                   nav=("OutBack", 2.6), fade="OutCubic", page="pop", hover=0.22),
    "slide": dict(name="Slide", hint="Pages slide in from the side.", speed=1.0, main="OutQuart",
                  nav="OutQuart", fade="OutCubic", page="slide", hover=0.30),
    "zoom": dict(name="Zoom", hint="Pages zoom in softly.", speed=1.0, main="OutCubic",
                 nav="OutCubic", fade="OutCubic", page="zoom", hover=0.30),
    "dreamy": dict(name="Dreamy", hint="Slow and floaty.", speed=1.7, main="InOutSine",
                   nav="InOutSine", fade="InOutSine", page="fade", hover=0.16),
    "off": dict(name="Off", hint="No animations at all.", speed=0.0, main="Linear",
                nav="Linear", fade="Linear", page="none", hover=1.0),
}
DEFAULT_PREFS = {"theme": "midnight", "anim": "smooth", "particles": True, "sfx": True, "vol": 0.5,
                 "clock24": False, "dim": 1.0, "popups": True, "popsfx": True, "lang": "en"}


def mix(a, b, t, alpha=255):
    return QColor(int(a.red() * (1 - t) + b.red() * t), int(a.green() * (1 - t) + b.green() * t),
                  int(a.blue() * (1 - t) + b.blue() * t), alpha)


class ThemeManager(QObject):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.prefs = dict(DEFAULT_PREFS)
        self._tuned = []                      # (weakref to animation, base ms, kind) - re-tuned when the style changes
        self._derive()

    def load(self, ui):
        self.prefs = dict(DEFAULT_PREFS)
        for k, v in (ui or {}).items():
            if k in DEFAULT_PREFS:
                self.prefs[k] = v
        if self.prefs["theme"] not in THEMES:
            self.prefs["theme"] = "midnight"
        if self.prefs["anim"] not in ANIMS:           # old versions stored "on"
            self.prefs["anim"] = "smooth"
        from . import i18n
        i18n.set_lang(self.prefs.get("lang"))          # the language is applied at start-up (restart after changing it)
        self._derive()
        self.changed.emit()

    def set(self, key, value):
        self.prefs[key] = value
        self._derive()
        self.changed.emit()

    @property
    def anim_key(self):
        k = self.prefs.get("anim")
        return k if k in ANIMS else "smooth"

    @property
    def anim_on(self):
        return self.anim_key != "off"

    @property
    def preset(self):
        return ANIMS[self.anim_key]

    @property
    def page_style(self):
        return self.preset["page"]

    @property
    def hover_k(self):
        """How fast eased hover values move per 15 ms tick (0..1)."""
        return self.preset["hover"]

    @staticmethod
    def make_curve(spec):
        name, over = (spec, None) if isinstance(spec, str) else spec
        c = QEasingCurve(getattr(QEasingCurve.Type, name))
        if over is not None:
            c.setOvershoot(over)
        return c

    def curve(self, kind="main", key=None):
        key = key or self.anim_key
        if kind == "ease":                         # never overshoots: scrolling, panels sliding in, widths
            return QEasingCurve(QEasingCurve.Type.Linear if key == "off" else QEasingCurve.Type.OutCubic)
        return self.make_curve(ANIMS[key][kind])

    def dur(self, ms, key=None):
        sp = ANIMS[key or self.anim_key]["speed"]
        return 0 if sp <= 0 else max(1, int(ms * sp))

    def tune(self, an, ms, kind="main"):
        """Gives an animation its duration + easing from the current style, and keeps it updated when the style changes."""
        self._tuned.append((weakref.ref(an), ms, kind))
        self._apply(an, ms, kind)

    def _apply(self, an, ms, kind):
        an.setDuration(self.dur(ms))
        an.setEasingCurve(self.curve(kind))

    def _retune(self):
        keep = []
        for ref, ms, kind in self._tuned:
            an = ref()
            if an is None:
                continue
            try:
                self._apply(an, ms, kind)
            except RuntimeError:                  # the Qt object is already gone
                continue
            keep.append((ref, ms, kind))
        self._tuned = keep

    def _derive(self):
        _n, ac, ac2, base, onac = THEMES[self.prefs["theme"]]
        self.ac, self.ac2, self.base, self.onac = QColor(ac), QColor(ac2), QColor(base), QColor(onac)
        self.panel_top = mix(self.base, self.ac, 0.22, 172)
        self.panel_bot = mix(self.base, self.ac, 0.06, 190)
        self.card_bg = mix(self.base, self.ac, 0.05)
        self.card_bg.setAlpha(255)
        self._retune()

    def ac_a(self, alpha):
        c = QColor(self.ac)
        c.setAlphaF(max(0.0, min(1.0, alpha)))
        return c

    def ac2_a(self, alpha):
        c = QColor(self.ac2)
        c.setAlphaF(max(0.0, min(1.0, alpha)))
        return c

    def qss(self):
        ac, ac2 = self.ac.name(), self.ac2.name()
        r, g, b = self.ac.red(), self.ac.green(), self.ac.blue()
        return f"""
        QToolTip {{ background:#10162a; color:#fff; border:1px solid {ac}; padding:5px 8px; }}
        QLineEdit {{ background:rgba(255,255,255,18); border:1px solid rgba(255,255,255,46); border-radius:10px;
                     padding:11px 14px; color:#fff; font-size:15px; selection-background-color:{ac}; }}
        QLineEdit:focus {{ border:1px solid rgba({r},{g},{b},200); }}
        QComboBox {{ background:rgba(10,16,40,160); color:#fff; border:1.5px solid rgba({r},{g},{b},105);
                     border-radius:18px; padding:8px 18px; font-size:14px; min-width:150px; }}
        QComboBox::drop-down {{ border:0; width:26px; }}
        QComboBox QAbstractItemView {{ background:#10162a; color:#fff; border:1px solid {ac}; outline:0;
                     selection-background-color:{ac}; selection-color:{self.onac.name()}; padding:4px; }}
        QSlider::groove:horizontal {{ height:6px; background:rgba(255,255,255,40); border-radius:3px; }}
        QSlider::sub-page:horizontal {{ background:{ac}; border-radius:3px; }}
        QSlider::handle:horizontal {{ background:{ac2}; width:16px; height:16px; margin:-5px 0; border-radius:8px; }}
        QScrollBar {{ width:0; height:0; background:transparent; }}
        QScrollArea {{ background:transparent; border:none; }}
        QScrollArea > QWidget > QWidget {{ background:transparent; }}
        QLabel {{ background:transparent; color:#fff; }}
        """


T = ThemeManager()
