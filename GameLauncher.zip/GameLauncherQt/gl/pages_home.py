"""Home screen: the games strip on top, big title + Play button, play-time card."""
import time

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, Qt, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget

from .icons import draw_icon
from .theme import T
from .util import first_sentence, fmt_play
from .widgets import (AA, SMOOTH, Btn, FadeSwap, Panel, StatCard, chip, label, load_pix, mkfont, paint_cover, white)


class TileRow(QWidget):
    """The strip of game tiles. One painted widget: a glowing plate glides to the selected game."""
    picked = Signal(str)
    activated = Signal(str)
    add_clicked = Signal()
    stepped = Signal(int)
    TILE, GAP, PADX = 90, 22, 70

    def __init__(self, parent=None):
        super().__init__(parent)
        self.games, self.sel_id, self.pos_, self.hover = [], None, 0.0, -1
        self._wheel_t = 0.0
        self.setMouseTracking(True)
        self._an = QVariantAnimation(self)
        self._an.setDuration(420)
        self._an.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._an.valueChanged.connect(self._set)

    @property
    def step(self):
        return self.TILE + self.GAP

    def _set(self, v):
        self.pos_ = float(v)
        self.update()

    def index_of(self, gid):
        for i, g in enumerate(self.games):
            if g["id"] == gid:
                return i
        return -1

    def set_games(self, games, sel_id):
        self.games, self.sel_id = list(games), sel_id
        self._an.stop()
        self.pos_ = float(max(0, self.index_of(sel_id)))
        self.update()

    def select(self, gid):
        self.sel_id = gid
        i = self.index_of(gid)
        if i < 0:
            return
        self._an.stop()
        if not T.anim_on:
            self.pos_ = float(i)
            self.update()
            return
        self._an.setStartValue(self.pos_)
        self._an.setEndValue(float(i))
        self._an.start()

    def _scroll_x(self):
        n = len(self.games) + 1
        total = self.PADX * 2 + n * self.step - self.GAP
        mx = max(0.0, total - self.width())
        return max(0.0, min(mx, self.PADX + self.pos_ * self.step + self.TILE / 2 - self.width() / 2))

    def _hit(self, pos):
        sc = self._scroll_x()
        i = int(round((pos.x() + sc - self.PADX - self.TILE / 2) / self.step))
        if 0 <= i <= len(self.games):
            x = self.PADX + i * self.step - sc
            if x - 6 <= pos.x() <= x + self.TILE + 6:
                return i
        return -1

    def mouseMoveEvent(self, e):
        h = self._hit(e.position())
        if h != self.hover:
            self.hover = h
            self.setCursor(Qt.CursorShape.PointingHandCursor if h >= 0 else Qt.CursorShape.ArrowCursor)
            self.update()

    def leaveEvent(self, e):
        self.hover = -1
        self.update()

    def mousePressEvent(self, e):
        i = self._hit(e.position())
        if i < 0:
            return
        if i == len(self.games):
            self.add_clicked.emit()
        else:
            self.picked.emit(self.games[i]["id"])

    def mouseDoubleClickEvent(self, e):
        i = self._hit(e.position())
        if 0 <= i < len(self.games):
            self.activated.emit(self.games[i]["id"])

    def wheelEvent(self, e):
        now = time.time()
        if now - self._wheel_t > 0.085:
            self._wheel_t = now
            d = e.angleDelta().y() or e.angleDelta().x()
            self.stepped.emit(1 if d < 0 else -1)
        e.accept()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        n, T_, sc, cy = len(self.games), self.TILE, self._scroll_x(), self.height() / 2
        p.setClipRect(QRectF(6, 0, self.width() - 12, self.height()))
        if n:                                           # the plate under the selected game
            cx = self.PADX + self.pos_ * self.step + T_ / 2 - sc
            size = T_ * 1.12 + 22
            r = QRectF(cx - size / 2, cy - size / 2, size, size)
            g = QLinearGradient(r.topLeft(), r.bottomLeft())
            g.setColorAt(0, T.ac_a(0.10))
            g.setColorAt(1, T.ac_a(0.30))
            p.setBrush(g)
            p.setPen(QPen(T.ac_a(0.75), 1.5))
            p.drawRoundedRect(r, 24, 24)
            p.setPen(QPen(T.ac2, 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawLine(QPointF(r.left() + r.width() * 0.28, r.bottom()), QPointF(r.right() - r.width() * 0.28, r.bottom()))
        for i in range(n + 1):
            x = self.PADX + i * self.step - sc
            if x > self.width() or x + T_ < 0:
                continue
            close = max(0.0, 1.0 - abs(i - self.pos_)) if n else 0.0
            size = T_ * (1 + 0.12 * close)
            lift = 3 if (i == self.hover and close < 0.5) else 0
            r = QRectF(x + T_ / 2 - size / 2, cy - size / 2 - lift, size, size)
            if i == n:                                  # the "+" tile
                p.setBrush(T.ac_a(0.08))
                p.setPen(QPen(T.ac_a(0.6), 2, Qt.PenStyle.DashLine))
                p.drawRoundedRect(r.adjusted(1, 1, -1, -1), 20, 20)
                draw_icon(p, "plus", QRectF(r.center().x() - 17, r.center().y() - 17, 34, 34), white(220 if i == self.hover else 190))
                continue
            paint_cover(p, r, self.games[i], 20)
            if close < 0.98 and i != self.hover:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QColor(0, 0, 0, int(70 * (1 - close))))
                p.drawRoundedRect(r, 20, 20)
            if close > 0.5:
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(T.ac2, 2))
                p.drawRoundedRect(r.adjusted(-1, -1, 1, 1), 20, 20)
            if self.games[i].get("fav"):
                draw_icon(p, "star", QRectF(r.right() - 24, r.top() + 6, 18, 18), "#ffd75e")


class HeroBox(QWidget):
    """Big title (or logo), one-line description, chips and the Play button."""
    play = Signal()
    fav = Signal()
    trophies = Signal()
    more = Signal()
    add = Signal()
    W = 560

    def __init__(self, parent=None):
        super().__init__(parent)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(0)
        self.logo = QLabel()
        self.title = QLabel()
        self.title.setWordWrap(True)
        self.title.setStyleSheet("color:#fff; background:transparent;")
        self.title.setFixedWidth(self.W)
        self.tag = label("", 16, 400, wrap=True, alpha=0.88)
        self.tag.setFixedWidth(440)
        self.chips_box = QWidget()
        self.chips = QHBoxLayout(self.chips_box)
        self.chips.setContentsMargins(0, 0, 0, 0)
        self.chips.setSpacing(8)
        self.btns_box = QWidget()
        bl = QHBoxLayout(self.btns_box)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(12)
        self.b_play = Btn("Play", "play", "primary")
        self.b_fav = Btn("", "heart", "round", 50, icon_on="heart_on")
        self.b_tro = Btn("", "trophy", "round", 50)
        self.b_more = Btn("", "more", "round", 50)
        self.b_add = Btn("Add Game", "plus", "primary")
        for b in (self.b_play, self.b_fav, self.b_tro, self.b_more, self.b_add):
            bl.addWidget(b)
        bl.addStretch(1)
        self.b_play.clicked.connect(self.play)
        self.b_fav.clicked.connect(self.fav)
        self.b_tro.clicked.connect(self.trophies)
        self.b_more.clicked.connect(self.more)
        self.b_add.clicked.connect(self.add)
        for w, gap in ((self.logo, 12), (self.title, 8), (self.tag, 20), (self.chips_box, 18), (self.btns_box, 0)):
            self.lay.addWidget(w, 0, Qt.AlignmentFlag.AlignLeft)
            self.lay.addSpacing(gap)
        self.setFixedWidth(self.W)

    def _title_font(self, text):
        px = 54 if len(text) <= 16 else 44 if len(text) <= 26 else 34
        self.title.setFont(mkfont(px, 700, serif=True, spacing=2))

    def _tag(self, text):
        self.tag.setText(text)
        self.tag.setFixedHeight(max(20, self.tag.heightForWidth(self.tag.width())))
        self.tag.setVisible(bool(text))

    def _chips(self, items):
        while self.chips.count():
            it = self.chips.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        for t in items:
            self.chips.addWidget(chip(t))
        self.chips.addStretch(1)
        self.chips_box.setVisible(bool(items))

    def set_game(self, g):
        lp = load_pix(g.get("logo_path"))
        if lp:
            self.logo.setPixmap(lp.scaled(400, 150, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        self.logo.setVisible(bool(lp))
        self.title.setVisible(not lp)
        name = (g.get("name") or "").upper()
        self.title.setText(name)
        self._title_font(name)
        tag = first_sentence(g.get("desc"))
        self._tag(tag)
        extra = [g.get("developer"), " · ".join(g.get("genres") or [])]
        if g.get("last_played"):
            from .util import fmt_ago
            extra.append("Last played " + fmt_ago(g["last_played"]))
        self._chips([x for x in extra if x])
        self.b_fav.active = bool(g.get("fav"))
        self.b_fav.update()
        for b in (self.b_play, self.b_fav, self.b_tro, self.b_more):
            b.show()
        self.b_add.hide()
        self._resize()

    def set_empty(self, welcome):
        self.logo.hide()
        self.title.show()
        t = "Welcome" if welcome else "Nothing here yet"
        self.title.setText(t.upper())
        self._title_font(t)
        self._tag("Press + and choose the game's .exe file. It shows up here with its picture. The game stays where it is."
                  if welcome else "Play, favorite or add games and they will show up in this list.")
        self._chips([])
        for b in (self.b_play, self.b_fav, self.b_tro, self.b_more):
            b.hide()
        self.b_add.setVisible(welcome)
        self._resize()

    def _resize(self):
        self.lay.activate()
        h = self.lay.totalHeightForWidth(self.W)
        self.setFixedHeight(h if h > 0 else self.lay.sizeHint().height())


class HomePage(QWidget):
    picked = Signal(str)
    activated = Signal(str)
    stepped = Signal(int)
    play = Signal()
    fav = Signal()
    trophies = Signal()
    more = Signal()
    add = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.games, self.sel_id, self.welcome = [], None, True
        self.strip = Panel(self, radius=28, border=0.38)
        self.row = TileRow(self.strip)
        self.aL = Btn("", "chevL", "icon", 44, parent=self.strip)
        self.aR = Btn("", "chevR", "icon", 44, parent=self.strip)
        self.hero = HeroBox(self)
        self.stats = QWidget(self)
        sl = QHBoxLayout(self.stats)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(12)
        self.stats_lay = sl
        self.fade_h, self.fade_s = FadeSwap(self.hero), FadeSwap(self.stats)
        self.row.picked.connect(self.picked)
        self.row.activated.connect(self.activated)
        self.row.stepped.connect(self.stepped)
        self.row.add_clicked.connect(self.add)
        self.aL.clicked.connect(lambda: self.stepped.emit(-1))
        self.aR.clicked.connect(lambda: self.stepped.emit(1))
        self.hero.play.connect(self.play)
        self.hero.fav.connect(self.fav)
        self.hero.trophies.connect(self.trophies)
        self.hero.more.connect(self.more)
        self.hero.add.connect(self.add)

    def current(self):
        for g in self.games:
            if g["id"] == self.sel_id:
                return g
        return None

    def show_games(self, games, sel_id, welcome):
        self.games, self.sel_id, self.welcome = list(games), sel_id, welcome
        self.row.set_games(self.games, sel_id)
        self._arrows()
        self._fill(False)

    def select(self, gid):
        self.sel_id = gid
        self.row.select(gid)
        self._arrows()
        self._fill(True)

    def refresh_current(self):
        self.row.update()
        self._fill(False)

    def _arrows(self):
        i = self.row.index_of(self.sel_id)
        self.aL.setVisible(i > 0)
        self.aR.setVisible(0 <= i < len(self.games) - 1)

    def _fill(self, fade):
        g = self.current()

        def apply():
            if g is None:
                self.hero.set_empty(self.welcome)
                self._stats(None)
            else:
                self.hero.set_game(g)
                self._stats(g)
            self._place()
        (self.fade_h.swap if fade else (lambda f: f()))(apply)

    def _stats(self, g):
        while self.stats_lay.count():
            it = self.stats_lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        if g is None:
            return
        self.stats_lay.addWidget(StatCard("gamepad", "Play Time", fmt_play(g.get("playtime"))))
        tro = StatCard("trophy", "Achievements", f"{g['tro_unlocked']} / {g['tro_total']}" if g.get("tro_total") else "—", clickable=True)
        tro.clicked.connect(self.trophies)
        self.stats_lay.addWidget(tro)
        self.stats.adjustSize()

    def _place(self):
        w, h = self.width(), self.height()
        self.hero.move(44, max(170, h - 116 - self.hero.height()))
        self.stats.adjustSize()
        self.stats.move(w - 36 - self.stats.width(), h - 78 - self.stats.height())

    def resizeEvent(self, e):
        w = self.width()
        self.strip.setGeometry(8, 8, max(200, w - 36), 156)
        self.row.setGeometry(0, 0, self.strip.width(), self.strip.height())
        self.aL.move(12, (self.strip.height() - 44) // 2)
        self.aR.move(self.strip.width() - 56, (self.strip.height() - 44) // 2)
        self._place()
