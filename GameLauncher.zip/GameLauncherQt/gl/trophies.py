"""Launcher trophies + per-game trophies. Pure logic copied from the old version (nothing here touches the UI)."""
import time

from .store import DB_LOCK, load_db, save_db


def _total_play(d):
    return sum(g.get("playtime", 0) for g in d["games"])


def _flag(d, name):
    return 1 if (d.get("flags") or {}).get(name) else 0


def _count(d, key):
    return sum(1 for g in d["games"] if g.get(key))


# (id, name, description, tier, icon, progress(subject) -> (current, target), kind: n=number t=time)
GLOBAL_DEFS = [
    ("add1", "Welcome Aboard", "Add your first game to the library", "bronze", "plus",
     lambda d: (len(d["games"]), 1), "n"),
    ("add5", "Collector", "Have 5 games in your library", "silver", "stack",
     lambda d: (len(d["games"]), 5), "n"),
    ("add15", "Game Vault", "Have 15 games in your library", "gold", "stack",
     lambda d: (len(d["games"]), 15), "n"),
    ("play1", "Player One", "Start a game from the launcher", "bronze", "play",
     lambda d: (sum(g.get("launches", 0) for g in d["games"]), 1), "n"),
    ("mix5", "Variety Pack", "Start 5 different games", "silver", "gamepad",
     lambda d: (sum(1 for g in d["games"] if g.get("launches", 0) > 0), 5), "n"),
    ("fav1", "Close to My Heart", "Mark a game as a favorite", "bronze", "heart",
     lambda d: (_count(d, "fav"), 1), "n"),
    ("art1", "Interior Designer", "Set your own background image for a game", "bronze", "image",
     lambda d: (_count(d, "custom_hero"), 1), "n"),
    ("steam1", "Connected", "Add your Steam key and ID in Settings", "silver", "link",
     lambda d: (1 if d["settings"].get("steam_key") and d["settings"].get("steam_id") else 0, 1), "n"),
    ("owl", "Night Owl", "Start a game between midnight and 5 AM", "silver", "moon",
     lambda d: (1 if (d.get("flags") or {}).get("night_owl") else 0, 1), "n"),
    ("lib", "Explorer", "Open the Library", "bronze", "lib",
     lambda d: (_flag(d, "lib"), 1), "n"),
    ("search", "Detective", "Search for a game", "bronze", "search",
     lambda d: (_flag(d, "search"), 1), "n"),
    ("settings", "Tweaker", "Open Settings", "bronze", "sliders",
     lambda d: (_flag(d, "settings"), 1), "n"),
    ("theme", "Stylist", "Change the theme", "silver", "star",
     lambda d: (_flag(d, "theme"), 1), "n"),
    ("sound", "Sound Check", "Switch the sound effects on or off", "bronze", "spk",
     lambda d: (_flag(d, "sound"), 1), "n"),
    ("kbd", "Keyboard Warrior", "Move around with the arrow keys", "bronze", "dpad",
     lambda d: (_flag(d, "kbd"), 1), "n"),
    ("pad", "Controller Ready", "Use a gamepad", "silver", "gamepad",
     lambda d: (_flag(d, "pad"), 1), "n"),
    ("fav3", "Curator", "Have 3 favorite games", "silver", "heart",
     lambda d: (_count(d, "fav"), 3), "n"),
    ("early", "Early Bird", "Start a game between 5 and 9 AM", "silver", "sun",
     lambda d: (_flag(d, "early_bird"), 1), "n"),
    ("hab25", "Creature of Habit", "Start games 25 times in total", "gold", "play",
     lambda d: (sum(g.get("launches", 0) for g in d["games"]), 25), "n"),
    ("hrs10", "Getting Hooked", "Play 10 hours in total", "silver", "clock",
     lambda d: (_total_play(d), 36000), "t"),
    ("hrs100", "No Days Off", "Play 100 hours in total", "gold", "clock",
     lambda d: (_total_play(d), 360000), "t"),
]

GAME_DEFS = [
    ("first", "First Launch", "Start this game from the launcher", "bronze", "play",
     lambda g: (g.get("launches", 0), 1), "n"),
    ("l10", "Regular", "Start this game 10 times", "silver", "play",
     lambda g: (g.get("launches", 0), 10), "n"),
    ("l25", "Loyal Fan", "Start this game 25 times", "gold", "play",
     lambda g: (g.get("launches", 0), 25), "n"),
    ("t30", "Warming Up", "Play for 30 minutes", "bronze", "clock",
     lambda g: (g.get("playtime", 0), 1800), "t"),
    ("t1h", "One More Hour", "Play for 1 hour", "bronze", "clock",
     lambda g: (g.get("playtime", 0), 3600), "t"),
    ("t5h", "Hooked", "Play for 5 hours", "silver", "clock",
     lambda g: (g.get("playtime", 0), 18000), "t"),
    ("t20h", "Veteran", "Play for 20 hours", "gold", "clock",
     lambda g: (g.get("playtime", 0), 72000), "t"),
    ("t50h", "Legend", "Play for 50 hours", "gold", "clock",
     lambda g: (g.get("playtime", 0), 180000), "t"),
    ("fav", "Favorite", "Add this game to your favorites", "bronze", "heart",
     lambda g: (1 if g.get("fav") else 0, 1), "n"),
    ("style", "Your Style", "Set your own background image", "bronze", "image",
     lambda g: (1 if g.get("custom_hero") else 0, 1), "n"),
    ("steam", "Matched", "Link this game to its Steam page", "bronze", "link",
     lambda g: (1 if g.get("appid") else 0, 1), "n"),
]


def eval_defs(defs, subject, store, plat_desc):
    """Progress of every trophy (plus the Platinum for finishing them all). Pure, saves nothing."""
    items = []
    for tid, name, desc, tier, icon, fn, kind in defs:
        cur, tgt = fn(subject)
        rec = store.get(tid)
        items.append({"id": tid, "name": name, "desc": desc, "tier": tier, "icon": icon,
                      "cur": min(cur, tgt), "target": tgt, "kind": kind,
                      "achieved": bool(rec) or cur >= tgt, "ts": (rec or {}).get("ts", 0)})
    done = sum(1 for i in items if i["achieved"])
    rec = store.get("plat")
    items.append({"id": "plat", "name": "Platinum", "desc": plat_desc, "tier": "plat", "icon": "trophy",
                  "cur": done, "target": len(items), "kind": "n",
                  "achieved": bool(rec) or done == len(items), "ts": (rec or {}).get("ts", 0)})
    return items


def _record(items, store, silent, label):
    """Remembers newly earned trophies; returns (changed, popups-not-shown-yet)."""
    changed, now = False, time.time()
    for i in items:
        if i["achieved"] and i["id"] not in store:
            store[i["id"]] = {"ts": now, "seen": bool(silent)}
            changed = True
    new = []
    for i in items:
        r = store.get(i["id"])
        if r is not None and not r.get("seen"):
            r["seen"] = True
            changed = True
            new.append({"name": i["name"], "tier": i["tier"], "icon": i["icon"], "game": label})
    return changed, new


def sync_trophies():
    """Unlocks whatever has been earned since last time. Returns trophies to announce."""
    with DB_LOCK:
        db = load_db()
        silent = "trophies" not in db      # first run of this version: unlock quietly, no pop-up flood
        store = db.setdefault("trophies", {})
        changed, new = _record(eval_defs(GLOBAL_DEFS, db, store, "Unlock every launcher trophy"),
                               store, silent, None)
        changed = changed or silent
        for g in db["games"]:
            st = g.setdefault("trophies", {})
            c, n = _record(eval_defs(GAME_DEFS, g, st, "Unlock every trophy for this game"),
                           st, silent, g.get("name"))
            changed, new = changed or c, new + n
        if changed:
            save_db(db)
        return new


