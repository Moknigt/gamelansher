"""Full-window background: theme glow, the selected game's picture (cross-fading), shade and floating particles."""
import math
import random

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, Qt, QTimer, QVariantAnimation
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPixmap, QRadialGradient
from PySide6.QtWidgets import QWidget

from .theme import T
from .widgets import AA, SMOOTH, load_pix, white

# image opacity, shade strength per screen
MODES = {"home": (1.0, "home"), "lib": (0.0, "home"), "game": (1.0, "game"), "ach": (0.55, "ach")}


class Background(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.cur = self.prev = None          # pixmaps
        self.fade = 1.0
        self.img_op = 1.0
        self.shade = "home"
        self._path = None
        self._cache = {}
        self.parts = []
        self.t0 = 0.0
        self._fade_an = QVariantAnimation(self)
        self._fade_an.setDuration(900)
        self._fade_an.setEasingCurve(QEasingCurve.Type.InOutSine)
        self._fade_an.valueChanged.connect(self._set_fade)
        self._op_an = QVariantAnimation(self)
        self._op_an.setDuration(450)
        self._op_an.valueChanged.connect(self._set_op)
        self.timer = QTimer(self)
        self.timer.setInterval(33)
        self.timer.timeout.connect(self._tick)
        T.changed.connect(self._theme)
        self._theme()

    # -- state
    def set_image(self, path):
        if path == self._path:
            return
        self._path = path
        self.prev, self.cur = self.cur, load_pix(path)
        if not T.anim_on:
            self.fade = 1.0
            self.update()
            return
        self._fade_an.stop()
        self._fade_an.setStartValue(0.0)
        self._fade_an.setEndValue(1.0)
        self._fade_an.start()

    def set_mode(self, mode):
        op, shade = MODES.get(mode, MODES["home"])
        self.shade = shade
        self._op_an.stop()
        if not T.anim_on:
            self.img_op = op
            self.update()
            return
        self._op_an.setStartValue(self.img_op)
        self._op_an.setEndValue(op)
        self._op_an.start()

    def _set_fade(self, v):
        self.fade = float(v)
        self.update()

    def _set_op(self, v):
        self.img_op = float(v)
        self.update()

    def _theme(self):
        want = bool(T.prefs.get("particles")) and T.anim_on
        if want and not self.timer.isActive():
            if not self.parts:
                self.parts = [[random.random(), random.random(), random.random() * 2 + 0.6, random.random() * 0.0006 + 0.0002,
                               random.random() * 0.5 + 0.15, random.random() * 6.28] for _ in range(46)]
            self.timer.start()
        elif not want:
            self.timer.stop()
        self.update()

    def _tick(self):
        self.t0 += 0.033
        for q in self.parts:
            q[1] -= q[3]
            q[0] += math.sin(self.t0 + q[5]) * 0.0002
            if q[1] < -0.01:
                q[1], q[0] = 1.01, random.random()
        self.update()

    def resizeEvent(self, e):
        self._cache.clear()

    # -- painting
    def _fitted(self, pm):
        """Picture scaled to cover the window; cached so animation frames stay cheap."""
        key = (pm.cacheKey(), self.width(), self.height())
        hit = self._cache.get(key)
        if hit is None:
            if len(self._cache) > 6:
                self._cache.clear()
            w, h = self.width(), self.height()
            s = pm.scaled(w, h, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
            hit = s.copy(max(0, (s.width() - w) // 2), max(0, (s.height() - h) // 2), w, h)
            self._cache[key] = hit
        return hit

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        w, h = self.width(), self.height()
        r = self.rect()
        p.fillRect(r, T.base)
        has_img = self.img_op > 0.01 and (self.cur is not None or self.prev is not None)
        for cx, cy, rad, a in ((0.12, 1.0, 0.9, 0.5), (1.0, 1.0, 1.0, 0.4), (0.6, 0.0, 0.7, 0.22)):
            if has_img:
                break                       # picture shows with its own colours: no blue glow over/under it
            g = QRadialGradient(QPointF(cx * w, cy * h), rad * max(w, h) * 0.75)
            g.setColorAt(0, T.ac_a(a))
            g.setColorAt(1, T.ac_a(0))
            p.fillRect(r, g)
        dim = float(T.prefs.get("dim", 1.0))
        if self.img_op > 0.01:
            for pm, op in ((self.prev, 1.0 - self.fade), (self.cur, self.fade)):
                if pm is not None and op > 0.01:
                    p.setOpacity(op * self.img_op * min(1.0, dim))
                    p.drawPixmap(0, 0, self._fitted(pm))
            p.setOpacity(1.0)
            if dim > 1.0:
                p.fillRect(r, white(int((dim - 1.0) * 120)))
            elif dim < 1.0:
                p.fillRect(r, QColor(0, 0, 0, int((1.0 - dim) * 160)))
            self._shade(p, w, h)
        # floating particles
        if self.timer.isActive():
            p.setPen(Qt.PenStyle.NoPen)
            for x, y, rad, _s, a, ph in self.parts:
                c = QColor(T.ac2)
                c.setAlphaF(max(0.0, min(1.0, a * (0.6 + 0.4 * math.sin(self.t0 * 1.5 + ph)))))
                p.setBrush(c)
                p.drawEllipse(QPointF(x * w, y * h), rad, rad)

    def _shade(self, p, w, h):
        k = {"home": ((0, 0, 0, 110), (0, 0, 0, 20), (0, 0, 0, 0), (0, 0, 0, 70), (0, 0, 0, 150)),
             "game": ((0, 0, 0, 204), (0, 0, 0, 128), (0, 0, 0, 38), (0, 0, 0, 140), (0, 0, 0, 217)),
             "ach": ((0, 0, 0, 245), (0, 0, 0, 184), (0, 0, 0, 51), (0, 0, 0, 178), (0, 0, 0, 230))}[self.shade]
        g = QLinearGradient(0, 0, w, 0)                 # left to right
        g.setColorAt(0, QColor(*k[0]))
        g.setColorAt(0.45 if self.shade != "home" else 0.4, QColor(*k[1]))
        g.setColorAt(1 if self.shade != "home" else 0.65, QColor(*k[2]))
        p.fillRect(self.rect(), g)
        g2 = QLinearGradient(0, 0, 0, h)                # top and bottom
        g2.setColorAt(0, QColor(*k[3]))
        g2.setColorAt(0.25, QColor(0, 0, 0, 0))
        g2.setColorAt(0.6, QColor(0, 0, 0, 0))
        g2.setColorAt(1, QColor(*k[4]))
        p.fillRect(self.rect(), g2)
