"""The Settings page (its own screen, opened from the gear button).

Overview = big category cards. Each category is its own page, reached from the card or from the side list:
Themes (all themes as preview cards), Animations (several styles you can switch between), Display & Sound,
Games & Trophies, Steam, Your data (backups). Everything touches data only through `Backend`.
"""
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, QVariantAnimation, Signal
from PySide6.QtGui import (QBrush, QColor, QDesktopServices, QFontMetrics, QLinearGradient, QPainter, QPainterPath, QPen,
                           QRadialGradient)
from PySide6.QtWidgets import (QAbstractButton, QHBoxLayout, QLabel, QLineEdit, QSizePolicy, QSlider, QVBoxLayout,
                               QWidget)

from .dialogs import LangPill
from .i18n import tr as _t
from .icons import draw_icon, icon
from .pages_ach import ClickLabel, Flow
from .theme import ANIMS, THEMES, T, mix
from .widgets import AA, Btn, PageFx, Panel, SmoothScroll, Switch, label, mkfont, white

# (key, icon, title, one-line description) - the side list in the main window uses the same keys
CATS = [
    ("themes", "palette", "Themes", "Colors of the whole launcher"),
    ("anim", "wand", "Animations", "How things move"),
    ("display", "monitor", "Display & Sound", "Language, clock, brightness, sound"),
    ("play", "play", "Games & Trophies", "What happens when you start a game"),
    ("steam", "steam", "Steam", "Real achievements from your Steam account"),
    ("data", "shield", "Your data", "Backups of your games list"),
]
SIDE_ITEMS = [("home", "sliders", "Overview")] + [(k, ic, t) for k, ic, t, _d in CATS]


def _ease(card, ms=180):
    """A 0..1 value that follows hover smoothly (uses the animation style's speed)."""
    an = QVariantAnimation(card)
    T.tune(an, ms, "fade")
    return an


# ----------------------------------------------------------------------------- cards
class CatCard(QAbstractButton):
    """Big category card on the Settings overview."""

    def __init__(self, ic, title, summary, parent=None):
        super().__init__(parent)
        self.ic, self.title, self.summary = ic, _t(title), summary
        self.h = 0.0
        self.setFixedSize(340, 104)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setMouseTracking(True)
        self._an = _ease(self)
        self._an.valueChanged.connect(self._set)
        T.changed.connect(self.update)

    def _set(self, v):
        self.h = float(v)
        self.update()

    def _go(self, to):
        self._an.stop()
        if not T.anim_on:
            self.h = to
            self.update()
            return
        self._an.setStartValue(self.h)
        self._an.setEndValue(to)
        self._an.start()

    def enterEvent(self, e):
        self._go(1.0)

    def leaveEvent(self, e):
        self._go(0.0)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0, T.panel_top)
        g.setColorAt(1, T.panel_bot)
        p.setBrush(g)
        p.setPen(QPen(T.ac_a(0.30 + 0.45 * self.h), 1.5))
        p.drawRoundedRect(r, 20, 20)
        if self.h > 0.01:                                         # soft hover glow
            p.setBrush(T.ac_a(0.10 * self.h))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(r, 20, 20)
        c = QRectF(r.left() + 18, r.center().y() - 26, 52, 52)    # icon bubble
        p.setBrush(T.ac_a(0.28 + 0.2 * self.h))
        p.setPen(QPen(T.ac_a(0.7), 1.2))
        p.drawEllipse(c)
        draw_icon(p, self.ic, c.adjusted(13, 13, -13, -13), "#ffffff")
        tx = c.right() + 16
        tw = r.right() - 40 - tx
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(17, 700))
        p.drawText(QRectF(tx, r.top() + 20, tw, 26), Qt.AlignmentFlag.AlignVCenter, self.title)
        f = mkfont(12.5, 400)
        p.setFont(f)
        p.setPen(white(170))
        txt = QFontMetrics(f).elidedText(self.summary, Qt.TextElideMode.ElideRight, int(tw))
        p.drawText(QRectF(tx, r.top() + 50, tw, 24), Qt.AlignmentFlag.AlignVCenter, txt)
        draw_icon(p, "chevR", QRectF(r.right() - 34 + 4 * self.h, r.center().y() - 11, 22, 22), "#ffffff")


class ThemeCard(QAbstractButton):
    """A theme drawn as a tiny preview of the launcher in that theme's colors."""
    W, H = 214, 136

    def __init__(self, key, parent=None):
        super().__init__(parent)
        self.key, self.h = key, 0.0
        self.setCheckable(True)
        self.setFixedSize(self.W, self.H)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._an = _ease(self)
        self._an.valueChanged.connect(self._set)

    def _set(self, v):
        self.h = float(v)
        self.update()

    def _go(self, to):
        self._an.stop()
        if not T.anim_on:
            self.h = to
            self.update()
            return
        self._an.setStartValue(self.h)
        self._an.setEndValue(to)
        self._an.start()

    def enterEvent(self, e):
        self._go(1.0)

    def leaveEvent(self, e):
        self._go(0.0)

    def paintEvent(self, _e):
        name, ac, ac2, base, onac = THEMES[self.key]
        cac, cac2, cbase = QColor(ac), QColor(ac2), QColor(base)
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(3, 3, -3, -3)
        path = QPainterPath()
        path.addRoundedRect(r, 18, 18)
        p.save()
        p.setClipPath(path)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, mix(cbase, cac, 0.30))
        g.setColorAt(1, cbase)
        p.fillRect(r, QBrush(g))
        glow = QRadialGradient(r.right() - 20, r.top() + 10, r.width() * 0.75)
        glow.setColorAt(0, QColor(cac.red(), cac.green(), cac.blue(), int(110 + 60 * self.h)))
        glow.setColorAt(1, QColor(cac.red(), cac.green(), cac.blue(), 0))
        p.fillRect(r, QBrush(glow))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(white(70))                                      # top bar of the mini launcher
        p.drawRoundedRect(QRectF(r.left() + 14, r.top() + 14, 74, 8), 4, 4)
        p.setBrush(white(40))
        p.drawEllipse(QRectF(r.right() - 30, r.top() + 12, 12, 12))
        for i in range(3):                                         # three mini game tiles, the middle one selected
            t = QRectF(r.left() + 14 + i * 46, r.top() + 36, 38, 38)
            if i == 1:
                p.setBrush(cac)
                p.setPen(QPen(cac2, 2))
            else:
                p.setBrush(white(34))
                p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(t, 9, 9)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cac)                                            # mini Play button
        p.drawRoundedRect(QRectF(r.right() - 64, r.bottom() - 36, 50, 20), 10, 10)
        p.setBrush(QColor(onac))
        p.drawRoundedRect(QRectF(r.right() - 46, r.bottom() - 29, 14, 6), 3, 3)
        p.restore()
        p.setFont(mkfont(14, 700))
        p.setPen(QColor("#ffffff"))
        p.drawText(QRectF(r.left() + 14, r.bottom() - 38, r.width() - 90, 24), Qt.AlignmentFlag.AlignVCenter, _t(name))
        on = self.isChecked()
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(cac2, 2.6) if on else QPen(white(int(36 + 70 * self.h)), 1.4))
        p.drawRoundedRect(r, 18, 18)
        if on:                                                     # check badge
            b = QRectF(r.right() - 30, r.bottom() - 62, 22, 22)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(cac2)
            p.drawEllipse(b)
            draw_icon(p, "check", b.adjusted(4, 4, -4, -4), onac)


class AnimCard(QAbstractButton):
    """One animation style: name, short description and a dot that moves the way that style moves (on hover / click)."""

    def __init__(self, key, parent=None):
        super().__init__(parent)
        self.key, self.t, self.h = key, 0.0, 0.0
        self.setCheckable(True)
        self.setFixedHeight(88)
        self.setMaximumWidth(760)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._demo = QVariantAnimation(self)                       # preview: uses THIS style's own speed and curve
        self._demo.valueChanged.connect(self._dot)
        T.changed.connect(self.update)

    def _dot(self, v):
        self.t = float(v)
        self.update()

    def play(self):
        pr = ANIMS[self.key]
        self._demo.stop()
        if pr["speed"] <= 0:
            self.t = 1.0
            self.update()
            return
        self._demo.setDuration(int(1000 * pr["speed"]))
        self._demo.setEasingCurve(T.make_curve(pr["main"]))
        self._demo.setStartValue(0.0)
        self._demo.setEndValue(1.0)
        self._demo.start()

    def enterEvent(self, e):
        self.h = 1.0
        self.update()
        self.play()

    def leaveEvent(self, e):
        self.h = 0.0
        self.update()

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        self.play()

    def paintEvent(self, _e):
        pr = ANIMS[self.key]
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        on = self.isChecked()
        p.setBrush(T.ac_a(0.22) if on else white(int(14 + 12 * self.h)))
        p.setPen(QPen(T.ac2 if on else white(34), 2.2 if on else 1.3))
        p.drawRoundedRect(r, 18, 18)
        p.setPen(QColor("#ffffff"))
        p.setFont(mkfont(17, 700))
        p.drawText(QRectF(r.left() + 22, r.top() + 14, r.width() - 330, 28), Qt.AlignmentFlag.AlignVCenter, _t(pr["name"]))
        f = mkfont(13, 400)
        p.setFont(f)
        p.setPen(white(165))
        txt = QFontMetrics(f).elidedText(_t(pr["hint"]), Qt.TextElideMode.ElideRight, int(r.width() - 330))
        p.drawText(QRectF(r.left() + 22, r.top() + 44, r.width() - 330, 26), Qt.AlignmentFlag.AlignVCenter, txt)
        x0, x1, y = r.right() - 270, r.right() - 78, r.center().y()   # the moving dot
        p.setPen(QPen(white(60), 4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawLine(QPointF(x0, y), QPointF(x1, y))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(T.ac2)
        d = x0 + (x1 - x0) * self.t
        p.drawEllipse(QRectF(d - 9, y - 9, 18, 18))
        if on:
            b = QRectF(r.right() - 52, y - 15, 30, 30)
            p.setBrush(T.ac)
            p.drawEllipse(b)
            draw_icon(p, "check", b.adjusted(6, 6, -6, -6), T.onac.name())


# ----------------------------------------------------------------------------- the page
class SettingsPage(QWidget):
    go = Signal(str)             # switch category ("home" = overview)
    saved = Signal(str)          # toast text
    flagged = Signal(str)        # a trophy flag ("theme", "sound")
    lang_changed = Signal(str)
    restored = Signal(int)       # games were put back from a backup

    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.be = backend
        self.scroll = SmoothScroll(self)
        self.inner = QWidget()
        self.lay = QVBoxLayout(self.inner)
        self.lay.setContentsMargins(8, 6, 40, 40)
        self.lay.setSpacing(0)
        self.scroll.setWidget(self.inner)
        self.sub, self._built = "home", False
        self.fx = PageFx(self)
        self._persist = QTimer(self)                 # writes the look settings shortly after the last change
        self._persist.setSingleShot(True)
        self._persist.setInterval(350)
        self._persist.timeout.connect(self._flush)
        self._confirm = QTimer(self)                 # "click again to restore" expires
        self._confirm.setSingleShot(True)
        self._confirm.setInterval(4000)
        self._confirm.timeout.connect(self._unconfirm)
        self.b_restore = None

    def resizeEvent(self, e):
        self.scroll.setGeometry(0, 0, self.width(), self.height())

    # ------------------------------------------------------------------ helpers
    def _clear(self):
        self.b_restore = None
        while self.lay.count():
            it = self.lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
            elif it.layout():
                self._drop(it.layout())

    def _drop(self, lay):
        while lay.count():
            it = lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
            elif it.layout():
                self._drop(it.layout())

    def _head(self, ic, title, hint=""):
        if self.sub != "home":
            back = ClickLabel("‹  Settings")
            back.clicked.connect(lambda: self.go.emit("home"))
            self.lay.addWidget(back, 0, Qt.AlignmentFlag.AlignLeft)
            self.lay.addSpacing(12)
        row = QHBoxLayout()
        row.setSpacing(12)
        i = QLabel()
        i.setPixmap(icon(ic, 30, "#ffffff"))
        row.addWidget(i)
        row.addWidget(label(title, 27, 700))
        row.addStretch(1)
        self.lay.addLayout(row)
        if hint:
            self.lay.addSpacing(8)
            self.lay.addWidget(label(hint, 14, 400, wrap=True, alpha=0.72))
        self.lay.addSpacing(20)

    def _panel(self, width=760):
        panel = Panel(radius=22, border=0.3)
        panel.setMaximumWidth(width)
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(30, 24, 30, 10)
        pl.setSpacing(0)
        self.lay.addWidget(panel)
        self.lay.addSpacing(18)
        return pl

    @staticmethod
    def _sec(pl, text, first=False):
        if not first:
            pl.addSpacing(8)
        pl.addWidget(label(text.upper(), 12.5, 700, alpha=0.6))
        pl.addSpacing(12)

    @staticmethod
    def _switch(pl, title, hint, on, fn):
        row = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(3)
        col.addWidget(label(title, 15, 600, wrap=True))
        if hint:
            col.addWidget(label(hint, 12.5, 400, wrap=True, alpha=0.62))
        row.addLayout(col, 1)
        row.addSpacing(16)
        sw = Switch(on)
        sw.toggled.connect(fn)
        row.addWidget(sw, 0, Qt.AlignmentFlag.AlignVCenter)
        pl.addLayout(row)
        pl.addSpacing(16)
        return sw

    @staticmethod
    def _slider(pl, title, lo, hi, val, fn):
        row = QHBoxLayout()
        row.setSpacing(14)
        row.addWidget(label(title, 15, 600), 1)
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(lo, hi)
        s.setValue(int(round(float(val) * 100)))
        s.setFixedWidth(220)
        s.valueChanged.connect(fn)
        row.addWidget(s)
        pl.addLayout(row)
        pl.addSpacing(16)

    # ------------------------------------------------------------------ showing a category
    def show_sub(self, sub, settings, force=False):
        valid = {k for k, _i, _t2 in SIDE_ITEMS}
        sub = sub if sub in valid else "home"
        if sub == self.sub and self._built and sub != "home" and not force:
            return                                   # the data file changed on disk: do not rebuild (it would reset sliders/typing)
        changed = sub != self.sub or not self._built
        self.sub, self._built = sub, True
        self._clear()
        getattr(self, "_p_" + sub)(settings or {})
        self.lay.addStretch(1)
        self.scroll.scroll_to(0, instant=True)
        if changed and sub != "home":
            self.fx.play(self.scroll, "fade")

    # ------------------------------------------------------------------ overview
    def _p_home(self, st):
        self._head("gear", "Settings", "Pick a section. Everything is saved the moment you change it.")
        flow = Flow(gap=16)
        flow.setMaximumWidth(1060)
        for key, ic, title, _d in CATS:
            c = CatCard(ic, title, self._summary(key, st))
            c.clicked.connect(lambda _=False, k=key: self.go.emit(k))
            flow.add(c)
        self.lay.addWidget(flow)

    def _summary(self, key, st):
        on, off = _t("On"), _t("Off")
        if key == "themes":
            return _t(THEMES[T.prefs["theme"]][0]) + " · " + _t("%d themes" % len(THEMES))
        if key == "anim":
            return _t(ANIMS[T.anim_key]["name"]) + " · " + _t("%d styles" % len(ANIMS))
        if key == "display":
            lang = "العربية" if T.prefs.get("lang") == "ar" else "English"
            return lang + " · " + (_t("24-hour clock") if T.prefs.get("clock24") else _t("12-hour clock"))
        if key == "play":
            return _t("Play time") + ": " + (on if st.get("track_play") else off) + " · " + _t("Pop-ups") + ": " + (on if T.prefs.get("popups") else off)
        if key == "steam":
            return _t("Connected") if (st.get("steam_key") and st.get("steam_id")) else _t("Not set up")
        if key == "data":
            try:
                info = self.be.data_info()
                return _t("%d games · %d backups" % (max(0, info["games"]), len(info["backups"])))
            except Exception:
                return _t("Backups of your games list")
        return ""

    # ------------------------------------------------------------------ themes
    def _p_themes(self, st):
        self._head("palette", "Themes", "Tap a theme to use it. The whole launcher changes color at once.")
        flow = Flow(gap=16)
        flow.setMaximumWidth(1060)
        self.cards = {}
        for key in THEMES:
            c = ThemeCard(key)
            c.setChecked(T.prefs["theme"] == key)
            c.clicked.connect(lambda _=False, k=key: self._theme(k))
            self.cards[key] = c
            flow.add(c)
        self.lay.addWidget(flow)

    def _theme(self, key):
        for k, c in self.cards.items():
            c.setChecked(k == key)
        self._ui("theme", key)
        self.flagged.emit("theme")

    # ------------------------------------------------------------------ animations
    def _p_anim(self, st):
        self._head("wand", "Animations", "Choose how the launcher moves. Hover a style to see it move; click to use it.")
        self.acards = {}
        for key in ANIMS:
            c = AnimCard(key)
            c.setChecked(T.anim_key == key)
            c.clicked.connect(lambda _=False, k=key: self._anim(k))
            self.acards[key] = c
            self.lay.addWidget(c)
            self.lay.addSpacing(12)
        self.lay.addWidget(label("The style changes how pages come in, how the menu highlight glides, scrolling, "
                                 "switches, and the background fade. “Off” turns all of it off.",
                                 12.5, 400, wrap=True, alpha=0.6))

    def _anim(self, key):
        for k, c in self.acards.items():
            c.setChecked(k == key)
        self._ui("anim", key)
        self.fx.play(self.scroll, T.page_style if T.page_style != "none" else "fade")   # shows the new style right away

    # ------------------------------------------------------------------ display & sound
    def _p_display(self, st):
        self._head("monitor", "Display & Sound")
        pl = self._panel()
        self._sec(pl, "Language", True)
        row = QHBoxLayout()
        row.setSpacing(10)
        self.langs = {}
        for code, name in (("en", "English"), ("ar", "العربية")):
            b = LangPill(name)
            b.setChecked(T.prefs.get("lang", "en") == code)
            b.clicked.connect(lambda _=False, c=code: self._lang(c))
            self.langs[code] = b
            row.addWidget(b)
        row.addStretch(1)
        pl.addLayout(row)
        pl.addSpacing(18)
        self._sec(pl, "Screen")
        self._slider(pl, "Background brightness", 40, 110, T.prefs["dim"], lambda v: self._ui("dim", v / 100))
        self._switch(pl, "Floating particles", "Small lights drifting in the background.", bool(T.prefs["particles"]),
                     lambda v: self._ui("particles", v))
        self._switch(pl, "24-hour clock", "", bool(T.prefs["clock24"]), lambda v: self._ui("clock24", v))
        self._sec(pl, "Sound")
        self._switch(pl, "Sound effects", "", bool(T.prefs["sfx"]), self._sfx)
        self._slider(pl, "Volume", 10, 100, T.prefs["vol"], lambda v: self._ui("vol", v / 100))

    def _lang(self, code):
        if T.prefs.get("lang", "en") == code:
            self.langs[code].setChecked(True)
            return
        for k, b in self.langs.items():
            b.setChecked(k == code)
        self._ui("lang", code)
        self._flush()
        self.lang_changed.emit(code)

    def _sfx(self, v):
        self.flagged.emit("sound")
        self._ui("sfx", v)
        from .sfx import sfx
        sfx.ok()

    # ------------------------------------------------------------------ games & trophies
    def _p_play(self, st):
        self._head("play", "Games & Trophies")
        pl = self._panel()
        self._sec(pl, "When I start a game", True)
        self._switch(pl, "Open the launcher again when I close the game",
                     "On: the launcher window closes while you play and a tiny hidden helper with no window waits in the "
                     "background. When you close the game the launcher opens again by itself. "
                     "Off: the launcher closes completely and stays closed.",
                     bool(st.get("reopen_after")), lambda v: self._bset("reopen_after", v))
        self._switch(pl, "Count play time",
                     "Uses the same tiny hidden helper while the game is open. Needed for play-time trophies and the Stats page.",
                     bool(st.get("track_play")), lambda v: self._bset("track_play", v))
        pl.addWidget(label("With both options off, nothing of the launcher keeps running while you play. "
                           "With them on, only the tiny helper does.", 12.5, 400, wrap=True, alpha=0.62))
        pl.addSpacing(20)
        self._sec(pl, "Trophies")
        self._switch(pl, "Show a pop-up when I earn a trophy", "", bool(T.prefs.get("popups")), lambda v: self._ui("popups", v))
        self._switch(pl, "Play a sound with the pop-up", "", bool(T.prefs.get("popsfx")), self._popsfx)

    def _popsfx(self, v):
        self._ui("popsfx", v)
        if v:
            from .sfx import sfx
            sfx.play("pop", force=True)

    def _bset(self, key, v):
        try:
            self.be.set_setting(**{key: bool(v)})
        except Exception as ex:
            self.saved.emit(str(ex))

    # ------------------------------------------------------------------ steam
    def _p_steam(self, st):
        self._head("steam", "Steam", "Optional. Only needed to see your real achievements for games you own on Steam.")
        pl = self._panel()
        pl.addWidget(label("Steam API key", 13.5, 400, alpha=0.75))
        pl.addSpacing(6)
        self.e_key = QLineEdit(st.get("steam_key", ""))
        self.e_key.setPlaceholderText(_t("32 characters"))
        pl.addWidget(self.e_key)
        pl.addSpacing(16)
        pl.addWidget(label("Your SteamID64", 13.5, 400, alpha=0.75))
        pl.addSpacing(6)
        self.e_id = QLineEdit(st.get("steam_id", ""))
        self.e_id.setPlaceholderText(_t("17 digits"))
        pl.addWidget(self.e_id)
        pl.addSpacing(10)
        pl.addWidget(label("Get a free key at steamcommunity.com/dev/apikey and find your SteamID64 at steamid.io. "
                           "Your Steam profile's “Game details” must be Public.", 12.5, 400, wrap=True, alpha=0.62))
        pl.addSpacing(18)
        row = QHBoxLayout()
        row.addStretch(1)
        b = Btn("Save Steam details", "", "primary")
        b.clicked.connect(self._save_steam)
        row.addWidget(b)
        pl.addLayout(row)
        pl.addSpacing(18)

    def _save_steam(self):
        try:
            self.be.set_setting(steam_key=self.e_key.text().strip(), steam_id=self.e_id.text().strip())
            self.saved.emit("Saved")
        except Exception as ex:
            self.saved.emit(str(ex))

    # ------------------------------------------------------------------ your data
    def _p_data(self, st):
        self._head("shield", "Your data", "Your games list is backed up automatically every time it changes, so an update or a crash can't wipe it.")
        pl = self._panel()
        try:
            info = self.be.data_info()
        except Exception as ex:
            info = {"path": "", "games": -1, "backups": []}
            self.saved.emit(str(ex))
        self._sec(pl, "Library", True)
        n = info["games"]
        pl.addWidget(label(_t("%d games" % n) if n >= 0 else "The games file could not be read", 16, 600))
        pl.addSpacing(6)
        pl.addWidget(label(info["path"], 12.5, 400, wrap=True, alpha=0.62))
        pl.addSpacing(18)
        self._sec(pl, "Backups")
        bk = info["backups"]
        if bk:
            when = time.strftime("%d %b %Y  %H:%M", time.localtime(bk[0][0]))
            pl.addWidget(label(_t("%d backups" % len(bk)) + "  ·  " + _t("newest") + ": " + when + " (" + _t("%d games" % bk[0][1]) + ")",
                               14, 400, wrap=True, alpha=0.85))
        else:
            pl.addWidget(label("No backups yet. One is made the next time your library changes.", 14, 400, wrap=True, alpha=0.85))
        pl.addSpacing(16)
        row = QHBoxLayout()
        row.setSpacing(12)
        b1 = Btn("Back up now", "", "ghost")
        b1.clicked.connect(self._backup)
        self.b_restore = Btn("Restore last backup", "", "ghost")
        self.b_restore.clicked.connect(self._restore)
        b3 = Btn("Open data folder", "", "ghost")
        b3.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(info["path"])))
        for b in (b1, self.b_restore, b3):
            row.addWidget(b)
        row.addStretch(1)
        pl.addLayout(row)
        pl.addSpacing(10)
        pl.addWidget(label("Restore puts back the newest backup that has games. Your current file is kept in the backups folder, never deleted.",
                           12.5, 400, wrap=True, alpha=0.62))
        pl.addSpacing(18)

    def _backup(self):
        try:
            ok = self.be.backup_now()
            self.saved.emit("Backup saved" if ok else "Nothing to back up yet")
            self.show_sub("data", self.be.settings(), force=True)
        except Exception as ex:
            self.saved.emit(str(ex))

    def _restore(self):
        if self.b_restore is None:
            return
        if not self._confirm.isActive():                 # first click: ask for a second one
            self.b_restore.set_label("Click again to restore")
            self._confirm.start()
            return
        self._confirm.stop()
        try:
            n = self.be.restore_backup()
        except Exception as ex:
            self.saved.emit(str(ex))
            return
        if n:
            self.restored.emit(n)
            self.show_sub("data", self.be.settings(), force=True)
        else:
            self._unconfirm()
            self.saved.emit("No backup with games was found.")

    def _unconfirm(self):
        if self.b_restore is not None:
            try:
                self.b_restore.set_label("Restore last backup")
            except RuntimeError:                         # the page was rebuilt
                self.b_restore = None

    # ------------------------------------------------------------------ saving the look settings
    def _ui(self, key, value):
        T.set(key, value)
        self._persist.start()

    def _flush(self):
        try:
            self.be.set_ui(T.prefs)
        except Exception as ex:
            self.saved.emit(str(ex))

