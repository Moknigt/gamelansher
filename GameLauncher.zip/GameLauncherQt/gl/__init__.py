"""Game Launcher (Qt version)."""
