"""The main window: owns the state (view, tabs, search, selection) and wires every page together."""
from PySide6.QtCore import QRectF, Qt, QTime, QTimer, QVariantAnimation, QEasingCurve, Signal
from PySide6.QtGui import QPainter, QPen
from PySide6.QtWidgets import (QApplication, QComboBox, QFileDialog, QHBoxLayout, QLineEdit, QSizePolicy, QVBoxLayout,
                               QWidget)

from . import dialogs, steam
from .backend import NotYet
from .worker import run_async
from .gamepad import Gamepad
from .background import Background
from .drawer import Drawer
from .icons import draw_icon
from .pages_ach import AchPage
from .pages_home import HomePage
from .pages_library import LibraryPage
from .sfx import sfx
from .theme import T
from .i18n import tr as _t
from .widgets import (AA, Btn, Busy, LogoMark, NavGroup, Panel, Toast, TrophyPop, label, mkfont, white)

APP_NAME = "Game Launcher"
TABS = [("home", "home", "Home"), ("lib", "lib", "Library"), ("fav", "heart", "Favorites"), ("ach", "trophy", "Achievements")]
SIDE = {
    "home": ("homeF", [("all", "gamepad", "All Games"), ("recent", "clock", "Recently Played"),
                       ("fav", "heart", "Favorites"), ("most", "stats", "Most Played")], True),
    "lib": ("libTab", [("all", "gamepad", "All Games"), ("inst", "check", "Installed"),
                       ("most", "stats", "Most Played"), ("recent", "clock", "Recently Added")], True),
    "fav": ("favTab", [("all", "heart", "All Favorites"), ("recent", "clock", "Recently Played"),
                       ("most", "stats", "Most Played")], False),
    "ach": ("achSub", [("overview", "trophy", "Achievements"), ("games", "gamepad", "All Games"),
                       ("stats", "stats", "Stats"), ("settings", "gear", "Settings")], False),
}
FAIL = object()      # returned by MainWindow.safe() when the call failed (its message was shown)
TOPBAR, SIDE_X, SIDE_Y, SIDE_W, CONTENT_X, FOOT_H = 78, 20, 92, 214, 252, 48


class SearchEdit(QLineEdit):
    escaped = Signal()
    leave = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setPlaceholderText(_t("Search games"))
        self.setFixedWidth(0)
        self.setVisible(False)
        self.on = False
        self._an = QVariantAnimation(self)
        self._an.setDuration(260)
        self._an.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._an.valueChanged.connect(lambda v: self.setFixedWidth(int(v)))
        self._an.finished.connect(self._fin)

    def _fin(self):
        if not self.on:
            self.setVisible(False)

    def toggle(self, on):
        self.on = on
        self._an.stop()
        if on:
            self.setVisible(True)
        if not T.anim_on:
            self.setFixedWidth(230 if on else 0)
            self.setVisible(on)
            return
        self._an.setStartValue(self.width())
        self._an.setEndValue(230 if on else 0)
        self._an.start()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.escaped.emit()
        elif e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Down):
            self.leave.emit()
        else:
            super().keyPressEvent(e)


class Footer(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.count = ""
        T.changed.connect(self.update)

    def set_count(self, t):
        self.count = t
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        x = 6
        p.setFont(mkfont(14, 400))
        for ic, text in (("dpad", "Navigate"), ("cross_btn", "Select"), ("circ", "Back")):
            c = QRectF(x, self.height() / 2 - 14, 28, 28)
            p.setBrush(white(30))
            p.setPen(QPen(white(60), 1))
            p.drawEllipse(c)
            draw_icon(p, ic, c.adjusted(6, 6, -6, -6), "#ffffff")
            p.setPen(white(205))
            tw = p.fontMetrics().horizontalAdvance(text)
            p.drawText(QRectF(x + 38, 0, tw + 6, self.height()), Qt.AlignmentFlag.AlignVCenter, _t(text))
            x += 38 + tw + 30
        if self.count:
            p.setPen(white(205))
            p.setFont(mkfont(14, 600))
            p.drawText(QRectF(0, 0, self.width(), self.height()), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, _t(self.count))


class MainWindow(QWidget):
    def __init__(self, backend):
        super().__init__()
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        self.setWindowTitle(APP_NAME)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumSize(1000, 620)
        self.be = backend
        # state (mirrors the old JS)
        self.view, self.homeF, self.libTab, self.favTab, self.achSub = "home", "all", "all", "all", "overview"
        self.sort, self.q, self.selId, self.gd = "name", "", None, False
        self.games, self.settings, self._sig, self._mt = [], {}, None, 0.0

        self.bg = Background(self)
        # ---- top bar
        self.top = QWidget(self)
        tl = QHBoxLayout(self.top)
        tl.setContentsMargins(28, 13, 28, 13)
        tl.setSpacing(16)
        self.tabs = NavGroup("tab")
        self.tabs.set_items(TABS, "home")
        self.tabs.selected.connect(self._tab)
        tl.addWidget(self.tabs)
        tl.addStretch(1)
        self.clock = label("", 17, 600, alpha=0.9)
        tl.addWidget(self.clock)
        self.search = SearchEdit()
        self.search.setFixedHeight(46)
        self.search.textChanged.connect(lambda t: self.set_q(t, True))
        self.search.escaped.connect(self.back)
        self.search.leave.connect(self.setFocus)
        tl.addWidget(self.search)
        self.b_search = Btn("", "search", "icon", 46)
        self.b_search.setToolTip(_t("Search ( / )"))
        self.b_search.clicked.connect(self._toggle_search)
        self.b_set = Btn("", "gear", "icon", 46)
        self.b_set.setToolTip(_t("Settings"))
        self.b_set.clicked.connect(self.open_settings)
        tl.addWidget(self.b_search)
        tl.addWidget(self.b_set)
        # ---- side panel + exit
        self.side_panel = Panel(self, radius=24)
        self.side = NavGroup("side", self.side_panel)
        self.side.move(12, 12)
        self.side.selected.connect(self._side)
        self.side.add_clicked.connect(self.add_game)
        self.b_exit = Btn("", "power", "danger", 50, parent=self)
        self.b_exit.setToolTip(_t("Exit"))
        self.b_exit.clicked.connect(self.confirm_exit)
        # ---- pages
        self.content = QWidget(self)
        self.home = HomePage(self.content)
        self.lib = LibraryPage(self.content)
        self.ach = AchPage(self.be, self.content)
        self.foot = Footer(self)
        # ---- overlays (z-order: drawer < modal < busy < toast < pop)
        self.drawer = Drawer(self)
        self.modal = dialogs.ModalHost(self)
        self.busy = Busy(self)
        self.toast = Toast(self)
        self.pop = TrophyPop(self)
        self._wire()

        self.clock_t = QTimer(self)
        self.clock_t.timeout.connect(self.tick)
        self.clock_t.start(15000)
        self.poll_t = QTimer(self)
        self.poll_t.timeout.connect(self._poll)
        self.poll_t.start(4000)
        self.tick()

    # ------------------------------------------------------------------ wiring
    def _wire(self):
        h = self.home
        h.picked.connect(self._pick_click)
        h.activated.connect(lambda _g: self.play())
        h.stepped.connect(self.move)
        h.play.connect(self.play)
        h.fav.connect(self.toggle_fav)
        h.trophies.connect(self.open_ach)
        h.more.connect(self.more_menu)
        h.add.connect(self.add_game)
        L = self.lib
        L.picked.connect(self._grid_click)
        L.sort_changed.connect(self._sort)
        d = L.detail
        d.back.connect(self.close_gd)
        d.prev.connect(lambda: self.move(-1))
        d.next.connect(lambda: self.move(1))
        d.play.connect(self.play)
        d.fav.connect(self.toggle_fav)
        d.trophies.connect(self.open_ach)
        d.more.connect(self.more_menu)
        self.ach.open_game.connect(self._ach_open)
        self.ach.go.connect(self._ach_go)
        self.ach.saved.connect(self.say)
        self.drawer.refresh.connect(self.open_ach)
        self.drawer.toggle.connect(self._tick_real)
        self.drawer.closed.connect(self.setFocus)
        self.modal.closed.connect(self.setFocus)
        self.be.new_trophies.connect(self.pop.add)
        self.pad = Gamepad(self)
        self.pad.pressed.connect(self.pad_press)
        self.pad.start()
        T.changed.connect(self._theme_changed)

    def say(self, text):
        self.toast.say(text)

    def safe(self, fn):
        try:
            return fn()
        except NotYet as ex:
            self.say(str(ex))
        except Exception as ex:
            self.say(str(ex) or ex.__class__.__name__)
        return FAIL

    # ------------------------------------------------------------------ layout
    def resizeEvent(self, e):
        w, h = self.width(), self.height()
        self.bg.setGeometry(0, 0, w, h)
        self.bg.lower()
        self.top.setGeometry(0, 0, w, TOPBAR)
        self._fit_side()
        self.b_exit.move(SIDE_X, h - 72)
        cw, ch = max(100, w - CONTENT_X), max(100, h - TOPBAR - FOOT_H)
        self.content.setGeometry(CONTENT_X, TOPBAR, cw, ch)
        for pg in (self.home, self.lib, self.ach):
            pg.setGeometry(0, 0, cw, ch)
        self.foot.setGeometry(CONTENT_X, h - FOOT_H, cw - 30, FOOT_H - 8)
        for ov in (self.drawer, self.modal):
            if ov.isVisible():
                ov.setGeometry(0, 0, w, h)
        if self.busy.isVisible():
            self.busy.setGeometry(0, 0, w, h)

    def _fit_side(self):
        self.side_panel.setGeometry(SIDE_X, SIDE_Y, SIDE_W, self.side.height() + 24)

    def _theme_changed(self):
        self.update()
        self.tick()

    # ------------------------------------------------------------------ lists
    def sel(self):
        for g in self.games:
            if g["id"] == self.selId:
                return g
        return None

    def is_grid(self):
        return self.view in ("lib", "fav")

    def home_list(self):
        def base(g):
            return (0 if g.get("fav") else 1, -(g.get("last_played") or 0), g.get("added") or 0)
        l = list(self.games)
        if self.homeF == "recent":
            return sorted((g for g in l if g.get("last_played")), key=lambda g: -g["last_played"])
        if self.homeF == "fav":
            return sorted((g for g in l if g.get("fav")), key=base)
        if self.homeF == "most":
            return sorted((g for g in l if g.get("playtime", 0) > 0), key=lambda g: -g["playtime"])
        return sorted(l, key=base)

    def lib_list(self):
        s = self.q.lower()
        so = self.sort
        l = [g for g in self.games if not s or s in g["name"].lower()]
        if self.view == "fav":
            l = [g for g in l if g.get("fav")]
            if self.favTab == "recent":
                so, l = "recent", [g for g in l if g.get("last_played")]
            if self.favTab == "most":
                so, l = "played", [g for g in l if g.get("playtime", 0) > 0]
        else:
            if self.libTab == "inst":
                l = [g for g in l if g.get("installed", True)]
            if self.libTab == "most":
                so, l = "played", [g for g in l if g.get("playtime", 0) > 0]
            if self.libTab == "recent":
                so = "added"
        keys = {"name": lambda g: g["name"].lower(), "recent": lambda g: -(g.get("last_played") or 0),
                "played": lambda g: -(g.get("playtime") or 0), "added": lambda g: -(g.get("added") or 0)}
        return sorted(l, key=keys[so])

    def cur(self):
        if self.view == "home":
            return self.home_list()
        return [] if self.view == "ach" else self.lib_list()

    # ------------------------------------------------------------------ rendering
    def reload(self, keep=None, first=False, force=False):
        self.games = self.be.games()
        self.settings = self.be.settings()
        if first:
            T.load(self.settings.get("ui"))
        if keep:
            self.selId = keep
        sig = repr([(g["id"], g["name"], g.get("fav"), g.get("cover_path"), g.get("hero_path"), g.get("logo_path"),
                     g.get("installed"), g.get("playtime"), g.get("last_played"), g.get("tro_unlocked"),
                     g.get("launches"), g.get("desc")) for g in self.games])
        if sig != self._sig or keep or force or first:
            self._sig = sig
            self.render(first)
        self._mt = self.be.db_mtime()

    def render_side(self):
        attr, items, add = SIDE[self.view]
        self.side.set_items(items, getattr(self, attr), add, 190)
        self._fit_side()

    def update_bg(self):
        g = self.sel() or (self.games[0] if (self.view == "ach" and self.games) else None)
        self.bg.set_image((g.get("hero_path") or g.get("cover_path")) if g else "")
        mode = "ach" if self.view == "ach" else "game" if self.gd else "home" if self.view == "home" else "lib"
        self.bg.set_mode(mode)

    def render(self, instant=False):
        v = self.view
        if v == "lib":
            self.be.flag("lib")
        if not self.is_grid():
            self.gd = False
        self.home.setVisible(v == "home")
        self.lib.setVisible(self.is_grid())
        self.ach.setVisible(v == "ach")
        self.foot.setVisible(v != "ach")
        self.tabs.set_current(v, instant)
        self.render_side()
        if v == "ach":
            self.update_bg()
            self.ach.show_sub(self.achSub, self.games, self.settings)
            self.foot.set_count("")
            return
        l = self.cur()
        if not any(g["id"] == self.selId for g in l):
            self.selId = l[0]["id"] if l else None
        if v == "home":
            self.home.show_games(l, self.selId, welcome=not self.games)
        else:
            self._show_lib(l)
        self._gd_ui()
        self.update_bg()
        self.foot.set_count(f"{len(l)} Game" + ("" if len(l) == 1 else "s") if self.is_grid() else "")

    def _show_lib(self, l):
        fav = self.view == "fav"
        if self.q:
            title = f"Search: “{self.q}”"
        elif fav:
            title = {"all": "Favorites", "recent": "Recently Played", "most": "Most Played"}[self.favTab]
        else:
            title = {"all": "All Games", "inst": "Installed", "most": "Most Played", "recent": "Recently Added"}[self.libTab]
        can_sort = bool(self.q) or (self.favTab == "all" if fav else self.libTab in ("all", "inst"))
        empty = ("No games match your search." if self.q else
                 "No favorites here yet. Select a game and press F, or use the heart button." if fav else
                 "Nothing here yet.")
        self.lib.set_games(l, self.selId, title, can_sort, self.sort, empty)
        self.lib.select(self.selId) if self.selId else None

    def _gd_ui(self):
        """Shows the full-page game details (or the grid) according to `gd`."""
        if self.gd and self.sel() and self.is_grid():
            self.paint_gd()
        else:
            self.gd = False
            self.lib.detail.hide()
        self.lib.head.setVisible(not self.gd)
        self.lib.scroll.setVisible(not self.gd)

    def paint_gd(self):
        g, l = self.sel(), self.cur()
        if not g:
            return
        i = next((k for k, x in enumerate(l) if x["id"] == g["id"]), 0)
        self.lib.detail.show_game(g, i, len(l), "Favorites" if self.view == "fav" else "Library")
        self.lib.detail.show()
        self.lib.detail.raise_()

    # ------------------------------------------------------------------ navigation
    def _tab(self, key):
        sfx.move()
        self.go_view(key)

    def go_view(self, v):
        if v == self.view:
            return
        self.gd = False
        self.view = v
        self.render()

    def _side(self, key):
        sfx.move()
        self.gd = False
        setattr(self, SIDE[self.view][0], key)
        self.render()

    def _sort(self, key):
        self.sort = key
        self.render()
        self.setFocus()

    def _ach_go(self, sub):
        self.achSub = sub
        self.render()

    def _ach_open(self, gid):
        if not gid:
            self.open_all_ach()
        else:
            self.selId = gid
            self.open_ach()

    def pick(self, gid):
        self.selId = gid
        if self.view == "home":
            self.home.select(gid)
        elif self.is_grid():
            self.lib.select(gid)
        self.update_bg()
        if self.gd:
            self.paint_gd()

    def _pick_click(self, gid):
        sfx.move()
        self.pick(gid)

    def _grid_click(self, gid):
        self.pick(gid)
        self.open_gd()

    def move(self, d):
        l = self.cur()
        i = next((k for k, g in enumerate(l) if g["id"] == self.selId), -1)
        n = max(0, min(len(l) - 1, i + d))
        if n == i or not l:
            return
        sfx.move()
        self.pick(l[n]["id"])

    def open_gd(self):
        if not self.sel() or not self.is_grid():
            return
        self.gd = True
        sfx.ok()
        self._gd_ui()
        self.update_bg()

    def close_gd(self):
        self.gd = False
        sfx.move()
        self._gd_ui()
        if self.selId:
            self.lib.select(self.selId)
        self.update_bg()

    # ------------------------------------------------------------------ search
    def _toggle_search(self):
        on = not self.search.on
        self.search.toggle(on)
        if on:
            self.search.setFocus()
        else:
            self.set_q("")
            self.setFocus()

    def open_search(self):
        if not self.search.on:
            self.search.toggle(True)
        self.search.setFocus()

    def set_q(self, v, from_input=False):
        if v == self.q:
            return
        self.q = v
        if v:
            self.be.flag("search")
        if not from_input:
            self.search.blockSignals(True)
            self.search.setText(v)
            self.search.blockSignals(False)
        if v and not self.is_grid():
            self.view, self.libTab = "lib", "all"
        self.render()

    # ------------------------------------------------------------------ overlays
    def overlay_open(self):
        return self.modal.is_open() or self.drawer.is_open() or self.busy.isVisible()

    def close_all(self):
        self.drawer.close_()
        self.modal.close_()

    def back(self):
        if self.overlay_open():
            self.close_all()
        elif self.gd:
            self.close_gd()
        elif self.q:
            self.set_q("")
            self.search.toggle(False)
            self.setFocus()
        elif self.view != "home":
            self.go_view("home")
        else:
            self.setFocus()

    # ------------------------------------------------------------------ actions
    def toggle_fav(self):
        g = self.sel()
        if not g:
            return
        self.safe(lambda: self.be.toggle_fav(g["id"]))
        self.reload(g["id"])

    def play(self):
        g = self.sel()
        if not g:
            return
        sfx.ok()
        self.busy.start(f"Starting {g['name']}…")
        QTimer.singleShot(60, lambda: self._do_play(g["id"]))

    def _do_play(self, gid):
        try:
            self.be.play(gid)
        except Exception as ex:
            self.busy.stop()
            self.say(str(ex) or "Couldn't start the game.")

    def open_ach(self):
        g = self.sel()
        if not g:
            return
        sfx.open()
        gid = g["id"]
        self.busy.start("Loading trophies…")

        def done(r, err):
            self.busy.stop()
            cur = self.sel()
            if not cur or cur["id"] != gid:          # the user moved on while we were loading
                return
            if err is not None:
                self.drawer.show_error(g["name"], str(err))
            else:
                self.drawer.show_game(cur, r, bool(self.settings.get("track_play")))
        run_async(lambda: self.be.game_achievements(gid), done)

    def open_all_ach(self):
        sfx.open()
        try:
            self.drawer.show_launcher(self.be.launcher_trophies())
        except Exception as ex:
            self.drawer.show_error(dialogs.APP_NAME, str(ex))

    def _tick_real(self, ach_id):
        g = self.sel()
        if not g:
            return
        if self.safe(lambda: self.be.ach_toggle(g["id"], ach_id)) is not FAIL:
            self.reload(g["id"], force=True)
            self.open_ach()

    def more_menu(self):
        g = self.sel()
        if not g:
            return
        c = dialogs.MoreCard(g)
        c.fav.connect(lambda: (self.modal.close_(), self.toggle_fav()))
        c.ach.connect(lambda: (self.modal.close_(), self.open_ach()))
        c.edit.connect(lambda: (self.modal.close_(), self.open_edit()))
        sfx.open()
        self.modal.open_(c)

    def confirm_exit(self):
        c = dialogs.confirm_exit_card()
        c.stay.clicked.connect(self.modal.close_)
        c.yes.clicked.connect(QApplication.quit)
        sfx.open()
        self.modal.open_(c)

    def open_settings(self):
        self.be.flag("settings")
        c = dialogs.SettingsCard(self.be, self.be.flag)
        c.done.connect(self.modal.close_)
        c.lang_changed.connect(lambda _c: self.say("Restart the launcher to finish switching the language."))
        sfx.open()
        self.modal.open_(c)

    # ---- add
    def add_game(self):
        c = dialogs.add_game_card()
        c.cancel.clicked.connect(self.modal.close_)
        c.go.clicked.connect(lambda: (self.modal.close_(), QTimer.singleShot(0, self._choose_game)))
        sfx.open()
        self.modal.open_(c)

    def _choose_game(self):
        path, _ = QFileDialog.getOpenFileName(self, _t("Choose the game's file"), "",
                                              _t("Games (*.exe *.lnk *.bat *.cmd);;All files (*)"))
        self.setFocus()
        if not path:
            return
        self._add_details(path)

    def _add_details(self, path):
        """Step 2 of adding: name, picture from the internet yes/no, search by another name."""
        c = dialogs.AddDetailsCard(path, steam.best_guess(path))
        c.cancel.connect(self.modal.close_)

        def search(term):
            if not term.strip():
                return
            c.say("Searching…")

            def done(r, err):
                try:
                    if err is not None:
                        c.say(str(err) or "Search failed.")
                    else:
                        c.set_results(r.get("items", []))
                except RuntimeError:                  # the card was closed while searching
                    pass
            run_async(lambda: self.be.online_search(term), done)

        def go():
            name, online, use_name, item = c.e_name.text().strip(), c.sw_online.isChecked(), c.sw_name.isChecked(), c.item
            self.modal.close_()
            self.busy.start("Adding the game…")
            run_async(lambda: self.be.add_game(path, name or None, online, item, use_name), self._added)

        c.search.connect(search)
        c.pick.connect(c.chosen)
        c.add.connect(go)
        sfx.open()
        self.modal.open_(c)

    def _added(self, g, err):
        self.busy.stop()
        if err is not None:
            self.say(str(err) or err.__class__.__name__)
            return
        if self.view == "ach":
            self.view = "home"
        self.homeF, self.libTab = "all", "all"
        self.reload(g["id"], force=True)
        sfx.ok()
        self.say(g.get("note") or "Added " + g["name"])

    # ---- edit
    def open_edit(self):
        g = self.sel()
        if not g:
            return
        c = dialogs.EditCard(g)
        gid = g["id"]
        c.dismiss.connect(self.modal.close_)

        def save(name):
            self.safe(lambda: self.be.rename(gid, name))
            self.modal.close_()
            self.reload(gid, force=True)

        def search(term):
            if not term.strip():
                return
            c.say("Searching Steam, GOG and Wikipedia…")

            def done(r, err):
                try:
                    if err is not None:
                        c.say(str(err) or "Search failed.")
                    else:
                        c.set_results(r.get("items", []))
                except RuntimeError:                  # the card was closed while searching
                    pass
            run_async(lambda: self.be.online_search(term), done)

        def pick(item):
            use_name = c.sw_name.isChecked()
            self.busy.start("Getting the picture…")

            def done(_r, err):
                self.busy.stop()
                if err is not None:
                    self.say(str(err) or "Couldn't link this game.")
                    return
                self.modal.close_()
                self.reload(gid, force=True)
                self.say("Matched to " + item["name"])
            run_async(lambda: self.be.match_online(gid, item, use_name), done)

        def image():
            path, _ = QFileDialog.getOpenFileName(self, _t("Choose a background image"), "",
                                                  _t("Images (*.png *.jpg *.jpeg *.webp *.bmp);;All files (*)"))
            if not path:
                return
            if self.safe(lambda: self.be.set_custom_art(gid, path)) is FAIL:
                return
            self.modal.close_()
            self.reload(gid, force=True)
            self.say("Background changed")

        def steam_art():
            self.busy.start("Getting the Steam picture…")

            def done(_r, err):
                self.busy.stop()
                if err is not None:
                    self.say(str(err) or "Couldn't get the Steam picture.")
                    return
                self.modal.close_()
                self.reload(gid, force=True)
                self.say("Using the Steam picture")
            run_async(lambda: self.be.reset_art(gid), done)

        def remove():
            rc = dialogs.confirm_remove_card(g["name"])
            rc.no.clicked.connect(self.modal.close_)

            def go():
                self.safe(lambda: self.be.remove(gid))
                self.selId = None
                self.gd = False
                self.modal.close_()
                self.reload(force=True)
            rc.yes.clicked.connect(go)
            self.modal.open_(rc)

        c.save.connect(save)
        c.search.connect(search)
        c.pick.connect(pick)
        c.image.connect(image)
        c.steam_art.connect(steam_art)
        c.auto.connect(lambda on: self.safe(lambda: self.be.set_auto_art(gid, on)))
        c.remove.connect(remove)
        sfx.open()
        self.modal.open_(c)

    # ------------------------------------------------------------------ gamepad
    def pad_press(self, name):
        """Same mapping as the old version: A select, B back, Y achievements, LB/RB Home<->Library, dpad/stick move."""
        self.be.flag("pad")
        if name == "b":
            self.back()
            return
        if self.overlay_open():
            return
        g, grid = self.sel(), self.is_grid()
        if name in ("left", "right"):
            self.move(-1 if name == "left" else 1)
        elif name in ("up", "down"):
            if grid and not self.gd:
                self.move(self.lib.grid.cols() * (-1 if name == "up" else 1))
        elif name == "a":
            if self.view == "ach":
                return
            if grid and not self.gd:
                if g:
                    self.open_gd()
            else:
                self.play()
        elif name == "y":
            if g and self.view != "ach":
                self.open_ach()
        elif name == "tab":
            self.go_view("lib" if self.view == "home" else "home")

    # ------------------------------------------------------------------ keyboard
    def keyPressEvent(self, e):
        k = e.key()
        if k in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            self.be.flag("kbd")
        if k == Qt.Key.Key_Escape:
            self.back()
            return
        if self.overlay_open() or isinstance(self.focusWidget(), (QLineEdit, QComboBox)):
            super().keyPressEvent(e)
            return
        g, grid, t = self.sel(), self.is_grid(), e.text()
        handled = True
        if k == Qt.Key.Key_Right:
            self.move(1)
        elif k == Qt.Key.Key_Left:
            self.move(-1)
        elif k == Qt.Key.Key_Down:
            if grid and not self.gd:
                self.move(self.lib.grid.cols())
        elif k == Qt.Key.Key_Up:
            if grid and not self.gd:
                self.move(-self.lib.grid.cols())
        elif k in (Qt.Key.Key_Home, Qt.Key.Key_End):
            l = self.cur()
            if l:
                sfx.move()
                self.pick(l[0 if k == Qt.Key.Key_Home else -1]["id"])
        elif k in (Qt.Key.Key_PageDown, Qt.Key.Key_PageUp):
            self.move((1 if k == Qt.Key.Key_PageDown else -1) * (self.lib.grid.cols() * 3 if grid else 5))
        elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if self.view == "ach":
                pass
            elif grid and not self.gd:
                if g:
                    self.open_gd()
            else:
                self.play()
        elif t in ("a", "A") and g and self.view != "ach":
            self.open_ach()
        elif t in ("f", "F") and g and self.view != "ach":
            self.toggle_fav()
        elif t in ("l", "L"):
            self.go_view("lib" if self.view == "home" else "home")
        elif t == "/":
            self.open_search()
        elif t and t in "123456789" and self.view != "ach":
            l = self.cur()
            if int(t) - 1 < len(l):
                self.pick(l[int(t) - 1]["id"])
        else:
            handled = False
        if handled:
            e.accept()
        else:
            super().keyPressEvent(e)

    # ------------------------------------------------------------------ timers
    def tick(self):
        fmt = "HH:mm" if T.prefs.get("clock24") else "hh:mm AP"
        self.clock.setText(QTime.currentTime().toString(fmt))

    def _poll(self):
        if self.be.db_mtime() != self._mt and not self.overlay_open():
            self.reload(self.selId)
