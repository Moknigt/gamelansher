"""`python main.py --demo`: fills a temporary library with made-up games so you can try the interface."""
import json
import os
import random
import tempfile
import time

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QFont, QImage, QLinearGradient, QPainter, QRadialGradient

NAMES = [("Starfall Odyssey", "Nova Works", "Sci-fi · Adventure", 212),
         ("Ember Knight", "Cinder Forge", "Action · RPG", 40),
         ("Last Bell", "Quiet Owl", "Metroidvania", 330),
         ("Rally Drift 3", "Apex Labs", "Racing", 150),
         ("Deep Signal", "Low Tide", "Horror · Puzzle", 275),
         ("Tiny Kingdoms", "Pixel Hearth", "Strategy", 95),
         ("Skyline Runner", "Nova Works", "Platformer", 195),
         ("Moonlit Farm", "Pixel Hearth", "Simulation", 120)]
DESC = ("A short sample description so you can see how the text looks. It is only demo data. "
        "Add your own games with the + button to replace it.")


def _art(path, w, h, hue, text):
    img = QImage(w, h, QImage.Format.Format_ARGB32)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, w, h)
    g.setColorAt(0, QColor.fromHslF(hue / 360, .55, .30))
    g.setColorAt(1, QColor.fromHslF(((hue + 50) % 360) / 360, .6, .12))
    p.fillRect(0, 0, w, h, g)
    r = QRadialGradient(w * .7, h * .3, max(w, h) * .6)
    r.setColorAt(0, QColor(255, 255, 255, 70))
    r.setColorAt(1, QColor(255, 255, 255, 0))
    p.fillRect(0, 0, w, h, r)
    p.setPen(QColor(255, 255, 255, 230))
    f = QFont("Georgia")
    f.setPixelSize(int(min(w, h) * .11))
    f.setBold(True)
    p.setFont(f)
    p.drawText(QRectF(w * .08, h * .55, w * .84, h * .4), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom
               | Qt.TextFlag.TextWordWrap, text.upper())
    p.end()
    img.save(path)


def make_demo():
    folder = tempfile.mkdtemp(prefix="gl_demo_")
    os.environ["GL_DATA_DIR"] = folder
    art = os.path.join(folder, "art")
    os.makedirs(art, exist_ok=True)
    games = []
    now = time.time()
    for i, (name, dev, genres, hue) in enumerate(NAMES):
        gid = f"demo{i:02d}"
        _art(os.path.join(art, gid + "_cover.png"), 600, 900, hue, name)
        _art(os.path.join(art, gid + "_hero.png"), 1920, 1080, hue, name)
        open(os.path.join(folder, gid + ".exe"), "w").close()
        games.append({"id": gid, "name": name, "path": os.path.join(folder, gid + ".exe"), "cover": gid + "_cover.png",
                      "hero": gid + "_hero.png", "developer": dev, "genres": genres.split(" · "), "desc": DESC,
                      "fav": i in (0, 2, 5), "launches": random.randint(0, 30), "added": now - i * 86400 * 3,
                      "playtime": random.choice([0, 1500, 7200, 36000, 90000]),
                      "last_played": now - random.randint(1, 20) * 86400 if i % 3 else 0})
    with open(os.path.join(folder, "games.json"), "w", encoding="utf-8") as f:
        json.dump({"games": games, "settings": {"ui": {}, "steam_key": "", "steam_id": "", "track_play": False}}, f)
    return folder
