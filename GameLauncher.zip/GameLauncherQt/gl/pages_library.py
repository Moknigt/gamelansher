"""Library / Favorites: the grid of games, plus the full-page 'game details' view."""
import math
import time

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, Qt, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QFontMetrics, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from .icons import draw_icon
from .theme import T
from .i18n import tr as _t
from .util import fmt_ago, fmt_long, fmt_play
from .widgets import (AA, SMOOTH, Btn, SmoothScroll, StatCard, chip, label, mkfont, paint_cover, white)

SORTS = [("name", "Name"), ("recent", "Last played"), ("played", "Play time"), ("added", "Recently added")]


class GameGrid(QWidget):
    picked = Signal(str)
    activated = Signal(str)
    MINW, GAPX, GAPY, CAP = 150, 24, 30, 50
    PADL, PADR, PADT, PADB = 22, 40, 26, 30

    def __init__(self, parent=None):
        super().__init__(parent)
        self.games, self.sel_id, self.hover = [], None, -1
        self.plate = QRectF()
        self.setMouseTracking(True)
        self._an = QVariantAnimation(self)
        self._an.setDuration(380)
        self._an.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._an.valueChanged.connect(self._plate_to)

    def metrics(self):
        w = max(100, self.width() - self.PADL - self.PADR)
        cols = max(1, int((w + self.GAPX) // (self.MINW + self.GAPX)))
        return cols, (w - (cols - 1) * self.GAPX) / cols

    def cols(self):
        return self.metrics()[0]

    def index_of(self, gid):
        for i, g in enumerate(self.games):
            if g["id"] == gid:
                return i
        return -1

    def cell_rect(self, i):
        cols, cell = self.metrics()
        r, c = divmod(i, cols)
        return QRectF(self.PADL + c * (cell + self.GAPX), self.PADT + r * (cell + self.CAP + self.GAPY), cell, cell)

    def _fit(self):
        cols, cell = self.metrics()
        rows = math.ceil(len(self.games) / cols) if self.games else 0
        h = self.PADT + rows * (cell + self.CAP) + max(0, rows - 1) * self.GAPY + self.PADB
        self.setMinimumHeight(int(h))

    def _plate_target(self):
        i = self.index_of(self.sel_id)
        if i < 0:
            return QRectF()
        r = self.cell_rect(i)
        c = r.center()
        s = r.width() * 1.05 + 24
        return QRectF(c.x() - s / 2, c.y() - s / 2 - 4, s, s)

    def set_games(self, games, sel_id):
        self.games, self.sel_id = list(games), sel_id
        self._an.stop()
        self._fit()
        self.plate = self._plate_target()
        self.update()

    def select(self, gid):
        self.sel_id = gid
        tgt = self._plate_target()
        if self.plate.isNull() or not T.anim_on:
            self.plate = tgt
            self.update()
            return
        self._an.stop()
        self._an.setStartValue(self.plate)
        self._an.setEndValue(tgt)
        self._an.start()

    def _plate_to(self, v):
        self.plate = QRectF(v)
        self.update()

    def resizeEvent(self, e):
        self._fit()
        self._an.stop()
        self.plate = self._plate_target()

    def _hit(self, pos):
        cols, cell = self.metrics()
        c = int((pos.x() - self.PADL) // (cell + self.GAPX))
        r = int((pos.y() - self.PADT) // (cell + self.CAP + self.GAPY))
        i = r * cols + c
        if pos.x() < self.PADL or pos.y() < self.PADT or c >= cols or not (0 <= i < len(self.games)):
            return -1
        rc = self.cell_rect(i)
        return i if (rc.left() <= pos.x() <= rc.right() and rc.top() <= pos.y() <= rc.bottom() + self.CAP) else -1

    def mouseMoveEvent(self, e):
        h = self._hit(e.position())
        if h != self.hover:
            self.hover = h
            self.setCursor(Qt.CursorShape.PointingHandCursor if h >= 0 else Qt.CursorShape.ArrowCursor)
            self.update()

    def leaveEvent(self, e):
        self.hover = -1
        self.update()

    def mousePressEvent(self, e):
        i = self._hit(e.position())
        if i >= 0:
            self.picked.emit(self.games[i]["id"])

    def mouseDoubleClickEvent(self, e):
        i = self._hit(e.position())
        if i >= 0:
            self.activated.emit(self.games[i]["id"])

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        if not self.plate.isNull() and self.index_of(self.sel_id) >= 0:
            r = self.plate
            g = QLinearGradient(r.topLeft(), r.bottomLeft())
            g.setColorAt(0, T.ac_a(0.10))
            g.setColorAt(1, T.ac_a(0.30))
            p.setBrush(g)
            p.setPen(QPen(T.ac_a(0.75), 1.5))
            p.drawRoundedRect(r, 24, 24)
        vis = self.visibleRegion().boundingRect()
        for i, gm in enumerate(self.games):
            rc = self.cell_rect(i)
            if rc.bottom() + self.CAP < vis.top() or rc.top() > vis.bottom():
                continue
            sel = gm["id"] == self.sel_id
            r = rc
            if sel:
                c, s = rc.center(), rc.width() * 1.05
                r = QRectF(c.x() - s / 2, c.y() - s / 2 - 4, s, s)
            elif i == self.hover:
                c, s = rc.center(), rc.width() * 1.03
                r = QRectF(c.x() - s / 2, c.y() - s / 2, s, s)
            paint_cover(p, r, gm, 20)
            if sel:
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(T.ac2, 2))
                p.drawRoundedRect(r.adjusted(-1, -1, 1, 1), 20, 20)
            if gm.get("fav"):
                draw_icon(p, "star", QRectF(r.right() - 26, r.top() + 7, 19, 19), "#ffd75e")
            cap = QRectF(rc.left(), rc.bottom() + 12, rc.width(), 20)
            p.setFont(mkfont(14, 600))
            p.setPen(T.ac2 if (sel or i == self.hover) else QColor(255, 255, 255))
            p.drawText(cap, Qt.AlignmentFlag.AlignCenter,
                       QFontMetrics(p.font()).elidedText(gm.get("name", ""), Qt.TextElideMode.ElideRight, int(cap.width() - 8)))
            p.setFont(mkfont(12, 400))
            p.setPen(white(153))
            sub = fmt_long(gm["playtime"]) + " played" if gm.get("playtime") else ("New" if not gm.get("launches") else "Played")
            p.drawText(QRectF(rc.left(), rc.bottom() + 31, rc.width(), 18), Qt.AlignmentFlag.AlignCenter, _t(sub))


class CoverBox(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.game = {}

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(3, 3, -3, -3)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(T.ac_a(0.18))
        p.drawRoundedRect(r.adjusted(-3, -3, 3, 3), 25, 25)
        paint_cover(p, r, self.game, 22)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(white(46), 2))
        p.drawRoundedRect(r, 22, 22)
        if self.game.get("fav"):
            draw_icon(p, "star", QRectF(r.right() - 36, r.top() + 10, 24, 24), "#ffd75e")


class GamePage(QWidget):
    back = Signal()
    prev = Signal()
    next = Signal()
    play = Signal()
    fav = Signal()
    trophies = Signal()
    more = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 6, 40, 60)
        root.setSpacing(0)
        top = QHBoxLayout()
        self.b_back = Btn("Library", "chevL", "ghost")
        self.b_prev = Btn("", "chevL", "round", 42)
        self.b_next = Btn("", "chevR", "round", 42)
        self.count = label("", 13.5, 400, alpha=0.8)
        self.count.setMinimumWidth(52)
        self.count.setAlignment(Qt.AlignmentFlag.AlignCenter)
        top.addWidget(self.b_back)
        top.addStretch(1)
        for w in (self.b_prev, self.count, self.b_next):
            top.addWidget(w)
        root.addLayout(top)
        mid = QHBoxLayout()
        mid.setSpacing(44)
        self.cover = CoverBox()
        mid.addWidget(self.cover, 0, Qt.AlignmentFlag.AlignVCenter)
        info = QVBoxLayout()
        info.setSpacing(0)
        info.addStretch(1)
        self.title = QLabel()
        self.title.setWordWrap(True)
        self.title.setStyleSheet("color:#fff; background:transparent;")
        self.chips_box = QWidget()
        self.chips = QHBoxLayout(self.chips_box)
        self.chips.setContentsMargins(0, 0, 0, 0)
        self.chips.setSpacing(8)
        self.desc = label("", 15.5, 400, wrap=True, alpha=0.9)
        self.desc.setMaximumWidth(620)
        btns = QHBoxLayout()
        btns.setSpacing(12)
        self.b_play = Btn("Play", "play", "primary")
        self.b_fav = Btn("", "heart", "round", 50, icon_on="heart_on")
        self.b_tro = Btn("", "trophy", "round", 50)
        self.b_more = Btn("", "more", "round", 50)
        for b in (self.b_play, self.b_fav, self.b_tro, self.b_more):
            btns.addWidget(b)
        btns.addStretch(1)
        self.stats = QHBoxLayout()
        self.stats.setSpacing(12)
        info.addWidget(self.title)
        info.addSpacing(14)
        info.addWidget(self.chips_box)
        info.addSpacing(16)
        info.addWidget(self.desc)
        info.addSpacing(22)
        info.addLayout(btns)
        info.addSpacing(26)
        info.addLayout(self.stats)
        info.addStretch(1)
        mid.addLayout(info, 1)
        root.addLayout(mid, 1)
        self.b_back.clicked.connect(self.back)
        self.b_prev.clicked.connect(self.prev)
        self.b_next.clicked.connect(self.next)
        self.b_play.clicked.connect(self.play)
        self.b_fav.clicked.connect(self.fav)
        self.b_tro.clicked.connect(self.trophies)
        self.b_more.clicked.connect(self.more)

    def resizeEvent(self, e):
        h = int(min(self.height() * 0.58, 440))
        self.cover.setFixedSize(int(h * 2 / 3) + 6, h + 6)

    def show_game(self, g, index, total, back_text):
        self.b_back.set_label(back_text)
        self.cover.game = g
        self.cover.update()
        name = (g.get("name") or "").upper()
        self.title.setText(name)
        self.title.setFont(mkfont(46 if len(name) <= 18 else 36 if len(name) <= 30 else 28, 700, serif=True, spacing=2))
        while self.chips.count():
            it = self.chips.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        items = [x for x in (g.get("developer"), " · ".join(g.get("genres") or [])) if x]
        for t in items:
            self.chips.addWidget(chip(t))
        self.chips.addStretch(1)
        self.chips_box.setVisible(bool(items))
        d = g.get("desc") or ""
        self.desc.setText(d if len(d) < 380 else d[:377].rsplit(" ", 1)[0] + "…")
        self.desc.setVisible(bool(d))
        self.b_fav.active = bool(g.get("fav"))
        self.b_fav.update()
        self.b_prev.setEnabled(index > 0)
        self.b_next.setEnabled(index < total - 1)
        self.b_prev.setWindowOpacity(1)
        self.count.setText(f"{index + 1} / {total}")
        while self.stats.count():
            it = self.stats.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self.stats.addWidget(StatCard("clock", "Play Time", fmt_play(g.get("playtime")) if g.get("playtime") else "Not played yet"))
        self.stats.addWidget(StatCard("play", "Times Played", str(g.get("launches") or 0)))
        self.stats.addWidget(StatCard("gamepad", "Last Played", fmt_ago(g["last_played"]) if g.get("last_played") else "Never"))
        tro = StatCard("trophy", "Trophies", f"{g['tro_unlocked']} / {g['tro_total']}" if g.get("tro_total") else "—", clickable=True)
        tro.clicked.connect(self.trophies)
        self.stats.addWidget(tro)
        self.stats.addStretch(1)


class LibraryPage(QWidget):
    picked = Signal(str)
    activated = Signal(str)
    sort_changed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.head = QWidget(self)
        hl = QHBoxLayout(self.head)
        hl.setContentsMargins(8, 10, 40, 10)
        hl.setSpacing(14)
        self.title = label("All Games", 27, 700)
        self.count = QLabel("0 games")
        self.count.setFont(mkfont(13, 400))
        self.count.setStyleSheet("background:rgba(255,255,255,26); color:#fff; border-radius:13px; padding:4px 13px;")
        self.combo = QComboBox()
        for k, t in SORTS:
            self.combo.addItem(_t("Sort by: " + t), k)
        hl.addWidget(self.title)
        hl.addWidget(self.count)
        hl.addStretch(1)
        hl.addWidget(self.combo)
        self.scroll = SmoothScroll(self)
        self.grid = GameGrid()
        self.scroll.setWidget(self.grid)
        self.empty = label("", 15, 400, wrap=True, alpha=0.8, parent=self)
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.detail = GamePage(self)
        self.detail.hide()
        self.grid.picked.connect(self.picked)
        self.grid.activated.connect(self.activated)
        self.combo.activated.connect(lambda _i: self.sort_changed.emit(self.combo.currentData()))

    def set_games(self, games, sel_id, title, sortable, sort_key, empty_text):
        self.title.setText(_t(title))
        self.count.setText(_t(f"{len(games)} game" + ("" if len(games) == 1 else "s")))
        self.combo.setVisible(sortable)
        self.combo.blockSignals(True)
        self.combo.setCurrentIndex(max(0, [k for k, _ in SORTS].index(sort_key) if sort_key in dict(SORTS) else 0))
        self.combo.blockSignals(False)
        self.grid.set_games(games, sel_id)
        self.empty.setText(_t(empty_text))
        self.empty.setVisible(not games)

    def select(self, gid):
        self.grid.select(gid)
        i = self.grid.index_of(gid)
        if i < 0:
            return
        r = self.grid.cell_rect(i)
        top = r.top() - self.scroll.verticalScrollBar().value()
        bot = top + r.height() + self.grid.CAP
        vh = self.scroll.viewport().height()
        if top < 46:
            self.scroll.scroll_to(r.top() - 52)
        elif bot > vh - 52:
            self.scroll.scroll_to(r.top() + r.height() + self.grid.CAP + 60 - vh)

    def resizeEvent(self, e):
        w, h = self.width(), self.height()
        self.head.setGeometry(0, 0, w, 64)
        self.scroll.setGeometry(0, 64, w, max(0, h - 64 - 50))
        self.empty.setGeometry(60, 140, max(100, w - 120), 120)
        self.detail.setGeometry(0, 0, w, h)
