"""Tiny synthesized sound effects (no audio files needed). Silently does nothing if Qt audio is missing."""
import math
import os
import struct
import tempfile
import wave

try:
    from PySide6.QtCore import QUrl
    from PySide6.QtMultimedia import QSoundEffect
except Exception:                                  # pragma: no cover - audio is optional
    QSoundEffect = None

from .theme import T

SR = 22050
# name -> list of (frequency Hz, seconds, shape, volume, start second)
SOUNDS = {
    "move": [(660, .06, "triangle", .5, 0)],
    "ok": [(523, .12, "sine", .7, 0), (784, .22, "sine", .7, .08)],
    "open": [(440, .10, "triangle", .5, 0), (660, .14, "triangle", .5, .06)],
    "boot": [(f, .9, "sine", .5, i * .12) for i, f in enumerate((392, 523, 659, 784))],
    "pop": [(880, .18, "sine", .6, 0), (1320, .30, "sine", .6, .13)],
}


def _wave(shape, ph):
    if shape == "triangle":
        return 2 * abs(2 * (ph - math.floor(ph + .5))) - 1
    return math.sin(2 * math.pi * ph)


def _build(path, notes):
    total = max(s + d for _f, d, _w, _v, s in notes) + .05
    n = int(SR * total)
    buf = [0.0] * n
    for f, d, shape, vol, start in notes:
        i0, cnt = int(start * SR), int(d * SR)
        for i in range(cnt):
            if i0 + i >= n:
                break
            env = min(1.0, i / 120.0) * math.exp(-4.0 * i / max(1, cnt))
            buf[i0 + i] += _wave(shape, f * i / SR) * vol * env
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, x)) * 20000)) for x in buf))


class Sfx:
    def __init__(self):
        self.fx = {}
        self._ready = False

    def _init(self):
        self._ready = True
        if QSoundEffect is None or os.environ.get("QT_QPA_PLATFORM") == "offscreen" or os.environ.get("GL_NO_SOUND"):
            return
        try:
            folder = os.path.join(tempfile.gettempdir(), "gl_qt_sfx")
            os.makedirs(folder, exist_ok=True)
            for name, notes in SOUNDS.items():
                path = os.path.join(folder, name + ".wav")
                if not os.path.isfile(path):
                    _build(path, notes)
                e = QSoundEffect()
                e.setSource(QUrl.fromLocalFile(path))
                self.fx[name] = e
        except Exception:
            self.fx = {}

    def play(self, name, force=False):
        if not force and not T.prefs.get("sfx"):
            return
        if not self._ready:
            self._init()
        e = self.fx.get(name)
        if e is not None:
            e.setVolume(max(0.0, min(1.0, float(T.prefs.get("vol", .5)))))
            e.play()

    def move(self): self.play("move")
    def ok(self): self.play("ok")
    def open(self): self.play("open")
    def boot(self): self.play("boot")


sfx = Sfx()
