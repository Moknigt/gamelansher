"""Gamepad support (PART 3): Xbox-style controllers through Windows XInput (ctypes, nothing to install).

Same mapping as the old version:  D-pad / left stick = move,  A = select,  B = back,
Y = achievements,  LB / RB = Home <-> Library.
On other systems (or with no controller) it simply does nothing.
"""
import ctypes
import sys
import time

from PySide6.QtCore import QObject, QTimer, Signal

BTN = {"up": 0x0001, "down": 0x0002, "left": 0x0004, "right": 0x0008, "lb": 0x0100, "rb": 0x0200,
       "a": 0x1000, "b": 0x2000, "y": 0x8000}
STICK = 20000            # about 60% of the stick's range, like the old 0.6 dead zone
REPEAT_FIRST, REPEAT_NEXT = 0.38, 0.11      # holding a direction keeps moving (seconds)
DIRS = ("left", "right", "up", "down")


class GamepadLogic:
    """Turns raw pad states into 'button pressed' events. No Qt, easy to test."""

    def __init__(self):
        self.held = {}          # name -> time it was first seen pressed
        self.next_rep = {}

    def update(self, state, now=None):
        """state = (buttons_mask, lx, ly) or None when no pad. Returns a list of event names."""
        now = time.monotonic() if now is None else now
        if state is None:
            self.held.clear()
            return []
        mask, lx, ly = state
        cur = {
            "left": bool(mask & BTN["left"]) or lx < -STICK,
            "right": bool(mask & BTN["right"]) or lx > STICK,
            "up": bool(mask & BTN["up"]) or ly > STICK,       # XInput: stick up is positive
            "down": bool(mask & BTN["down"]) or ly < -STICK,
            "a": bool(mask & BTN["a"]), "b": bool(mask & BTN["b"]), "y": bool(mask & BTN["y"]),
            "tab": bool(mask & (BTN["lb"] | BTN["rb"])),
        }
        out = []
        for k, on in cur.items():
            if on and k not in self.held:
                self.held[k] = now
                self.next_rep[k] = now + REPEAT_FIRST
                out.append(k)
            elif on and k in DIRS and now >= self.next_rep.get(k, 1e18):
                self.next_rep[k] = now + REPEAT_NEXT
                out.append(k)
            elif not on:
                self.held.pop(k, None)
        return out


class _Gp(ctypes.Structure):
    _fields_ = [("wButtons", ctypes.c_ushort), ("bLeftTrigger", ctypes.c_ubyte), ("bRightTrigger", ctypes.c_ubyte),
                ("sThumbLX", ctypes.c_short), ("sThumbLY", ctypes.c_short),
                ("sThumbRX", ctypes.c_short), ("sThumbRY", ctypes.c_short)]


class _State(ctypes.Structure):
    _fields_ = [("dwPacketNumber", ctypes.c_ulong), ("Gamepad", _Gp)]


def _load_xinput():
    if sys.platform != "win32":
        return None
    for name in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
        try:
            return ctypes.WinDLL(name)
        except OSError:
            continue
    return None


class Gamepad(QObject):
    pressed = Signal(str)       # left right up down a b y tab

    def __init__(self, parent=None, reader=None):
        super().__init__(parent)
        self.logic = GamepadLogic()
        self._dll = None if reader else _load_xinput()
        self._reader = reader or (self._read_xinput if self._dll else None)
        self._idx, self._scan_at = None, 0.0
        self.t = QTimer(self)
        self.t.setInterval(45)
        self.t.timeout.connect(self._tick)

    def start(self):
        if self._reader:
            self.t.start()

    def stop(self):
        self.t.stop()

    def _read_xinput(self):
        now = time.monotonic()
        if self._idx is None:
            if now < self._scan_at:
                return None
            self._scan_at = now + 1.5            # no pad: look again only every 1.5 s (polling a missing pad is slow)
            for i in range(4):
                if self._dll.XInputGetState(i, ctypes.byref(_State())) == 0:
                    self._idx = i
                    break
            if self._idx is None:
                return None
        st = _State()
        if self._dll.XInputGetState(self._idx, ctypes.byref(st)) != 0:
            self._idx = None
            return None
        g = st.Gamepad
        return g.wButtons, g.sThumbLX, g.sThumbLY

    def _tick(self):
        try:
            state = self._reader()
        except Exception:
            state = None
        for ev in self.logic.update(state):
            self.pressed.emit(ev)
