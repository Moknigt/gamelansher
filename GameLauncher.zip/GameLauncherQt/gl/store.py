"""games.json reading/writing (same format as the old version).

SAFETY: this file is the user's whole library, so it is never overwritten with an empty/unknown state.
 - A failed read is retried, then the newest backup is used; the broken file is kept next to it (never deleted).
 - If nothing readable exists, `mutate` refuses to save (StoreError) instead of writing an empty library.
 - Every save keeps rolling backups in <data>/backups (at most one per few minutes, newest 12 kept) plus
   `games.json.bak` (the previous version). `restore_latest_backup()` is used by Settings > Data.
"""
import glob
import json
import os
import shutil
import threading
import time

from . import paths

DB_LOCK = threading.RLock()
BACKUP_KEEP = 12
BACKUP_EVERY = 300          # seconds between rolling backups


class StoreError(Exception):
    """games.json exists but cannot be read - nothing is saved so the library is not lost."""


def _backup_dir():
    return os.path.join(paths.DATA_DIR, "backups")


def _read_json(path):
    with open(path, encoding="utf-8-sig") as f:      # utf-8-sig also accepts a BOM
        d = json.load(f)
    if not isinstance(d, dict):
        raise ValueError("not a library file")
    return d


def list_backups():
    """Newest first: [(path, mtime, games_count)]."""
    out = []
    for p in glob.glob(os.path.join(_backup_dir(), "games-*.json")) + [paths.DB_FILE + ".bak"]:
        try:
            d = _read_json(p)
            out.append((p, os.path.getmtime(p), len(d.get("games") or [])))
        except (OSError, ValueError):
            continue
    out.sort(key=lambda x: -x[1])
    return out


def _normalize(d):
    d.setdefault("games", [])
    st = d.setdefault("settings", {})
    st.setdefault("steam_key", "")
    st.setdefault("steam_id", "")
    st.setdefault("ui", {})
    st.setdefault("track_play", False)      # off = nothing stays running while a game is open
    st.setdefault("reopen_after", False)    # open the launcher again when the game is closed (needs the helper)
    if not st.get("bg_v2"):                 # one time: the tiny hidden helper is ON by default now (it can be switched off)
        st["bg_v2"], st["track_play"], st["reopen_after"] = True, True, True
    return d


def _quarantine(path):
    """Keep an unreadable file for the user instead of overwriting it."""
    try:
        os.makedirs(_backup_dir(), exist_ok=True)
        shutil.copy2(path, os.path.join(_backup_dir(), "broken-%d.json" % int(time.time())))
    except OSError:
        pass


def load_db():
    """Returns the library. Fresh (empty) only when there is NO file; a damaged file falls back to a backup or raises."""
    path = paths.DB_FILE
    if not os.path.exists(path):
        return _normalize({})
    last = None
    for i in range(4):                                   # the file may be mid-replace or locked for a moment
        try:
            return _normalize(_read_json(path))
        except (OSError, ValueError) as ex:
            last = ex
            time.sleep(0.05 * (i + 1))
    _quarantine(path)
    for p, _mt, _n in list_backups():                    # newest readable backup
        try:
            return _normalize(_read_json(p))
        except (OSError, ValueError):
            continue
    raise StoreError("The games file could not be read (%s). Nothing was changed." % (last,))


def _rolling_backup(force=False):
    """Copy the current games.json into backups/ (throttled unless `force`). Returns True when a copy was made."""
    try:
        if not os.path.exists(paths.DB_FILE):
            return False
        os.makedirs(_backup_dir(), exist_ok=True)
        files = sorted(glob.glob(os.path.join(_backup_dir(), "games-*.json")))
        if not force and files and time.time() - os.path.getmtime(files[-1]) < BACKUP_EVERY:
            return False
        shutil.copy2(paths.DB_FILE, os.path.join(_backup_dir(), "games-%s.json" % time.strftime("%Y%m%d-%H%M%S")))
        for old in files[: max(0, len(files) + 1 - BACKUP_KEEP)]:
            try:
                os.remove(old)
            except OSError:
                pass
        return True
    except OSError:
        return False


def backup_now():
    with DB_LOCK:
        return _rolling_backup(force=True)


def _games_on_disk():
    """How many games the current games.json holds (0 when missing/unreadable)."""
    try:
        return len(_read_json(paths.DB_FILE).get("games") or [])
    except (OSError, ValueError):
        return 0


def save_db(d):
    os.makedirs(paths.DATA_DIR, exist_ok=True)
    if not d.get("games") and _games_on_disk() >= 2:     # last line of defence: never swap a real library for an empty one
        _rolling_backup(force=True)
        raise StoreError("Refused to save an empty games list over a library with games. Nothing was changed.")
    _rolling_backup()
    if os.path.exists(paths.DB_FILE):                    # the previous version, always one step back
        try:
            shutil.copy2(paths.DB_FILE, paths.DB_FILE + ".bak")
        except OSError:
            pass
    tmp = paths.DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    for i in range(6):                                   # Windows: replace can fail while another thread reads
        try:
            os.replace(tmp, paths.DB_FILE)
            return
        except PermissionError:
            time.sleep(0.05 * (i + 1))
    os.replace(tmp, paths.DB_FILE)


def mutate(fn):
    with DB_LOCK:
        db = load_db()                                   # raises StoreError -> nothing is written
        before = len(db.get("games") or [])
        r = fn(db)
        if len(db.get("games") or []) < before - 1:      # no single action removes more than one game
            raise StoreError("Refused: this change would have removed %d games. Nothing was changed." % (before - len(db["games"])))
        save_db(db)
        return r


def restore_latest_backup():
    """Puts back the newest backup that has games. Returns the number of games restored (0 = nothing to restore)."""
    with DB_LOCK:
        best = None
        for p, _mt, n in list_backups():
            if n > 0:
                best = (p, n)
                break
        if not best:
            return 0
        if os.path.exists(paths.DB_FILE):
            _quarantine(paths.DB_FILE)
        shutil.copy2(best[0], paths.DB_FILE)
        return best[1]


def find_game(db, gid):
    for g in db["games"]:
        if g.get("id") == gid:
            return g
    raise KeyError("Game not found")
