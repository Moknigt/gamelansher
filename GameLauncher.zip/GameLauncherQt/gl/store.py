"""games.json reading/writing (same format as the old version)."""
import json
import os
import threading

from . import paths

DB_LOCK = threading.RLock()


def load_db():
    try:
        with open(paths.DB_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("games", [])
    st = d.setdefault("settings", {})
    st.setdefault("steam_key", "")
    st.setdefault("steam_id", "")
    st.setdefault("ui", {})
    st.setdefault("track_play", False)      # off = nothing stays running while a game is open
    st.setdefault("reopen_after", False)    # open the launcher again when the game is closed (needs the helper)
    if not st.get("bg_v2"):                 # one time: the tiny hidden helper is ON by default now (it can be switched off)
        st["bg_v2"], st["track_play"], st["reopen_after"] = True, True, True
    return d


def save_db(d):
    os.makedirs(paths.DATA_DIR, exist_ok=True)
    tmp = paths.DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, paths.DB_FILE)


def mutate(fn):
    with DB_LOCK:
        db = load_db()
        r = fn(db)
        save_db(db)
        return r


def find_game(db, gid):
    for g in db["games"]:
        if g.get("id") == gid:
            return g
    raise KeyError("Game not found")
