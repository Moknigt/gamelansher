"""Inline SVG icons (24x24, stroke style) drawn to pixmaps in any color."""
from PySide6.QtCore import QByteArray, QRectF, Qt
from PySide6.QtGui import QGuiApplication, QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

_S = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
_F = 'fill="currentColor" stroke="none"'

PATHS = {
    "home": '<path d="M3 11.5l9-8 9 8"/><path d="M5.5 10v10h4.5v-6h4v6h4.5V10"/>',
    "lib": '<rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/>',
    "heart": '<path d="M12 20.5s-8-4.9-8-11A4.6 4.6 0 0 1 12 6.6 4.6 4.6 0 0 1 20 9.5c0 6.1-8 11-8 11z"/>',
    "heart_on": f'<path {_F} d="M12 20.5s-8-4.9-8-11A4.6 4.6 0 0 1 12 6.6 4.6 4.6 0 0 1 20 9.5c0 6.1-8 11-8 11z"/>',
    "trophy": '<path d="M8 4h8v5a4 4 0 0 1-8 0z"/><path d="M8 6H4.5A3.5 3.5 0 0 0 8 10M16 6h3.5A3.5 3.5 0 0 1 16 10"/><path d="M12 13v4M8.5 20h7M10 17h4"/>',
    "trophy_on": f'<path {_F} d="M7.5 3.5h9v5.5a4.5 4.5 0 0 1-9 0z"/><path d="M7.5 5.5H4.3A3.7 3.7 0 0 0 8 10M16.5 5.5h3.2A3.7 3.7 0 0 1 16 10"/><path d="M12 13.5v3.5M8.5 20.5h7M10 17h4"/>',
    "search": '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
    "gear": '<circle cx="12" cy="12" r="3.2"/><circle cx="12" cy="12" r="7"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "play": f'<path {_F} d="M7 4.5v15l13-7.5z"/>',
    "power": '<path d="M12 3v8"/><path d="M7 6.3a8 8 0 1 0 10 0"/>',
    "chevL": '<path d="M15 5l-7 7 7 7"/>',
    "chevR": '<path d="M9 5l7 7-7 7"/>',
    "arrowR": '<path d="M5 12h14M13 6l6 6-6 6"/>',
    "clock": '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
    "stats": '<path d="M5 20V11M12 20V4M19 20v-6"/>',
    "star": f'<path {_F} d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1L3.2 9.6l6.1-.8z"/>',
    "check": '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    "cross": '<path d="M6 6l12 12M18 6L6 18"/>',
    "pencil": '<path d="M4 20l1-4.5L16.5 4a2 2 0 0 1 3 3L8 18.5z"/>',
    "more": f'<circle cx="5.5" cy="12" r="1.9" {_F}/><circle cx="12" cy="12" r="1.9" {_F}/><circle cx="18.5" cy="12" r="1.9" {_F}/>',
    "gamepad": '<rect x="2.5" y="7" width="19" height="10.5" rx="5"/><path d="M7.5 10.5v3.5M5.8 12.2h3.4"/><circle cx="15.5" cy="11" r="1" fill="currentColor"/><circle cx="18" cy="13.5" r="1" fill="currentColor"/>',
    "image": '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5.5-5 4 3.5 3-2.5 3.5 3.5"/>',
    "link": '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1"/>',
    "moon": '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8"/>',
    "stack": '<path d="M12 3.5l9 4.5-9 4.5-9-4.5z"/><path d="M3 12l9 4.5 9-4.5M3 16l9 4.5 9-4.5"/>',
    "sliders": '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    "spk": '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    "dpad": '<path d="M9.5 3.5h5v6h6v5h-6v6h-5v-6h-6v-5h6z"/>',
    "cross_btn": '<path d="M7 7l10 10M17 7L7 17"/>',
    "palette": '<path d="M12 3a9 9 0 1 0 0 18c1.2 0 1.8-.9 1.4-1.9-.4-1 .2-2.1 1.4-2.1H17a4 4 0 0 0 4-4c0-5-4-10-9-10z"/><circle cx="7.5" cy="11" r="1.1"/><circle cx="10" cy="7" r="1.1"/><circle cx="15" cy="7.2" r="1.1"/>',
    "wand": '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16v4M17 18h4"/>',
    "monitor": '<rect x="3" y="4.5" width="18" height="12" rx="2"/><path d="M8.5 20h7M12 16.5V20"/>',
    "shield": '<path d="M12 3l7.5 3v5.5c0 4.6-3.2 8.1-7.5 9.5-4.3-1.4-7.5-4.9-7.5-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    "folder": '<path d="M3.5 7.5a2 2 0 0 1 2-2H10l2 2.5h6.5a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
    "steam": '<circle cx="12" cy="12" r="9"/><circle cx="15.2" cy="9.6" r="2.4"/><path d="M3.3 13.2l5.2 2.1M7.8 17.2a2 2 0 1 0 1.4-3.4"/>',
    "circ": '<circle cx="12" cy="12" r="6.5"/>',
}
_CACHE = {}


def _dpr():
    s = QGuiApplication.primaryScreen()
    return s.devicePixelRatio() if s else 1.0


def icon(name, size=22, color="#ffffff"):
    """Pixmap of an icon, `size` logical pixels, drawn in `color` (hex string or QColor)."""
    if not isinstance(color, str):
        color = color.name()
    key = (name, size, color)
    pm = _CACHE.get(key)
    if pm is not None:
        return pm
    dpr = _dpr()
    px = max(1, int(round(size * dpr)))
    body = PATHS.get(name, PATHS["circ"]).replace("currentColor", color)
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" color="{color}" '
           f'{_S.replace("currentColor", color)}>{body}</svg>')
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(p, QRectF(0, 0, px, px))
    p.end()
    pm = QPixmap.fromImage(img)
    pm.setDevicePixelRatio(dpr)
    _CACHE[key] = pm
    return pm


def draw_icon(p, name, rect, color="#ffffff"):
    """Draw an icon centered in `rect` (QRectF), sized to the rect's smaller side."""
    s = int(min(rect.width(), rect.height()))
    pm = icon(name, s, color)
    p.drawPixmap(int(rect.center().x() - s / 2), int(rect.center().y() - s / 2), pm)
