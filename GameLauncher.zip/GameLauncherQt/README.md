# Game Launcher (Qt rewrite)

Native Qt (PySide6) version of the launcher. Same data folder as the old WebView version
(`~/.mygamelauncher/games.json`), so your games, art and trophies carry over.

## Run
```
pip install -r requirements.txt
python main.py            # your real library
python main.py --demo     # TRIAL: temporary library with 8 made-up games (nothing of yours is touched)
```
On Windows you can also double-click `Run.bat` or `Run_Demo.bat`. The built exe takes the same flag: `GameLauncher.exe --demo`.

## What it does
- Home / Library / Favorites / Achievements, search, themes, sounds, keyboard and gamepad.
- Add a game: pick its `.exe`; the launcher guesses the name, finds the Steam page and downloads the art (works offline too, it fills in later).
- **When you press Play the launcher closes completely.** Settings (Achievements > Settings) has two optional choices:
  - *Open the launcher again when I close the game*
  - *Count play time*
  Either one keeps a tiny hidden helper (no window) alive while the game is open. With both off (default) nothing stays running.
- Gamepad (Xbox style, Windows): D-pad / left stick move, A select, B back, Y achievements, LB / RB switch Home <-> Library.
- Real Steam achievements with an API key + SteamID (cached for offline); otherwise tick them by hand.

## Get the .exe from GitHub (no install on your PC)
1. Upload everything in this folder to a GitHub repository (keep the `.github` folder).
2. Open **Actions**; the build starts by itself (or press **Run workflow**). It first runs a headless smoke test of every screen.
3. When it is green, download **GameLauncher-exe** from *Artifacts*.
Push a tag like `v1.0` to get a permanent download on the Releases page.

## Notes
- Windows may show a SmartScreen warning because the exe is not code-signed: *More info > Run anyway*.
- Status: Part 1 (interface), Part 2 (Steam data) and Part 3 (helper, gamepad, build) are written. See HANDOFF_PROMPT.md for what was tested.
