"""Headless run of the real Add / Edit flows with pictures chosen by the user (file dialog and network faked).
Run:  QT_QPA_PLATFORM=offscreen python tests/flow_art.py"""
import os
import sys
import tempfile
import traceback

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
errors = []
sys.excepthook = lambda t, v, tb: errors.append("".join(traceback.format_exception(t, v, tb)))


def main():
    from PySide6.QtGui import QColor, QImage
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QFileDialog

    from gl import demo
    app = QApplication([])
    demo.make_demo()
    from gl import steam
    from gl.backend import Backend
    from gl.main_window import MainWindow
    from gl.theme import T

    tmp = tempfile.mkdtemp()

    def png(name, w, h):
        im = QImage(w, h, QImage.Format.Format_RGB32)
        im.fill(QColor("#aa5533"))
        p = os.path.join(tmp, name)
        im.save(p)
        return p
    wide, tall = png("wide.png", 1600, 900), png("tall.png", 600, 900)
    steam.fetch_bytes = lambda url, limit=0: None
    steam.online_search = lambda t: ([{"source": "google", "id": "u", "page": "u", "name": "Cool Game", "img": ""}], False)
    steam.find_steam_match = lambda path, name=None: (None, False)
    app.setStyleSheet(T.qss())
    win = MainWindow(Backend())
    win.reload(None, True)
    win.resize(1366, 720)
    win.show()
    QTest.qWait(200)
    n0 = len(win.games)

    exe = os.path.join(tmp, "Cool Game", "cool.exe")
    os.makedirs(os.path.dirname(exe))
    open(exe, "w").write("x")
    win._add_details(exe)                                     # step 2 of Add: it searches by itself
    QTest.qWait(300)
    c = win.modal.card
    assert c.res.count() == 1, "the automatic search should have filled the list"
    QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: (wide, ""))
    c.p_hero.clicked.emit()
    QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: (tall, ""))
    c.p_cover.clicked.emit()
    assert c.hero_file == wide and c.cover_file == tall and c.p_hero.pm and c.p_cover.pm
    c.add.emit()
    QTest.qWait(800)
    assert len(win.games) == n0 + 1, "the game was not added"
    g = next(x for x in win.games if x["path"].endswith("cool.exe"))
    assert g["custom_hero"] and g["custom_cover"] and g["hero_path"] and g["cover_path"]

    win.selId = g["id"]
    win.open_edit()
    QTest.qWait(200)
    c = win.modal.card
    old = (g["hero_path"], g["cover_path"])
    QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: (tall, ""))
    c.p_hero.clicked.emit()                                   # change the background from the Edit card
    QTest.qWait(200)
    assert win.modal.is_open(), "the Edit card should stay open after changing a picture"
    g2 = next(x for x in win.games if x["id"] == g["id"])
    assert g2["hero_path"] != old[0]
    QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: (wide, ""))
    c.p_cover.clicked.emit()
    QTest.qWait(200)
    g3 = next(x for x in win.games if x["id"] == g["id"])
    assert g3["cover_path"] != old[1]
    win.close_all()
    win.close()


try:
    main()
except Exception:
    errors.append(traceback.format_exc())
if errors:
    print("FLOW TEST FAILED\n" + "\n".join(errors))
    sys.exit(1)
print("flow test OK")
