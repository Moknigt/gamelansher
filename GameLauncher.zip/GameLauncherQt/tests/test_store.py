"""Store safety test (no Qt): a damaged games.json must never turn into an empty library.
Run:  python tests/test_store.py"""
import os, sys, json, tempfile, time
d = tempfile.mkdtemp()
os.environ["GL_DATA_DIR"] = d
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from gl import store, paths
assert paths.DATA_DIR == d

# 1) fresh: no file -> empty library, nothing written yet
db = store.load_db(); assert db["games"] == []
store.mutate(lambda db: db["games"].append({"id": "a", "name": "A"}))
store.mutate(lambda db: db["games"].append({"id": "b", "name": "B"}))
assert [g["id"] for g in store.load_db()["games"]] == ["a", "b"]
assert os.path.exists(paths.DB_FILE + ".bak")
assert len(os.listdir(os.path.join(d, "backups"))) == 1          # throttled: one rolling backup

# 2) corrupt file -> falls back to the backup, broken copy kept, games NOT lost
open(paths.DB_FILE, "w").write('{"games": [ {"id": "a"')            # truncated json
got = store.load_db()
assert [g["id"] for g in got["games"]] == ["a"] or len(got["games"]) >= 1, got["games"]
assert any(f.startswith("broken-") for f in os.listdir(os.path.join(d, "backups")))
print("fallback games:", [g["id"] for g in got["games"]])

# 3) corrupt + no backups at all -> StoreError, and mutate must not write
d2 = tempfile.mkdtemp(); paths.DATA_DIR = d2; paths.DB_FILE = os.path.join(d2, "games.json")
open(paths.DB_FILE, "w").write("garbage")
try:
    store.load_db(); raise SystemExit("should have raised")
except store.StoreError as ex:
    print("StoreError ok:", str(ex)[:50])
called = []
try:
    store.mutate(lambda db: called.append(1))
except store.StoreError:
    pass
assert not called and open(paths.DB_FILE).read() == "garbage"      # untouched

# 4) restore: wiped library comes back from backup
d3 = tempfile.mkdtemp(); paths.DATA_DIR = d3; paths.DB_FILE = os.path.join(d3, "games.json")
store.mutate(lambda db: db["games"].extend([{"id": "x"}, {"id": "y"}, {"id": "z"}]))
store.mutate(lambda db: None)                                       # any later save leaves the 3-game version as a backup
# the new guard refuses to wipe a library through the normal save path ...
try:
    store.mutate(lambda db: db["games"].clear())
    raise SystemExit("wipe was allowed")
except store.StoreError:
    pass
assert len(store.load_db()["games"]) == 3
# ... and an empty file written by something else is still recoverable from the backup
json.dump({"games": [], "settings": {}}, open(paths.DB_FILE, "w"))
assert store.load_db()["games"] == []
n = store.restore_latest_backup()
print("restored:", n)
assert n == 3 and len(store.load_db()["games"]) == 3
# 5) BOM file is accepted
open(paths.DB_FILE, "wb").write(b"\xef\xbb\xbf" + json.dumps({"games": [{"id": "q"}]}).encode())
assert store.load_db()["games"][0]["id"] == "q"
print("ALL STORE TESTS PASSED")
