"""Headless smoke test: opens every screen with demo games and drives a few keys. Exit code 1 on any error.
Run:  QT_QPA_PLATFORM=offscreen python tests/smoke.py
"""
import os
import sys
import traceback

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

errors = []


def hook(t, v, tb):
    errors.append("".join(traceback.format_exception(t, v, tb)))


sys.excepthook = hook


def main():
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication

    from gl import demo
    app = QApplication([])
    demo.make_demo()
    from gl.backend import Backend
    from gl.main_window import MainWindow
    from gl.theme import T

    app.setStyleSheet(T.qss())
    be = Backend()
    win = MainWindow(be)
    win.reload(None, True)
    win.resize(1500, 860)
    win.show()
    QTest.qWait(300)
    for v in ("home", "lib", "ach", "home"):
        win.go_view(v)
        QTest.qWait(150)
    for sub in ("overview", "games", "stats", "settings"):
        win.achSub = sub
        win.go_view("ach")
        win._ach_go(sub)
        QTest.qWait(120)
    win.go_view("home")
    for k in (Qt.Key.Key_Right, Qt.Key.Key_Right, Qt.Key.Key_Left, Qt.Key.Key_Escape):
        QTest.keyClick(win, k)
        QTest.qWait(60)
    for name in ("right", "left", "tab", "tab", "y", "b"):       # gamepad events
        win.pad_press(name)
        QTest.qWait(80)
    win.open_settings()
    QTest.qWait(150)
    win.close_all()
    win.open_ach()
    QTest.qWait(600)
    win.close_all()
    win.close()


try:
    main()
except Exception:
    errors.append(traceback.format_exc())
if errors:
    print("SMOKE TEST FAILED\n" + "\n".join(errors))
    sys.exit(1)
print("smoke test OK")
