"""Headless smoke test: opens every screen with demo games and drives a few keys. Exit code 1 on any error.
Run:  QT_QPA_PLATFORM=offscreen python tests/smoke.py
"""
import os
import sys
import traceback

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

errors = []


def hook(t, v, tb):
    errors.append("".join(traceback.format_exception(t, v, tb)))


sys.excepthook = hook


def main():
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication

    from gl import demo
    app = QApplication([])
    demo.make_demo()
    from gl.backend import Backend
    from gl.main_window import MainWindow
    from gl.theme import T

    app.setStyleSheet(T.qss())
    be = Backend()
    win = MainWindow(be)
    win.reload(None, True)
    win.resize(1500, 860)
    win.show()
    QTest.qWait(300)
    for v in ("home", "lib", "ach", "home"):
        win.go_view(v)
        QTest.qWait(150)
    for sub in ("overview", "games", "stats"):
        win.achSub = sub
        win.go_view("ach")
        win._ach_go(sub)
        QTest.qWait(120)
    from gl.settings_page import SIDE_ITEMS
    from gl.theme import ANIMS, THEMES
    win.open_settings()                                  # the Settings screen: every category
    QTest.qWait(150)
    for key, _ic, _t in SIDE_ITEMS:
        win._set_go(key)
        QTest.qWait(120)
    win._set_go("themes")
    for key in THEMES:                                   # pick every theme
        win.setp._theme(key)
    win._set_go("anim")
    for key in ANIMS:                                    # every animation style, with page changes in between
        win.setp._anim(key)
        for v in ("lib", "home", "set"):
            win.go_view(v)
            QTest.qWait(80)
    win.setp._anim("smooth")
    win._set_go("themes")
    win.setp._theme("midnight")
    win._set_go("data")
    win.setp._backup()
    QTest.keyClick(win, Qt.Key.Key_Escape)               # Esc: category -> overview -> home
    QTest.keyClick(win, Qt.Key.Key_Escape)
    win.go_view("home")
    for k in (Qt.Key.Key_Right, Qt.Key.Key_Right, Qt.Key.Key_Left, Qt.Key.Key_Escape):
        QTest.keyClick(win, k)
        QTest.qWait(60)
    for name in ("right", "left", "tab", "tab", "y", "b"):       # gamepad events
        win.pad_press(name)
        QTest.qWait(80)
    win.open_ach()
    QTest.qWait(600)
    win.close_all()
    win.close()


try:
    main()
except Exception:
    errors.append(traceback.format_exc())
if errors:
    print("SMOKE TEST FAILED\n" + "\n".join(errors))
    sys.exit(1)
print("smoke test OK")
