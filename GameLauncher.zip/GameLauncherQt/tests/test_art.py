"""Pictures the user chooses, web results, and the "never lose games" guard. Offline: the network is faked.
Run:  QT_QPA_PLATFORM=offscreen python tests/test_art.py"""
import os
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
tmp = tempfile.mkdtemp()
os.environ["GL_DATA_DIR"] = os.path.join(tmp, "data")

from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication

app = QApplication([])
from gl import paths, steam, store
from gl.backend import Backend

def png(path, w, h):
    im = QImage(w, h, QImage.Format.Format_RGB32)
    im.fill(QColor("#336699"))
    assert im.save(path)
    return path

be = Backend()
exe = os.path.join(tmp, "Cool Game", "cool.exe")
os.makedirs(os.path.dirname(exe))
open(exe, "w").write("x")
wide, tall, junk = png(os.path.join(tmp, "wide.png"), 3200, 1800), png(os.path.join(tmp, "tall.png"), 600, 900), os.path.join(tmp, "junk.png")
open(junk, "w").write("not a picture")

# ---- fake network
png_bytes = open(wide, "rb").read() + b"\0" * 3000
steam.http_get = lambda url, timeout=8, binary=False: png_bytes if binary else {}
steam.steam_search = lambda t: [{"id": 1, "name": "Cool Game"}]

# 1. a bad picture stops the add and saves nothing
try:
    be.add_game(exe, "Cool Game", False, None, True, junk, None)
    raise SystemExit("bad picture was accepted")
except ValueError:
    pass
assert be.games() == []

# 2. add with own background + own tile, no internet
g = be.add_game(exe, "Cool Game", False, None, False, wide, tall)
assert g["custom_hero"] and g["custom_cover"] and g["hero_path"] and g["cover_path"], g
assert QImage(g["hero_path"]).width() <= 2560, "big picture should be scaled down"
print("add with own pictures: ok")

# 3. changing them later
old_h = g["hero_path"]
be.set_custom_cover(g["id"], wide)
be.set_custom_art(g["id"], tall)
g2 = be.games()[0]
assert g2["cover_path"] != g["cover_path"] and g2["hero_path"] != old_h and not os.path.exists(old_h)
print("change background / tile: ok")

# 4. a web result: a wide picture -> background, tall -> tile, and a user's own picture is never replaced
g3 = be.games()[0]
png_bytes = open(wide, "rb").read() + b"\0" * 3000
assert steam.web_meta("x1", {"source": "img", "img": "http://a/b.jpg"}).get("hero")
png_bytes = open(tall, "rb").read() + b"\0" * 3000
ch = steam.web_meta("x2", {"source": "img", "img": "http://a/b.jpg"})
assert ch.get("cover") and ch.get("hero") == "", ch
assert steam.web_meta("x3", {"source": "img", "img": "http://a/b.jpg"}, custom_cover=True) == {}
print("web picture placement: ok")

# 5. the parsers
assert steam.clean_result_title("Elden Ring - Wikipedia") == "Elden Ring"
assert steam.clean_result_title("Hollow Knight on Steam") == "Hollow Knight"
html = ('<div><a href="/url?q=https://en.wikipedia.org/wiki/Hades_(video_game)&amp;sa=U"><h3 class="x">Hades (video game) - Wikipedia</h3></a>'
        '<a href="https://store.steampowered.com/app/1145360/Hades/"><div><h3>Hades on Steam</h3></div></a></div>')
steam.http_text = lambda url, timeout=8, limit=0, ua="": html
r = steam.google_search("hades")
print("google parse:", [(i["name"], i["page"][:30]) for i in (r or [])])
bing = ('<a class="iusc" style="x" m="{&quot;murl&quot;:&quot;http://img/hades.jpg&quot;,&quot;turl&quot;:&quot;http://t/1.jpg&quot;,'
        '&quot;t&quot;:&quot;Hades - Official Art&quot;,&quot;purl&quot;:&quot;http://p&quot;}"></a>')
steam.http_text = lambda url, timeout=8, limit=0, ua="": bing
r = steam.image_search("hades")
assert r and r[0]["img"] == "http://img/hades.jpg" and r[0]["name"] == "Hades", r
steam.http_text = lambda url, timeout=8, limit=0, ua="": '<meta property="og:image" content="/pic.jpg">'
assert steam.og_image("http://site.com/game/page") == "http://site.com/pic.jpg"
print("parsers: ok")

# 6. the data guard: no single action can drop several games, and an empty list never replaces a real one
for i in range(3):
    f = os.path.join(tmp, "g%d.exe" % i)
    open(f, "w").write("x")
    be.add_game(f, "G%d" % i, False)
n = len(be.games())
assert n == 4
try:
    store.mutate(lambda db: db.update(games=[]))
    raise SystemExit("guard failed")
except store.StoreError:
    pass
assert len(be.games()) == n
print("data guard: ok")
print("ALL ART TESTS PASSED")
