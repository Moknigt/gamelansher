@echo off
rem Trial version: opens the launcher with 8 made-up games (your real library is not touched).
cd /d "%~dp0"
python -m pip install -q -r requirements.txt
start "" pythonw main.py --demo
