# HANDOFF PROMPT - copy everything below into another AI (together with the zip, and the ORIGINAL GameLauncher.zip)

You are continuing a rewrite of a Windows PC game launcher from an HTML/WebView UI to a native Qt (PySide6, widgets) app.
The user speaks Egyptian Arabic (reply in Arabic, short and simple), dictates by voice, and wants the work in 3 PARTS so each step stays quick.
Do ONLY the part you are asked to do. Do not start the next part early.

## Source material
- ORIGINAL app: `GameLauncher/GameLauncher.pyw` (2172 lines: Python backend + the whole UI as an HTML string).
  UI/JS logic is at lines ~1100-2172, CSS ~1130-1530, backend API ~360-1100. Use it as the visual + behavior reference.
- NEW app (this zip): `GameLauncherQt/` - PySide6, everything custom-painted, same data folder `~/.mygamelauncher/games.json`
  (so the user's existing games, art and trophies carry over).

## What the user wants (from earlier chats)
- PC layout, games bar at the TOP (not bottom), PlayStation/Xbox feel, ASUS-launcher-like, blue theme, selected game not too big.
- Mockup: Home (games strip on top, big per-game background art, Play button, play-time + achievements card) and
  Library (grid, tabs All/Installed/Favorites/Most Played/Recently Added, sort), left side panel, Exit button bottom-left.
- Background art comes from each game (fetched online from Steam), not from the mockup.
- Achievements: show the game's real achievements, track them while playing, record them OFFLINE.
- The launcher must NOT keep running in the background while a game runs.

## THE 3 PARTS
- PART 1 = the INTERFACE only (DONE). PART 2 = Steam/online (DONE). PART 3 = helper/gamepad/build (DONE, written). Next = test on a real Windows PC and fix what shows up.
- PART 2 = Steam/online data: smart game-name guess, Steam search, art/logo/description download, "Edit game -> Steam search / use Steam art",
  retry missing pictures when online, REAL Steam achievements (cache the list so it shows offline, unlock state via API key + SteamID when online,
  manual tick otherwise, record unlocks offline), `Backend.steam_search / match_steam / reset_art / game_achievements(items) / ach_toggle`.
  Port from old file: guess_name, name_candidates, steam_search, best_match, fetch_meta, download_first, find_steam_match, api_art, _ach_steam, retry_missing_meta.
- PART 3 = play time + polish: optional hidden play-time helper (`--track <gameid>` process, exits as soon as the game closes, OFF by default),
  gamepad (XInput/pygame, same mapping as old JS: A=select, B=back, Y=achievements, LB/RB=Home<->Library, dpad/stick=move),
  PyInstaller GitHub workflow for PySide6 (replace the old build.yml), README, final bug pass.

## PART 1 STATUS - DONE (written AND run)
Tested headless (QT_QPA_PLATFORM=offscreen, PySide6 6.12): every screen was rendered and checked by screenshot, and a script
drove keyboard (arrows, Enter, Esc, F, A, L, /), search, add/duplicate/rename/remove, theme change, anim off, missing-game play error,
empty library. No runtime errors. NOT tested on real Windows with a real mouse/gamepad/sound (sound is disabled in headless mode).

### Files in `gl/`
paths, store, trophies, util, theme, icons, sfx, widgets, background, backend, demo (as before) +
pages_home.py, pages_library.py, pages_ach.py (Overview/All Games/Stats/Settings), drawer.py (trophy drawer),
dialogs.py (ModalHost, Add, Edit, Settings, Exit, Remove confirm, More menu), main_window.py (state + wiring + keys), `main.py`.
Fixes made while running: QSS reset of fonts (set stylesheet once, then setFont), QGraphicsOpacityEffect default 0.7 (FadeSwap sets 1.0),
wrapped labels need explicit height, audio disabled when offscreen.

### Small things left from Part 1 (optional)
- Library grid has no "Add game" tile (side panel and Home strip have it).
- Not verified on high-DPI Windows; fonts fall back (Cinzel -> Georgia, Segoe UI).

## PART 2 = NEXT (Steam/online data). Hooks already in place
- `Backend.steam_search(term)` -> should return {"items":[{"id":appid,"name":str}]} (EditCard.set_results accepts a dict with "items" or a list).
- `Backend.match_steam(gid, appid)`: link game, download art/logo/description, store appid/hero/cover/logo/desc/developer/genres.
- `Backend.reset_art(gid)`: go back to the Steam art (clears custom_hero).
- `Backend.add_game(path)`: after adding, guess the name + find the Steam match + download art (UI already shows Busy and a toast with the name).
- `Backend.game_achievements(gid)`: fill `items` [{id,name,desc,icon,achieved,rare}], `mode` ('steam'|'manual'|'none'), `note`, `total`, `unlocked`.
  The drawer already renders them (section "Steam achievements", rows are tappable when mode == 'manual' -> `Backend.ach_toggle(gid, ach_id)`).
- Port from the old file: guess_name, name_candidates, steam_search, best_match, fetch_meta, download_first, find_steam_match, api_art, _ach_steam, retry_missing_meta.
- Network work must not freeze the UI: run it in a QThread/worker or show Busy (the UI calls Backend synchronously today).

## PART 3 = AFTER THAT
Play-time helper (`--track <gameid>`, OFF by default), gamepad (XInput/pygame, A=select, B=back, Y=achievements, LB/RB=Home<->Library),
PyInstaller GitHub workflow for PySide6 (replace the old build.yml), README, final bug pass.

## RULES
- UI code never touches games.json or the network directly - only `Backend`.
- Keep Part-2/3 methods raising `NotYet`; the UI must show their message as a toast and keep working.
- After finishing Part 1, give the user a short Arabic summary + the same kind of handoff prompt for Part 2 (done / not done).


## PART 2 STATUS - DONE (written; partly tested)
New: `gl/steam.py` (ported web code: steam_search, best_match, download_first, fetch_meta, smart guess_name/name_candidates/clean_title,
find_steam_match, steam_achievements), `gl/worker.py` (`run_async(fn, done(result, error))` runs blocking work in a thread, callback on the UI thread).
`Backend`: add_game (guess + Steam match + art, offline-safe, returns `note`), steam_search -> {"items"}, match_steam, reset_art, game_achievements
(mode steam / manual / none, offline cache `ach_cache`, manual ticks in `ach_done`), ach_toggle, patch_game, start_meta_retry/stop_meta_retry
(daemon thread; fills missing art when online; window refreshes through the existing db_mtime poll). rename() sets `renamed`.
`main_window.py`: add, Edit search/pick/Use Steam art and the trophy drawer now call Backend through run_async with Busy.
TESTED: backend logic with a stubbed Qt and a fake network (add online/offline, duplicates, search, match, reset art, achievements steam/manual/offline cache, ticks, retry thread).
NOT TESTED: real PySide6 run (PySide6 could not be installed in the build sandbox), real Steam network, Windows. First thing to do next: run `python main.py --demo` and `python main.py`, add a real game, open Edit > Search, open the trophy drawer.
Known limits: real-achievement rows have no Steam icons (the drawer draws its own badge); manual mode only has Steam's ~10 highlighted achievements.


## PART 3 STATUS - DONE (written; partly tested)
New: `gl/tracker.py` (hidden helper `main.py --track <gameid>`: no Qt, starts the game, counts play time if `track_play`, exits when the game closes,
reopens the launcher if `reopen_after`; also reopens if the game could not start), `gl/gamepad.py` (XInput via ctypes; `GamepadLogic` = pure edge detection
with hold-repeat for directions; `Gamepad` QObject emits `pressed(name)`), `tests/smoke.py` (headless run of every screen, used by CI), `Run.bat`, `Run_Demo.bat`,
new `.github/workflows/build.yml` (PySide6 + PyInstaller onefile, smoke test first), `requirements.txt` (+psutil).
Changed: `Backend.play` (both options off = start the game directly and quit; either on = spawn the helper and quit), new setting `reopen_after` (store.py),
`main.py` handles `--track` before importing Qt, `MainWindow.pad_press` (same mapping as the old JS), Settings page rebuilt (sections: When I start a game / Trophies / Steam).
TESTED: tracker (count only, reopen only, both, broken game file), play() in both modes, gamepad edge/repeat logic - all with stubbed Qt on Linux.
NOT TESTED: anything with real PySide6, a real XInput pad, real Windows, the PyInstaller build, tests/smoke.py (they run in the GitHub workflow).
First thing next: run the workflow, read its log, fix the smoke-test/build errors if any, then try the exe with a real game (both helper options on and off).


## PART 4 (small edits) - DONE (written; backend logic tested with stubs, Qt part NOT run)
- Add game is now 2 steps: choose .exe -> `AddDetailsCard` (name, switch "picture/info from the internet", switch "use the online name", search by another name). `Backend.add_game(path, name, online, item, use_online_name)`.
- Search is no longer Steam-only: `steam.online_search` = Steam + GOG + Wikipedia (`Backend.online_search`, `match_online`). GOG/Wikipedia endpoints are written from memory and NOT tested on the real network.
- Edit game: switch `auto_art` (off = the launcher never changes that game's picture/name by itself; the retry thread skips it), "also use the found name" switch, results from all sources.
- Helper (hidden, no Qt) is ON by default (one-time migration `bg_v2` in store.py): Play closes the launcher window and the helper brings it back when the game closes. A Python process cannot go under ~1 MB.
- Animations: `NavGroup` side list/tabs glide (the indicator used to be reset on every refresh = no animation), eased hover, slide+fade when the list changes; settings gear (`Btn`) turns on hover and spins on click.


## ROUND 5 (Settings) - DONE (written; logic tested with stub-Qt, real Qt NOT run - PySide6 was not installable in the build sandbox)
The user asked for the work in two rounds: ROUND 5 = Settings only (this one), ROUND 6 = the rest (below).
- DATA LOSS FIX (`gl/store.py`): `load_db()` used to return an EMPTY library when games.json could not be read for a moment, and the next
  `mutate()` / `sync_trophies()` then saved that empty library over the user's games. Now: no file = fresh library; unreadable file = retry, then the
  newest backup, the broken file is copied to `backups/broken-*.json`, and if nothing is readable `StoreError` is raised and NOTHING is written.
  Every save keeps `games.json.bak` + rolling `backups/games-*.json` (one per 5 min, newest 12). `Backend.data_info / backup_now / restore_backup`.
  Callers handle `StoreError` (main.py start-up dialog, `MainWindow.reload` toast, tracker helper reopens the launcher). Test: `tests/test_store.py` (also in CI).
- NEW SETTINGS SCREEN (`gl/settings_page.py`): its own view `"set"` (gear button / Esc goes back category -> overview -> home). Overview = category cards,
  side list = categories: Themes (preview cards for all 16 themes), Animations (7 styles with a live dot preview), Display & Sound (language, brightness,
  particles, 24h clock, sound, volume), Games & Trophies (reopen/track play, pop-ups), Steam, Your data (backup now / restore last backup / open folder).
  Old `SettingsCard` modal and the Achievements > Settings sub-page were removed. `PAGE_VIEWS = ("ach","set")` in main_window replaces the old `view == "ach"` checks.
  `show_sub()` does not rebuild the same category when games.json changes on disk (it would reset sliders/typing).
- ANIMATION STYLES (`gl/theme.py` ANIMS: smooth, snappy, bouncy, slide, zoom, dreamy, off): every animation is registered with `T.tune(anim, ms, kind)`
  (kinds: main / nav / fade / ease) and re-tuned live when the style changes; `T.hover_k`, `T.dur()`. Old pref "on" becomes "smooth". `widgets.PageFx` plays the
  page entrance (fade / rise / slide / pop / zoom) on `go_view` and on category changes. i18n: all new strings have Arabic.
- NOT TESTED: real PySide6 run. First thing next: run `python tests/smoke.py` (CI does) and `python main.py --demo`, open Settings, click every theme/animation,
  check zoom/slide page transitions look right on a real window.

## ROUND 6 - DONE (written; real PySide6 6.12 offscreen run: smoke, flow_art, test_art, test_store all pass)
- DATA SAFETY on top of Round 5: `store.mutate` refuses any change that removes more than one game; `save_db` refuses to replace a library of 2+ games with an empty one
  (raises `StoreError`, forces a backup first). Tests: `tests/test_store.py`, `tests/test_art.py`.
- SEARCH (`steam.online_search`): Steam + GOG + Wikipedia + Google result page (`google_search`, falls back to `ddg_search`) + web images (`image_search`, Bing image page),
  all in parallel. Items: `{source: steam|gog|wiki|google|web|img, id, name, img, thumb?, page?}`. `web_meta` downloads the picture (or the page's og:image);
  wide = background, tall/square = tile. GOOGLE/BING/DDG PARSERS ARE WRITTEN FROM MEMORY AND TESTED ONLY ON SAMPLE HTML, NOT ON THE REAL NETWORK (they may need a tweak).
- ADD GAME: `AddDetailsCard` searches by itself when it opens; results are `ResultRow`s (thumbnail + name + source) in a scrolling list; the picked row stays marked.
  Two real pictures (`ArtPicker`: Background + Game tile) - tap = file picker; picking a result previews its pictures. `Backend.add_game(..., hero_file, cover_file)`.
- EDIT GAME: same two pickers (card stays open and refreshes), `Backend.set_custom_cover` + flag `custom_cover` (respected by fetch_meta/gog/wiki/web, match_online, retry loop).
- `ModalHost` scrolls the card when the window is shorter than the card. Fixed: `SmoothScroll.setWidget` order (QScrollArea re-enabled autofill), and `it.widget()` called twice after `setParent(None)` (crash) in dialogs/settings/drawer/pages_ach.
- NOT TESTED: real network, real Windows, real mouse. First thing next: run `python main.py`, add a real game, check the result list and both pickers.
