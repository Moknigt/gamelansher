"""Game Launcher (Qt). Run:  python main.py        (add --demo to try it with made-up games)"""
import os
import sys


def main():
    from PySide6.QtCore import QEvent, QObject
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication

    from gl import paths
    from gl.backend import Backend
    from gl.store import StoreError
    from gl.main_window import MainWindow
    from gl.sfx import sfx
    from gl.theme import T

    app = QApplication(sys.argv)
    if "--demo" in sys.argv:
        from gl import demo
        demo.make_demo()                      # sets GL_DATA_DIR, must run BEFORE the Backend is created
    app.setApplicationName("Game Launcher")
    here = os.path.dirname(os.path.abspath(__file__))
    ico = os.path.join(here, "icon.ico")
    if os.path.isfile(ico):
        app.setWindowIcon(QIcon(ico))
    app.setStyleSheet(T.qss())
    T.changed.connect(lambda: app.setStyleSheet(T.qss()))

    class Boot(QObject):                      # startup sound on the first key press / click
        done = False

        def eventFilter(self, _o, e):
            if not self.done and e.type() in (QEvent.Type.KeyPress, QEvent.Type.MouseButtonPress):
                self.done = True
                sfx.boot()
            return False

    boot = Boot()
    app.installEventFilter(boot)

    be = Backend()
    try:
        ui = be.settings().get("ui")
    except StoreError as ex:                  # the games file is damaged and there is no backup: stop, change nothing
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.critical(None, "Game Launcher", "%s\n\nYour games file is in: %s" % (ex, paths.DATA_DIR))
        sys.exit(1)
    T.load(ui)                                # theme + language BEFORE any widget is created
    be.start_meta_retry()                     # fills in missing pictures whenever the internet works
    app.aboutToQuit.connect(be.stop_meta_retry)
    win = MainWindow(be)
    win.reload(None, True)
    win.showMaximized()
    win.setFocus()
    sys.exit(app.exec())


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--track":     # the tiny hidden helper: no window, no Qt
        from gl.tracker import run_tracker
        run_tracker(sys.argv[2])
    else:
        main()
