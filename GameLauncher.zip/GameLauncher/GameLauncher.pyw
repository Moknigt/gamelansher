#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
My Game Launcher - a PlayStation-style game launcher for your PC.

Needs only Python 3.8+ (nothing else to install). Double-click GameLauncher.pyw to start.

- "+" button: pick a game's .exe; the game stays where it is, the launcher only remembers the path.
- Art, description and achievements come from Steam's public store pages (needs internet, optional).
- Picking a game starts it and closes the launcher. A tiny hidden helper keeps counting play time.
"""
import sys, os, json, time, threading, subprocess, shutil, secrets, uuid, re, difflib
import urllib.request, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

IS_WIN = os.name == "nt"
FROZEN = bool(getattr(sys, "frozen", False))      # True when running as the PyInstaller .exe
DATA_DIR = os.environ.get("GL_DATA_DIR") or os.path.join(os.path.expanduser("~"), ".mygamelauncher")
ART_DIR = os.path.join(DATA_DIR, "art")
DB_FILE = os.path.join(DATA_DIR, "games.json")
PROFILE_DIR = os.path.join(DATA_DIR, "browser_profile")
NOWIN = 0x08000000 if IS_WIN else 0                                   # CREATE_NO_WINDOW
DETACH = (0x00000008 | 0x00000200 | 0x08000000) if IS_WIN else 0      # detached helper process
UA = "Mozilla/5.0 (MyGameLauncher)"
GAME_EXTS = (".exe", ".lnk", ".bat", ".cmd")
DEVNULL = subprocess.DEVNULL


class ApiError(Exception):
    pass


class State:
    token = ""
    port = 0
    browser = None
    start = time.time()
    last_ping = 0.0
    seen_ping = False
    bye = 0.0


S = State()
DB_LOCK = threading.RLock()


# ----------------------------------------------------------------------------- storage
def load_db():
    try:
        with open(DB_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("games", [])
    st = d.setdefault("settings", {})
    st.setdefault("steam_key", "")
    st.setdefault("steam_id", "")
    st.setdefault("ui", {})
    st.setdefault("track_play", False)      # off = nothing stays running while a game is open
    return d


def save_db(d):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DB_FILE)


def mutate(fn):
    with DB_LOCK:
        db = load_db()
        r = fn(db)
        save_db(db)
        return r


def find_game(db, gid):
    for g in db["games"]:
        if g.get("id") == gid:
            return g
    raise ApiError("Game not found")


def remove_art_file(name):
    if not name:
        return
    p = os.path.join(ART_DIR, os.path.basename(name))
    try:
        os.remove(p)
    except OSError:
        pass


def patch_game(gid, changes):
    def fn(db):
        g = find_game(db, gid)
        for k in ("hero", "cover", "logo"):
            if k in changes and g.get(k) and g.get(k) != changes[k]:
                remove_art_file(g[k])
        g.update(changes)
        return dict(g)
    return mutate(fn)


def public(g):
    d = dict(g)
    d["hero_url"] = "/art/" + g["hero"] if g.get("hero") else ""
    d["cover_url"] = "/art/" + g["cover"] if g.get("cover") else ""
    d["logo_url"] = "/art/" + g["logo"] if g.get("logo") else ""
    d["installed"] = os.path.isfile(g.get("path", ""))
    names = {a.get("name") for a in g.get("ach_highlight", [])}
    done = [k for k, v in (g.get("ach_done") or {}).items() if v and (not names or k in names)]
    d["ach_unlocked"] = g.get("ach_unlocked", 0) if g.get("ach_cache") else len(done)
    tr = eval_defs(GAME_DEFS, g, g.get("trophies") or {}, "Unlock every trophy for this game")
    d["tro_total"] = len(tr)
    d["tro_unlocked"] = sum(1 for i in tr if i["achieved"])
    return d


# ----------------------------------------------------------------------------- web helpers
def http_get(url, timeout=8, binary=False):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    return data if binary else json.loads(data.decode("utf-8"))


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def steam_search(term):
    """Returns a list of {id, name}, or None when Steam can't be reached."""
    url = "https://store.steampowered.com/api/storesearch/?" + urllib.parse.urlencode(
        {"term": term, "l": "english", "cc": "us"})
    try:
        d = http_get(url)
    except Exception:
        return None
    out = []
    for i in d.get("items", []):
        if i.get("type", "app") == "app" and i.get("id"):
            out.append({"id": int(i["id"]), "name": i.get("name", "")})
    return out[:8]


def best_match(term, items):
    best, score = None, 0.0
    for it in items or []:
        r = difflib.SequenceMatcher(None, norm(term), norm(it["name"])).ratio()
        if r > score:
            best, score = it, r
    return best if best and score >= 0.6 else None


def download_first(urls, base):
    for u in urls:
        if not u:
            continue
        try:
            data = http_get(u, timeout=10, binary=True)
        except Exception:
            continue
        if len(data) < 2000:
            continue
        ext = os.path.splitext(urllib.parse.urlparse(u).path)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".webp"):
            ext = ".jpg"
        fn = "%s_%d%s" % (base, int(time.time() * 1000) % 10**9, ext)
        os.makedirs(ART_DIR, exist_ok=True)
        with open(os.path.join(ART_DIR, fn), "wb") as f:
            f.write(data)
        return fn
    return None


def fetch_meta(gid, appid, keep_custom_hero=True, custom_hero=False):
    """Collects art + info for a Steam app. Returns a dict of changes for the game."""
    ch = {"appid": int(appid), "meta_tried": time.time()}
    info = {}
    try:
        d = http_get("https://store.steampowered.com/api/appdetails?appids=%d&l=english" % appid)
        node = d.get(str(appid), {})
        if node.get("success"):
            info = node.get("data", {})
    except Exception:
        pass
    if info:
        ch["desc"] = info.get("short_description", "")
        ch["genres"] = [x.get("description", "") for x in info.get("genres", [])][:3]
        ch["developer"] = ", ".join(info.get("developers", [])[:2])
        ach = info.get("achievements") or {}
        ch["ach_total"] = ach.get("total", 0)
        ch["ach_highlight"] = [{"name": a.get("name", ""), "icon": a.get("path", "")}
                               for a in ach.get("highlighted", [])]
    cdn = "https://cdn.akamai.steamstatic.com/steam/apps/%d/" % appid
    if not (custom_hero and keep_custom_hero):
        fn = download_first([info.get("background_raw", ""), cdn + "page_bg_raw.jpg", cdn + "library_hero.jpg",
                             info.get("header_image", "")], gid + "_hero")   # full-screen (16:9) picture first
        if fn:
            ch["hero"] = fn
            ch["custom_hero"] = False
            ch["hero_v"] = 2
    fn = download_first([cdn + "library_600x900.jpg", info.get("header_image", "")], gid + "_cover")
    if fn:
        ch["cover"] = fn
    fn = download_first([cdn + "logo.png"], gid + "_logo")       # transparent game logo for the Home screen
    if fn:
        ch["logo"] = fn
    return ch


GENERIC = {"game", "launcher", "start", "run", "main", "play", "client", "app", "bin", "win64",
           "win32", "x64", "x86", "shipping", "binaries", "setup", "autorun"}


def guess_name(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    parent = os.path.dirname(path)
    name = stem
    if stem.lower() in GENERIC or len(stem) < 4:
        p = parent
        while p and os.path.basename(p).lower() in GENERIC:
            p = os.path.dirname(p)
        name = os.path.basename(p) or stem
    name = re.sub(r"[-_.]+", " ", name)
    name = re.sub(r"\b(win64|win32|shipping|x64|x86)\b", "", name, flags=re.I)
    return re.sub(r"\s+", " ", name).strip() or stem


JUNK_RE = re.compile(r"\b(codex|skidrow|plaza|reloaded|flt|gog|fitgirl|dodi|repack|razor1911|cpy|hoodlum|tenoke|prophet|"
                     r"goldberg|steamrip|rune|elamigos|kaos|empress|darksiders|crack(?:ed)?|multi\d*|update|build|setup|"
                     r"portable|dlcs?|bonus|v?\d+(?:\.\d+)+\w*|\d{5,}|win64|win32|x64|x86|shipping|nosteam|nodrm)\b", re.I)
EDITION_RE = re.compile(r"\b(goty|game of the year|definitive|complete|deluxe|ultimate|gold|standard|remastered|"
                        r"enhanced|edition|collection|anniversary)\b", re.I)
SKIP_DIRS = GENERIC | {"games", "program files", "program files (x86)", "steamapps", "common", "windows", "downloads",
                       "desktop", "steam", "gog games", "epic games", "repacks", "install", "installed", "data", "documents"}


def clean_title(s, strip_edition=False):
    """'Elden.Ring.v1.02-CODEX' -> 'Elden Ring', 'EldenRing' -> 'Elden Ring'."""
    s = re.sub(r"\[.*?\]|\(.*?\)", " ", s)
    s = JUNK_RE.sub(" ", s)
    if not re.search(r"[\s._+-]", s.strip()):
        s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s)
    s = JUNK_RE.sub(" ", re.sub(r"[-_.+]+", " ", s))
    if strip_edition:
        s = EDITION_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def name_candidates(path):
    """Possible game names from the exe name and the folders above it, best guess first."""
    parts = [os.path.splitext(os.path.basename(path))[0]]
    p = os.path.dirname(path)
    for _ in range(3):
        b = os.path.basename(p)
        if not b:
            break
        parts.append(b)
        p = os.path.dirname(p)
    out = []
    for x in parts:
        for strip in (False, True):
            c = clean_title(x, strip)
            if len(c) >= 3 and c.lower() not in SKIP_DIRS and c not in out:
                out.append(c)
    return out[:6]


def name_score(cand, item):
    a, b = norm(cand), norm(item)
    if not a or not b:
        return 0.0
    r = difflib.SequenceMatcher(None, a, b).ratio()
    ta, tb = set(a.split()), set(b.split())
    if (ta <= tb or tb <= ta) and min(len(a), len(b)) >= 4:      # one name contains the other
        r = max(r, 0.85 - 0.05 * abs(len(ta) - len(tb)))
    return r


def find_steam_match(path):
    """Searches Steam with every name guess. Returns (match or None, offline)."""
    best, bs, queries = None, 0.0, 0
    for c in name_candidates(path):
        words = c.split()
        for q in ([c] + ([" ".join(words[:2])] if len(words) > 3 else [])):
            if queries >= 6:
                break
            queries += 1
            items = steam_search(q)
            if items is None:
                return None, True
            for it in items:
                sc = name_score(c, it["name"])
                if sc > bs:
                    best, bs = it, sc
        if bs >= 0.9:
            break
    return (best if bs >= 0.55 else None), False


# ----------------------------------------------------------------------------- file dialogs
def pick_file(title, kind):
    """Opens a native file picker. Returns path, '' if cancelled, None if no dialog possible."""
    if kind == "exe":
        tk_types = "[('Games and programs','*.exe *.lnk *.bat *.cmd'),('All files','*.*')]"
        ps_filter = "Games and programs|*.exe;*.lnk;*.bat;*.cmd|All files|*.*"
    else:
        tk_types = "[('Images','*.jpg *.jpeg *.png *.webp *.bmp'),('All files','*.*')]"
        ps_filter = "Images|*.jpg;*.jpeg;*.png;*.webp;*.bmp|All files|*.*"
    out = os.path.join(DATA_DIR, "pick_%s.txt" % uuid.uuid4().hex)
    os.makedirs(DATA_DIR, exist_ok=True)
    code = (
        "import sys, tkinter as tk\n"
        "from tkinter import filedialog\n"
        "r = tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
        "p = filedialog.askopenfilename(title=%r, filetypes=%s)\n"
        "open(sys.argv[1], 'w', encoding='utf-8').write(p or '')\n" % (title, tk_types))
    ok = False
    if not FROZEN:      # inside the built .exe, sys.executable is the launcher itself, so skip tkinter
        try:
            r = subprocess.run([sys.executable, "-c", code, out], stdin=DEVNULL, stdout=DEVNULL,
                               stderr=DEVNULL, timeout=900, creationflags=NOWIN)
            ok = r.returncode == 0 and os.path.exists(out)
        except Exception:
            ok = False
    if not ok and IS_WIN:
        ps = ("Add-Type -AssemblyName System.Windows.Forms; "
              "$d = New-Object System.Windows.Forms.OpenFileDialog; $d.Filter = $env:GL_FILTER; "
              "$d.Title = $env:GL_TITLE; $r = ''; if ($d.ShowDialog() -eq 'OK') { $r = $d.FileName }; "
              "[IO.File]::WriteAllText($env:GL_OUT, $r, (New-Object Text.UTF8Encoding $false))")
        try:
            env = dict(os.environ, GL_FILTER=ps_filter, GL_TITLE=title, GL_OUT=out)
            subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], stdin=DEVNULL,
                           stdout=DEVNULL, stderr=DEVNULL, timeout=900, env=env, creationflags=NOWIN)
            ok = os.path.exists(out)
        except Exception:
            ok = False
    if not ok:
        return None
    try:
        with open(out, encoding="utf-8") as f:
            p = f.read().strip()
    except OSError:
        p = ""
    try:
        os.remove(out)
    except OSError:
        pass
    return os.path.normpath(p) if p else ""


# ----------------------------------------------------------------------------- trophies (made by the launcher, no Steam needed)
def _total_play(d):
    return sum(g.get("playtime", 0) for g in d["games"])


def _flag(d, name):
    return 1 if (d.get("flags") or {}).get(name) else 0


def _count(d, key):
    return sum(1 for g in d["games"] if g.get(key))


# (id, name, description, tier, icon, progress(subject) -> (current, target), kind: n=number t=time)
GLOBAL_DEFS = [
    ("add1", "Welcome Aboard", "Add your first game to the library", "bronze", "plus",
     lambda d: (len(d["games"]), 1), "n"),
    ("add5", "Collector", "Have 5 games in your library", "silver", "stack",
     lambda d: (len(d["games"]), 5), "n"),
    ("add15", "Game Vault", "Have 15 games in your library", "gold", "stack",
     lambda d: (len(d["games"]), 15), "n"),
    ("play1", "Player One", "Start a game from the launcher", "bronze", "play",
     lambda d: (sum(g.get("launches", 0) for g in d["games"]), 1), "n"),
    ("mix5", "Variety Pack", "Start 5 different games", "silver", "gamepad",
     lambda d: (sum(1 for g in d["games"] if g.get("launches", 0) > 0), 5), "n"),
    ("fav1", "Close to My Heart", "Mark a game as a favorite", "bronze", "heart",
     lambda d: (_count(d, "fav"), 1), "n"),
    ("art1", "Interior Designer", "Set your own background image for a game", "bronze", "image",
     lambda d: (_count(d, "custom_hero"), 1), "n"),
    ("steam1", "Connected", "Add your Steam key and ID in Settings", "silver", "link",
     lambda d: (1 if d["settings"].get("steam_key") and d["settings"].get("steam_id") else 0, 1), "n"),
    ("owl", "Night Owl", "Start a game between midnight and 5 AM", "silver", "moon",
     lambda d: (1 if (d.get("flags") or {}).get("night_owl") else 0, 1), "n"),
    ("lib", "Explorer", "Open the Library", "bronze", "lib",
     lambda d: (_flag(d, "lib"), 1), "n"),
    ("search", "Detective", "Search for a game", "bronze", "search",
     lambda d: (_flag(d, "search"), 1), "n"),
    ("settings", "Tweaker", "Open Settings", "bronze", "sliders",
     lambda d: (_flag(d, "settings"), 1), "n"),
    ("theme", "Stylist", "Change the theme", "silver", "star",
     lambda d: (_flag(d, "theme"), 1), "n"),
    ("sound", "Sound Check", "Switch the sound effects on or off", "bronze", "spk",
     lambda d: (_flag(d, "sound"), 1), "n"),
    ("kbd", "Keyboard Warrior", "Move around with the arrow keys", "bronze", "dpad",
     lambda d: (_flag(d, "kbd"), 1), "n"),
    ("pad", "Controller Ready", "Use a gamepad", "silver", "gamepad",
     lambda d: (_flag(d, "pad"), 1), "n"),
    ("fav3", "Curator", "Have 3 favorite games", "silver", "heart",
     lambda d: (_count(d, "fav"), 3), "n"),
    ("early", "Early Bird", "Start a game between 5 and 9 AM", "silver", "sun",
     lambda d: (_flag(d, "early_bird"), 1), "n"),
    ("hab25", "Creature of Habit", "Start games 25 times in total", "gold", "play",
     lambda d: (sum(g.get("launches", 0) for g in d["games"]), 25), "n"),
    ("hrs10", "Getting Hooked", "Play 10 hours in total", "silver", "clock",
     lambda d: (_total_play(d), 36000), "t"),
    ("hrs100", "No Days Off", "Play 100 hours in total", "gold", "clock",
     lambda d: (_total_play(d), 360000), "t"),
]

GAME_DEFS = [
    ("first", "First Launch", "Start this game from the launcher", "bronze", "play",
     lambda g: (g.get("launches", 0), 1), "n"),
    ("l10", "Regular", "Start this game 10 times", "silver", "play",
     lambda g: (g.get("launches", 0), 10), "n"),
    ("l25", "Loyal Fan", "Start this game 25 times", "gold", "play",
     lambda g: (g.get("launches", 0), 25), "n"),
    ("t30", "Warming Up", "Play for 30 minutes", "bronze", "clock",
     lambda g: (g.get("playtime", 0), 1800), "t"),
    ("t1h", "One More Hour", "Play for 1 hour", "bronze", "clock",
     lambda g: (g.get("playtime", 0), 3600), "t"),
    ("t5h", "Hooked", "Play for 5 hours", "silver", "clock",
     lambda g: (g.get("playtime", 0), 18000), "t"),
    ("t20h", "Veteran", "Play for 20 hours", "gold", "clock",
     lambda g: (g.get("playtime", 0), 72000), "t"),
    ("t50h", "Legend", "Play for 50 hours", "gold", "clock",
     lambda g: (g.get("playtime", 0), 180000), "t"),
    ("fav", "Favorite", "Add this game to your favorites", "bronze", "heart",
     lambda g: (1 if g.get("fav") else 0, 1), "n"),
    ("style", "Your Style", "Set your own background image", "bronze", "image",
     lambda g: (1 if g.get("custom_hero") else 0, 1), "n"),
    ("steam", "Matched", "Link this game to its Steam page", "bronze", "link",
     lambda g: (1 if g.get("appid") else 0, 1), "n"),
]


def eval_defs(defs, subject, store, plat_desc):
    """Progress of every trophy (plus the Platinum for finishing them all). Pure, saves nothing."""
    items = []
    for tid, name, desc, tier, icon, fn, kind in defs:
        cur, tgt = fn(subject)
        rec = store.get(tid)
        items.append({"id": tid, "name": name, "desc": desc, "tier": tier, "icon": icon,
                      "cur": min(cur, tgt), "target": tgt, "kind": kind,
                      "achieved": bool(rec) or cur >= tgt, "ts": (rec or {}).get("ts", 0)})
    done = sum(1 for i in items if i["achieved"])
    rec = store.get("plat")
    items.append({"id": "plat", "name": "Platinum", "desc": plat_desc, "tier": "plat", "icon": "trophy",
                  "cur": done, "target": len(items), "kind": "n",
                  "achieved": bool(rec) or done == len(items), "ts": (rec or {}).get("ts", 0)})
    return items


def _record(items, store, silent, label):
    """Remembers newly earned trophies; returns (changed, popups-not-shown-yet)."""
    changed, now = False, time.time()
    for i in items:
        if i["achieved"] and i["id"] not in store:
            store[i["id"]] = {"ts": now, "seen": bool(silent)}
            changed = True
    new = []
    for i in items:
        r = store.get(i["id"])
        if r is not None and not r.get("seen"):
            r["seen"] = True
            changed = True
            new.append({"name": i["name"], "tier": i["tier"], "icon": i["icon"], "game": label})
    return changed, new


def sync_trophies():
    """Unlocks whatever has been earned since last time. Returns trophies to announce."""
    with DB_LOCK:
        db = load_db()
        silent = "trophies" not in db      # first run of this version: unlock quietly, no pop-up flood
        store = db.setdefault("trophies", {})
        changed, new = _record(eval_defs(GLOBAL_DEFS, db, store, "Unlock every launcher trophy"),
                               store, silent, None)
        changed = changed or silent
        for g in db["games"]:
            st = g.setdefault("trophies", {})
            c, n = _record(eval_defs(GAME_DEFS, g, st, "Unlock every trophy for this game"),
                           st, silent, g.get("name"))
            changed, new = changed or c, new + n
        if changed:
            save_db(db)
        return new


# ----------------------------------------------------------------------------- API
def api_games(_q=None, _b=None):
    new = sync_trophies()
    db = load_db()
    return {"games": [public(g) for g in db["games"]], "settings": db["settings"], "new": new}


def api_trophies(_q=None, _b=None):
    new = sync_trophies()
    db = load_db()
    items = eval_defs(GLOBAL_DEFS, db, db.get("trophies") or {}, "Unlock every launcher trophy")
    return {"items": items, "unlocked": sum(1 for i in items if i["achieved"]),
            "total": len(items), "new": new}


def api_ach_overview(_q=None, _b=None):
    """Everything the Achievements page needs: launcher trophies + the trophy set of every game."""
    new = sync_trophies()
    db = load_db()
    launcher = eval_defs(GLOBAL_DEFS, db, db.get("trophies") or {}, "Unlock every launcher trophy")
    games = []
    for g in db["games"]:
        pg = public(g)
        items = eval_defs(GAME_DEFS, g, g.get("trophies") or {}, "Unlock every trophy for this game")
        games.append({"id": g["id"], "name": g.get("name", ""), "cover_url": pg["cover_url"],
                      "hero_url": pg["hero_url"], "items": items})
    return {"launcher": launcher, "games": games, "new": new}


def api_ping(_q=None, _b=None):
    S.last_ping = time.time()
    S.seen_ping = True
    try:
        rev = os.path.getmtime(DB_FILE)
    except OSError:
        rev = 0
    return {"rev": rev}


def api_bye(_q=None, _b=None):
    S.bye = time.time()
    return {"ok": True}


def api_quit(_q=None, _b=None):
    threading.Timer(0.3, stop_all).start()
    return {"ok": True}


def api_add(_q, body):
    path = body.get("path")
    if not path:
        path = pick_file("Choose the game file (.exe)", "exe")
        if path is None:
            raise ApiError("nodialog")
        if path == "":
            raise ApiError("cancelled")
    path = os.path.normpath(str(path).strip().strip('"'))
    if not os.path.isfile(path):
        raise ApiError("File not found: " + path)
    if not path.lower().endswith(GAME_EXTS):
        raise ApiError("Please pick an .exe file (or a shortcut / .bat)")
    db = load_db()
    for g in db["games"]:
        if os.path.normcase(g["path"]) == os.path.normcase(path):
            raise ApiError("This game is already in your library")
    gid = uuid.uuid4().hex[:12]
    g = {"id": gid, "name": (name_candidates(path) or [guess_name(path)])[0], "path": path, "playtime": 0, "last_played": 0,
         "added": time.time(), "appid": None, "desc": "", "genres": [], "ach_done": {},
         "ach_total": 0, "ach_highlight": [], "meta_tried": time.time()}
    note, matched = "", False
    m, offline = find_steam_match(path)
    if offline:
        note = "No internet, so the game was added without a picture. It looks again next time you open the launcher online."
        g["meta_tried"] = 0
    elif m:
        g["name"] = m["name"]
        g.update(fetch_meta(gid, m["id"]))
        matched = True
    else:
        note = "Couldn't find a picture for this game online. Open Edit to search by name or pick your own image."

    def fn(db):
        db["games"].append(g)
    mutate(fn)
    return {"game": public(g), "note": note, "matched": matched}


def api_update(_q, body):
    gid = body.get("id")
    db = load_db()
    g = find_game(db, gid)
    ch = {}
    if isinstance(body.get("name"), str) and body["name"].strip():
        ch["name"] = body["name"].strip()
        ch["renamed"] = True            # the user chose this name: auto-lookup must not change it
    if body.get("appid"):
        ch.update(fetch_meta(gid, int(body["appid"]), True, bool(g.get("custom_hero"))))
    return {"game": public(patch_game(gid, ch))}


def api_search(q, _b=None):
    term = (q.get("term", [""])[0]).strip()
    if not term:
        return {"items": []}
    items = steam_search(term)
    if items is None:
        raise ApiError("Can't reach Steam - check your internet connection")
    return {"items": items}


def api_remove(_q, body):
    gid = body.get("id")

    def fn(db):
        g = find_game(db, gid)
        remove_art_file(g.get("hero"))
        remove_art_file(g.get("cover"))
        remove_art_file(g.get("logo"))
        db["games"].remove(g)
    mutate(fn)
    return {"ok": True}


def api_art(_q, body):
    gid = body.get("id")
    db = load_db()
    g = find_game(db, gid)
    if body.get("reset"):
        if not g.get("appid"):
            raise ApiError("Pick a Steam page first")
        return {"game": public(patch_game(gid, fetch_meta(gid, g["appid"], False)))}
    path = body.get("path")
    if not path:
        path = pick_file("Choose a background image", "img")
        if path is None:
            raise ApiError("nodialog")
        if path == "":
            raise ApiError("cancelled")
    path = os.path.normpath(str(path).strip().strip('"'))
    ext = os.path.splitext(path)[1].lower()
    if not os.path.isfile(path) or ext not in (".jpg", ".jpeg", ".png", ".webp", ".bmp"):
        raise ApiError("Please pick an image file (jpg, png, webp)")
    os.makedirs(ART_DIR, exist_ok=True)
    fn = "%s_hero_%d%s" % (gid, int(time.time() * 1000) % 10**9, ext)
    shutil.copyfile(path, os.path.join(ART_DIR, fn))
    ch = {"hero": fn, "custom_hero": True}
    if not g.get("cover"):
        cfn = "%s_cover_%d%s" % (gid, int(time.time() * 1000) % 10**9, ext)
        shutil.copyfile(path, os.path.join(ART_DIR, cfn))
        ch["cover"] = cfn
    return {"game": public(patch_game(gid, ch))}


UI_CHOICES = {"theme": {"midnight", "aurora", "ruby", "violet", "sunset", "mono"}, "anim": {"on", "off"}}
UI_TYPES = {"particles": bool, "sfx": bool, "clock24": bool, "popups": bool, "popsfx": bool,
            "vol": (int, float), "dim": (int, float)}


def api_settings(_q, body):
    def fn(db):
        st = db["settings"]
        for k in ("steam_key", "steam_id"):
            if k in body:
                st[k] = str(body[k]).strip()
        if "track_play" in body:
            st["track_play"] = bool(body["track_play"])
        ui = body.get("ui")
        if isinstance(ui, dict):
            cur = st.setdefault("ui", {})
            for k, ok in UI_CHOICES.items():
                if ui.get(k) in ok:
                    cur[k] = ui[k]
            for k, t in UI_TYPES.items():
                if isinstance(ui.get(k), t):
                    cur[k] = ui[k]
    mutate(fn)
    return {"ok": True}


def api_ach_toggle(_q, body):
    gid, name = body.get("id"), str(body.get("name", ""))

    def fn(db):
        g = find_game(db, gid)
        d = g.setdefault("ach_done", {})
        if d.get(name):
            d.pop(name, None)
        else:
            d[name] = time.time()      # saved on this PC with the date, no internet needed
    mutate(fn)
    return {"ok": True}


def api_fav(_q, body):
    gid = body.get("id")

    def fn(db):
        g = find_game(db, gid)
        g["fav"] = not g.get("fav")
    mutate(fn)
    return {"ok": True}


def _ach_steam(q):
    gid = q.get("id", [""])[0]
    db = load_db()
    g = find_game(db, gid)
    appid = g.get("appid")
    if not appid:
        return {"mode": "none", "items": [], "total": 0, "unlocked": 0,
                "note": "Pick this game's Steam page first (Edit > Steam page) to see its achievements."}
    key = db["settings"].get("steam_key", "").strip()
    sid = db["settings"].get("steam_id", "").strip()
    note = ""
    if key and sid:
        try:
            base = "https://api.steampowered.com/ISteamUserStats/"
            schema = http_get(base + "GetSchemaForGame/v2/?" + urllib.parse.urlencode(
                {"key": key, "appid": appid, "l": "english"}))
            defs = schema.get("game", {}).get("availableGameStats", {}).get("achievements", [])
            pl = http_get(base + "GetPlayerAchievements/v1/?" + urllib.parse.urlencode(
                {"key": key, "steamid": sid, "appid": appid, "l": "english"}))
            done = {a.get("apiname"): bool(a.get("achieved")) for a in
                    pl.get("playerstats", {}).get("achievements", [])}
            items = []
            for d in defs:
                ok = done.get(d.get("name"), False)
                items.append({"id": d.get("name"), "name": d.get("displayName", d.get("name")),
                              "desc": d.get("description", ""),
                              "icon": d.get("icon") if ok else d.get("icongray") or d.get("icon"),
                              "achieved": ok})
            items.sort(key=lambda x: not x["achieved"])
            patch_game(gid, {"ach_cache": items, "ach_total": len(items),
                             "ach_unlocked": sum(1 for i in items if i["achieved"])})
            return {"mode": "steam", "items": items, "total": len(items),
                    "unlocked": sum(1 for i in items if i["achieved"]),
                    "note": "" if items else "This game has no achievements."}
        except Exception:
            if g.get("ach_cache"):
                its = g["ach_cache"]
                return {"mode": "steam", "items": its, "total": len(its), "unlocked": g.get("ach_unlocked", 0),
                        "note": "No connection, so this is the last list saved on this PC."}
            note = ("Couldn't read your Steam progress. This works for games you own on Steam, and your "
                    "Steam profile's game details must be Public. ")
    done = g.get("ach_done", {})
    items = [{"id": a["name"], "name": a["name"], "desc": "", "icon": a.get("icon", ""),
              "achieved": bool(done.get(a["name"]))} for a in g.get("ach_highlight", [])]
    total = g.get("ach_total", 0) or len(items)
    note += ("Showing the game's top achievements; tap one to tick it yourself. Add your Steam API key "
             "in Settings to see your real progress for Steam games.") if items else \
        "No achievements found for this game."
    return {"mode": "manual", "items": items, "total": total,
            "unlocked": sum(1 for i in items if i["achieved"]), "note": note}


def api_achievements(q, _b=None):
    res = _ach_steam(q)
    new = sync_trophies()
    g = find_game(load_db(), q.get("id", [""])[0])
    res["custom"] = eval_defs(GAME_DEFS, g, g.get("trophies") or {}, "Unlock every trophy for this game")
    res["new"] = new
    return res


FLAG_NAMES = {"lib", "search", "settings", "theme", "sound", "kbd", "pad"}


def api_flag(_q, body):
    """The page tells us which things the user has tried (for the 'try it' trophies)."""
    name = str(body.get("name", ""))
    if name not in FLAG_NAMES:
        raise ApiError("unknown flag")

    def fn(db):
        db.setdefault("flags", {})[name] = True
    if not (load_db().get("flags") or {}).get(name):
        mutate(fn)
    return {"ok": True}


def api_play(_q, body):
    gid = body.get("id")
    db = load_db()
    g = find_game(db, gid)
    if not os.path.isfile(g["path"]):
        raise ApiError("The game file is missing: " + g["path"])

    def count_launch(db):
        gg = find_game(db, gid)
        gg["launches"] = gg.get("launches", 0) + 1
        gg["last_played"] = time.time()
        if 0 <= time.localtime().tm_hour < 5:
            db.setdefault("flags", {})["night_owl"] = True
        if 5 <= time.localtime().tm_hour < 9:
            db.setdefault("flags", {})["early_bird"] = True
    mutate(count_launch)
    if db["settings"].get("track_play"):
        if FROZEN:
            args = [sys.executable, "--track", gid]
        else:
            args = [sys.executable, os.path.abspath(__file__), "--track", gid]
        env = dict(os.environ)
        env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"      # helper must not reuse this process's temp folder
        kw = dict(stdin=DEVNULL, stdout=DEVNULL, stderr=DEVNULL, close_fds=True, env=env)
        if IS_WIN:
            kw["creationflags"] = DETACH
        else:
            kw["start_new_session"] = True
        subprocess.Popen(args, **kw)
    else:
        patch_game(gid, {"last_played": time.time()})
        path, folder = g["path"], os.path.dirname(g["path"])
        try:
            if IS_WIN and not path.lower().endswith(".exe"):
                os.startfile(path)
            else:
                kw = dict(cwd=folder, stdin=DEVNULL, stdout=DEVNULL, stderr=DEVNULL, close_fds=True)
                if IS_WIN:
                    kw["creationflags"] = DETACH
                else:
                    kw["start_new_session"] = True
                subprocess.Popen([path], **kw)
        except OSError:
            if not IS_WIN:
                raise ApiError("Couldn't start the game")
            os.startfile(path)                  # games that ask for admin rights
    threading.Timer(0.9, stop_all).start()
    return {"ok": True}


GET_ROUTES = {"/api/games": api_games, "/api/ping": api_ping, "/api/search": api_search,
              "/api/achievements": api_achievements,
              "/api/trophies": api_trophies, "/api/ach_overview": api_ach_overview}
POST_ROUTES = {"/api/add": api_add, "/api/update": api_update, "/api/remove": api_remove,
               "/api/art": api_art, "/api/settings": api_settings, "/api/ach_toggle": api_ach_toggle,
               "/api/play": api_play, "/api/flag": api_flag, "/api/fav": api_fav, "/api/quit": api_quit, "/api/bye": api_bye}


def retry_missing_meta():
    """In the background, the whole time the launcher is open: whenever the internet works, games without a
    picture (added offline, not matched yet, or whose art failed to download) get their picture, info and
    proper name by themselves. The page notices the change and refreshes on its own."""
    time.sleep(2)
    while True:
        try:
            now, todo = time.time(), []
            for g in load_db()["games"]:
                if g.get("custom_hero"):
                    continue
                tried = g.get("meta_tried", 0)
                if not g.get("appid"):
                    if now - tried > (60 if not tried else 3600):      # added offline: retry fast; no match: hourly
                        todo.append(g)
                elif (not g.get("hero") and not g.get("cover") or g.get("hero_v") != 2) and now - tried > 300:   # also upgrades older, narrow pictures
                    todo.append(g)
        except Exception:
            todo = []
        for g in todo:
            try:
                if g.get("appid"):
                    ch = fetch_meta(g["id"], g["appid"])
                else:
                    m, offline = find_steam_match(g["path"])
                    if offline:
                        break
                    ch = {"meta_tried": time.time()}
                    if m:
                        ch = fetch_meta(g["id"], m["id"])
                        if not g.get("renamed"):
                            ch["name"] = m["name"]
                patch_game(g["id"], ch)
            except Exception:
                pass
        time.sleep(60)


# ----------------------------------------------------------------------------- HTTP server
class Handler(BaseHTTPRequestHandler):
    server_version = "GameLauncher/1.0"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", cache="no-store"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        try:
            self.wfile.write(body)
        except OSError:
            pass

    def _host_ok(self):
        return self.headers.get("Host", "") in ("127.0.0.1:%d" % S.port, "localhost:%d" % S.port)

    def _auth(self, q):
        return self.headers.get("X-Token") == S.token or q.get("t", [""])[0] == S.token

    def _dispatch(self, routes, q, body):
        fn = routes.get(urllib.parse.urlparse(self.path).path)
        if not fn:
            return self._send(404, {"error": "not found"})
        if not self._auth(q):
            return self._send(403, {"error": "forbidden"})
        try:
            self._send(200, fn(q, body))
        except ApiError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:
            self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path == "/":
            return self._send(200, INDEX_HTML.replace("__TOKEN__", S.token), "text/html; charset=utf-8")
        if u.path.startswith("/art/"):
            fn = os.path.basename(urllib.parse.unquote(u.path[5:]))
            p = os.path.join(ART_DIR, fn)
            if os.path.isfile(p):
                ext = os.path.splitext(fn)[1].lower()
                ct = {".png": "image/png", ".webp": "image/webp", ".bmp": "image/bmp"}.get(ext, "image/jpeg")
                with open(p, "rb") as f:
                    return self._send(200, f.read(), ct, "max-age=86400")
            return self._send(404, b"", "text/plain")
        self._dispatch(GET_ROUTES, q, None)

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
        except ValueError:
            body = {}
        self._dispatch(POST_ROUTES, q, body if isinstance(body, dict) else {})


# ----------------------------------------------------------------------------- window / lifecycle
def find_browser():
    cands = []
    if IS_WIN:
        for env in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData"):
            base = os.environ.get(env)
            if base:
                cands += [os.path.join(base, r"Microsoft\Edge\Application\msedge.exe"),
                          os.path.join(base, r"Google\Chrome\Application\chrome.exe"),
                          os.path.join(base, r"BraveSoftware\Brave-Browser\Application\brave.exe")]
    elif sys.platform == "darwin":
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    for n in ("microsoft-edge", "google-chrome", "chromium", "chromium-browser"):
        w = shutil.which(n)
        if w:
            cands.append(w)
    for c in cands:
        if os.path.isfile(c):
            return c
    return None


def open_window(url):
    exe = find_browser()
    if exe:
        try:
            os.makedirs(PROFILE_DIR, exist_ok=True)
            S.browser = subprocess.Popen(
                [exe, "--app=" + url, "--user-data-dir=" + PROFILE_DIR, "--start-maximized",
                 "--no-first-run", "--no-default-browser-check", "--disable-background-mode"],
                stdin=DEVNULL, stdout=DEVNULL, stderr=DEVNULL)
            return
        except OSError:
            pass
    import webbrowser
    webbrowser.open(url)


def stop_all():
    b = S.browser
    if b is not None and b.poll() is None:
        try:
            if IS_WIN:
                subprocess.run(["taskkill", "/PID", str(b.pid), "/T", "/F"], stdin=DEVNULL,
                               stdout=DEVNULL, stderr=DEVNULL, timeout=10, creationflags=NOWIN)
            else:
                b.terminate()
        except Exception:
            pass
    os._exit(0)


def main():
    os.makedirs(ART_DIR, exist_ok=True)
    S.token = secrets.token_hex(16)
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    S.port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    threading.Thread(target=retry_missing_meta, daemon=True).start()
    url = "http://127.0.0.1:%d/" % S.port
    if os.environ.get("GL_NO_BROWSER"):
        print(url, flush=True)
    else:
        open_window(url)
    try:
        while True:
            time.sleep(1)
            now = time.time()
            if S.bye and S.last_ping < S.bye and now - S.bye > 4:
                stop_all()
            if S.seen_ping and now - S.last_ping > 90:
                stop_all()
            if not S.seen_ping and now - S.start > 120:
                stop_all()
    except KeyboardInterrupt:
        stop_all()


# ----------------------------------------------------------------------------- play-time tracker
def folder_has_running(folder):
    """True if some process is running from inside `folder` (for launchers that start the real game)."""
    prefix = os.path.normcase(os.path.abspath(folder)).rstrip("\\/") + os.sep
    try:
        import psutil
        me = os.getpid()
        for p in psutil.process_iter(["exe"]):
            try:
                exe = p.info.get("exe")
                if exe and p.pid != me and os.path.normcase(exe).startswith(prefix):
                    return True
            except Exception:
                pass
        return False
    except ImportError:
        pass
    if IS_WIN:
        ps = ("$d=$env:GL_DIR; if (Get-Process | Where-Object { $_.Path -and "
              "$_.Path.StartsWith($d,[StringComparison]::OrdinalIgnoreCase) }) {'1'} else {'0'}")
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                               stdin=DEVNULL, capture_output=True, text=True, timeout=40,
                               env=dict(os.environ, GL_DIR=prefix), creationflags=NOWIN)
            return r.stdout.strip() == "1"
        except Exception:
            return False
    return False


def add_playtime(gid, secs):
    if secs <= 0:
        return

    def fn(db):
        try:
            g = find_game(db, gid)
        except ApiError:
            return
        g["playtime"] = int(g.get("playtime", 0) + secs)
    mutate(fn)


def run_tracker(gid):
    try:
        g = find_game(load_db(), gid)
    except ApiError:
        return
    path = g["path"]
    folder = os.path.dirname(path)
    patch_game(gid, {"last_played": time.time()})
    t0 = time.time()
    popen = None
    try:
        if path.lower().endswith(".exe"):
            popen = subprocess.Popen([path], cwd=folder)
        else:
            raise OSError("use shell")
    except OSError:
        try:
            if IS_WIN:
                os.startfile(path)          # shortcuts, .bat files and games that ask for admin rights
            else:
                popen = subprocess.Popen([path], cwd=folder)
        except Exception:
            return
    popen_end = [None]

    def alive():
        if popen is not None:
            if popen.poll() is None:
                return True
            if popen_end[0] is None:
                popen_end[0] = time.time()
            if popen_end[0] - t0 >= 30:      # a real game process that ran a while and ended
                return False
        return folder_has_running(folder)    # stub launcher or shortcut: watch the game folder

    started = last_seen = last_flush = None
    deadline = t0 + 120                      # give the game two minutes to show up
    while True:
        now = time.time()
        if alive():
            if started is None:
                started = last_flush = now
            last_seen = now
            if now - last_flush >= 60:
                add_playtime(gid, now - last_flush)
                last_flush = now
        else:
            if started is not None:
                add_playtime(gid, last_seen - last_flush)
                return
            if now > deadline:
                return
        time.sleep(3 if (popen is not None and popen.poll() is None) else 8)


# ----------------------------------------------------------------------------- the interface
INDEX_HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Game Launcher</title>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<style>
*{box-sizing:border-box}
html,body{height:100%;margin:0}
:root{--ac:#3a86ff;--ac2:#7be0ff;--acr:47,123,255;--base:#050816;--onac:#fff;--br:1;--sw:252px;--tb:78px;--ease:cubic-bezier(.22,1,.36,1);
  --panel:linear-gradient(180deg,rgba(22,36,82,.66),rgba(8,12,34,.72));--panel2:linear-gradient(180deg,rgba(18,30,70,.55),rgba(8,12,32,.62))}
:root[data-theme=aurora]{--ac:#1fd1a5;--ac2:#8ff5d8;--acr:31,209,165;--base:#03100e;--onac:#032a22}
:root[data-theme=ruby]{--ac:#ff4d63;--ac2:#ffa0ab;--acr:255,77,99;--base:#14050a;--onac:#fff}
:root[data-theme=violet]{--ac:#9b6bff;--ac2:#d0b8ff;--acr:155,107,255;--base:#0c0618;--onac:#fff}
:root[data-theme=sunset]{--ac:#ff8a3d;--ac2:#ffd08a;--acr:255,138,61;--base:#140a05;--onac:#2a1100}
:root[data-theme=mono]{--ac:#d9dde6;--ac2:#fff;--acr:200,206,220;--base:#08090c;--onac:#0a0d16}
body{color:#fff;font-family:"Segoe UI",system-ui,-apple-system,Roboto,sans-serif;overflow:hidden;user-select:none;
  background:radial-gradient(900px 520px at 12% 100%,rgba(var(--acr),.5),transparent 62%),radial-gradient(1100px 560px at 100% 100%,rgba(var(--acr),.4),transparent 60%),radial-gradient(700px 400px at 60% 0%,rgba(var(--acr),.22),transparent 70%),var(--base)}
button{font-family:inherit}
.hide{display:none!important}
.ic{width:20px;height:20px;flex:0 0 auto;display:block}
i.i{display:flex;font-style:normal}

/* ---------- background ---------- */
#aurora{position:fixed;inset:0;overflow:hidden;z-index:0;pointer-events:none}
#aurora i{position:absolute;width:60vw;height:60vw;border-radius:50%;background:radial-gradient(circle,rgba(var(--acr),.38),transparent 65%);filter:blur(30px);animation:drift 26s ease-in-out infinite alternate}
#aurora i:nth-child(1){left:-15vw;top:30vh}#aurora i:nth-child(2){right:-20vw;top:-25vh;opacity:.7;animation-duration:34s;animation-delay:-9s}
@keyframes drift{to{transform:translate(12vw,-10vh) scale(1.18)}}
.bg{position:fixed;inset:0;filter:brightness(var(--br));transition:opacity .5s}
.bg div{position:absolute;inset:0;background-size:cover;background-position:center 20%;opacity:0;transition:opacity .9s ease;animation:kb 28s ease-in-out infinite alternate;will-change:opacity,transform}
.bg div.on{opacity:1}
@keyframes kb{from{transform:scale(1)}to{transform:scale(1.08) translate(-1%,-1%)}}
.shade{position:fixed;inset:0;transition:opacity .5s;background:linear-gradient(90deg,rgba(3,6,20,.82) 0%,rgba(3,6,20,.35) 45%,rgba(3,6,20,0) 75%),linear-gradient(180deg,rgba(3,6,20,.75) 0%,rgba(3,6,20,0) 30%,rgba(3,6,20,0) 62%,rgba(3,6,20,.88) 100%)}
body.libv .bg,body.libv .shade{opacity:0}
body.achv .bg{opacity:.55}
body.achv #foot{display:none}
body.achv .shade{background:linear-gradient(90deg,rgba(3,6,20,.96) 0%,rgba(3,6,20,.72) 42%,rgba(3,6,20,.2) 100%),linear-gradient(180deg,rgba(3,6,20,.7) 0%,rgba(3,6,20,0) 30%,rgba(3,6,20,.9) 100%)}
#fx{position:fixed;inset:0;z-index:1;pointer-events:none}

/* ---------- top bar ---------- */
#top{position:fixed;left:0;right:0;top:0;height:var(--tb);z-index:8;display:flex;align-items:center;gap:30px;padding:6px 32px 0 22px}
#brand{display:flex;align-items:center;gap:12px;width:calc(var(--sw) - 22px);flex:0 0 auto}
#brand .lm{width:46px;height:46px;flex:0 0 auto;filter:drop-shadow(0 4px 14px rgba(var(--acr),.55))}
#brand .bt{display:flex;flex-direction:column;line-height:1}
#brand b{font-size:19px;font-weight:800;letter-spacing:.16em}
#brand small{font-size:10.5px;font-weight:700;letter-spacing:.42em;color:var(--ac2);margin-top:5px}
#tabs{position:relative;display:flex;gap:10px}
.tb{position:relative;z-index:1;display:flex;align-items:center;gap:10px;height:48px;padding:0 24px 0 20px;border-radius:15px;border:1.5px solid rgba(255,255,255,.12);background:rgba(10,16,40,.5);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:rgba(255,255,255,.82);font-size:16.5px;font-weight:600;cursor:pointer;transition:color .25s,border-color .25s,transform .15s,background .25s}
.tb .ic{width:23px;height:23px}
.tb:hover{color:#fff;border-color:rgba(var(--acr),.7)}
.tb:active{transform:scale(.96)}
.tb.on{color:#fff;border-color:transparent;background:rgba(10,16,40,.15)}
.ind{position:absolute;left:0;top:0;z-index:0;border-radius:15px;pointer-events:none;border:1.5px solid var(--ac2);background:linear-gradient(180deg,rgba(var(--acr),.5),rgba(var(--acr),.16));box-shadow:0 0 24px rgba(var(--acr),.75),inset 0 0 18px rgba(var(--acr),.4);opacity:0;transition:transform .5s var(--ease),width .5s var(--ease),height .5s var(--ease),opacity .3s}
.right{margin-left:auto;display:flex;gap:12px;align-items:center}
#clock{font-size:19px;font-weight:500;margin-right:8px;opacity:.92;font-variant-numeric:tabular-nums}
#q{width:0;opacity:0;padding:0;border:0;height:44px;border-radius:99px;background:rgba(255,255,255,.1);color:#fff;font:inherit;font-size:14.5px;user-select:text;outline:none;transition:width .35s var(--ease),opacity .25s,padding .35s var(--ease)}
#q.on{width:230px;opacity:1;padding:0 18px;border:1.5px solid rgba(var(--acr),.55)}
.ico{width:46px;height:46px;border-radius:50%;border:1.5px solid rgba(255,255,255,.16);background:rgba(10,16,40,.5);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;backdrop-filter:blur(10px);transition:background .2s,transform .2s,border-color .2s}
.ico .ic{width:22px;height:22px}
.ico:hover{background:rgba(var(--acr),.45);border-color:rgba(var(--acr),.8)}
.ico:active{transform:scale(.93)}
#bSet:hover .ic{animation:spinG 1.4s linear infinite}
@keyframes spinG{to{transform:rotate(360deg)}}

/* ---------- side panel ---------- */
#side{position:fixed;left:20px;top:92px;width:214px;z-index:6;padding:12px;border-radius:24px;border:1.5px solid rgba(var(--acr),.38);background:var(--panel);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 14px 34px rgba(0,0,0,.4),0 0 28px rgba(var(--acr),.14)}
#sideItems{position:relative}
#sideList{display:flex;flex-direction:column;gap:8px}
.sn{position:relative;z-index:1;display:flex;align-items:center;gap:13px;height:50px;padding:0 14px;border-radius:14px;border:1.5px solid rgba(255,255,255,.09);background:rgba(255,255,255,.04);color:rgba(255,255,255,.8);font-size:15px;font-weight:600;cursor:pointer;transition:color .25s,border-color .25s,transform .2s}
.sn .ic{width:21px;height:21px}
.sn:hover{color:#fff;border-color:rgba(var(--acr),.7);transform:translateX(3px)}
.sn.on{color:#fff;border-color:transparent;background:rgba(255,255,255,.02)}
.sn.add{margin-top:10px;border-style:dashed;border-color:rgba(var(--acr),.55);background:rgba(var(--acr),.1)}
#sideList.fresh .sn{animation:sideIn .5s var(--ease) backwards;animation-delay:calc(var(--n,0)*45ms)}
@keyframes sideIn{from{opacity:0;transform:translateX(-22px)}}
#side .ind{height:50px}
#bExit{position:fixed;left:24px;bottom:16px;z-index:9;width:48px;height:48px;border-radius:50%;border:1.5px solid rgba(255,84,104,.75);background:rgba(224,51,74,.2);color:#ff5468;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:0 0 18px rgba(224,51,74,.3);transition:background .2s,color .2s,transform .2s,box-shadow .2s}
#bExit .ic{width:24px;height:24px}
#bExit:hover{background:#e0334a;color:#fff;box-shadow:0 0 28px rgba(224,51,74,.75);transform:scale(1.08)}
#bExit:active{transform:scale(.94)}

/* ---------- views ---------- */
#home,#lib,#ach{position:fixed;left:var(--sw);right:0;top:var(--tb);bottom:0;z-index:2}
@keyframes viewIn{from{opacity:0;transform:translateY(10px)}}
#home:not(.hide),#lib:not(.hide),#ach:not(.hide){animation:viewIn .45s var(--ease) backwards}
#top{animation:topIn .5s ease backwards}
@keyframes topIn{from{opacity:0;transform:translateY(-14px)}}

/* strip */
#strip{position:relative;margin:8px 28px 0 8px;border-radius:30px;border:1.5px solid rgba(var(--acr),.45);background:linear-gradient(180deg,rgba(20,32,72,.58),rgba(8,12,34,.58));backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:inset 0 1px 0 rgba(255,255,255,.1),inset 0 0 44px rgba(var(--acr),.1),0 12px 34px rgba(0,0,0,.4),0 0 30px rgba(var(--acr),.18);animation:stripIn .6s var(--ease) .1s backwards}
@keyframes stripIn{from{opacity:0;transform:translateY(-14px) scale(.98)}}
#row{position:relative;display:flex;align-items:center;gap:22px;overflow:hidden;padding:34px 74px 40px;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 64px,#000 calc(100% - 64px),transparent 100%);mask-image:linear-gradient(90deg,transparent 0,#000 64px,#000 calc(100% - 64px),transparent 100%)}
.arr{position:absolute;top:50%;z-index:4;width:44px;height:44px;margin-top:-22px;padding:0;border-radius:50%;background:rgba(10,14,32,.74);border:1.5px solid rgba(255,255,255,.3);backdrop-filter:blur(10px);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 6px 18px rgba(0,0,0,.5);transition:opacity .2s,background .15s,transform .15s,visibility .2s}
#aL{left:12px}#aR{right:12px}
.arr .ic{width:21px;height:21px;stroke-width:2.6}
.arr:hover{background:var(--ac);color:var(--onac);border-color:var(--ac2);box-shadow:0 6px 24px rgba(var(--acr),.65);transform:scale(1.1)}
.arr:active{transform:scale(.93)}
.arr.off{visibility:hidden;opacity:0;pointer-events:none}
#aL:hover .ic{animation:nudgeL .7s ease infinite}#aR:hover .ic{animation:nudgeR .7s ease infinite}
@keyframes nudgeL{50%{transform:translateX(-3px)}}@keyframes nudgeR{50%{transform:translateX(3px)}}

/* the plate: one glowing base that glides from game to game, tiles pop out of it */
.plate{position:absolute;left:0;top:0;z-index:0;pointer-events:none;border-radius:26px;opacity:0;
  background:linear-gradient(180deg,rgba(var(--acr),.08) 0%,rgba(var(--acr),.34) 100%);border:1.5px solid rgba(var(--acr),.9);
  box-shadow:0 0 30px rgba(var(--acr),.55),inset 0 -14px 22px rgba(var(--acr),.28),inset 0 1px 0 rgba(255,255,255,.18);
  transition:transform .46s var(--ease),width .4s var(--ease),height .4s var(--ease),opacity .3s}
.plate::after{content:"";position:absolute;left:18%;right:18%;bottom:-1.5px;height:3px;border-radius:3px;background:var(--ac2);box-shadow:0 0 14px 2px rgba(var(--acr),.95)}
.tile{flex:0 0 auto;position:relative;z-index:1;width:100px;height:100px;border-radius:18px;overflow:hidden;cursor:pointer;opacity:.8;display:flex;align-items:center;justify-content:center;background:#141b30;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.14),0 8px 18px rgba(0,0,0,.4);transition:transform .45s var(--ease),opacity .3s,box-shadow .4s}
.tile::after{content:"";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(155deg,rgba(255,255,255,.2) 0%,rgba(255,255,255,0) 38%,rgba(0,0,0,.2) 100%);pointer-events:none}
.tile:hover{opacity:1;transform:translateY(-3px)}
.tile img{width:100%;height:100%;object-fit:cover;pointer-events:none}
.tile .ph{font-size:40px;font-weight:700;text-shadow:0 2px 10px rgba(0,0,0,.45)}
.tile.sel{z-index:2;opacity:1;transform:translateY(-9px) scale(1.15);box-shadow:0 0 0 2px var(--ac2),0 16px 32px rgba(0,0,0,.6),0 0 22px rgba(var(--acr),.55);animation:glow 2.8s ease-in-out infinite}
@keyframes glow{50%{box-shadow:0 0 0 2px #fff,0 16px 32px rgba(0,0,0,.6),0 0 30px rgba(var(--acr),.95)}}
.tile.add{border:2px dashed rgba(var(--acr),.6);background:rgba(var(--acr),.08);box-shadow:none}
.tile.add .ic{width:34px;height:34px;color:rgba(255,255,255,.85);stroke-width:1.8}
.tile .star{position:absolute;top:6px;right:7px;z-index:2;width:18px;height:18px;color:#ffd75e;filter:drop-shadow(0 1px 3px rgba(0,0,0,.8))}
.tile .star .ic{width:18px;height:18px}
.tile .nm{position:absolute;left:0;right:0;bottom:0;z-index:1;padding:22px 8px 7px;font-size:11px;font-weight:600;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:linear-gradient(transparent,rgba(0,0,0,.85));opacity:0;transform:translateY(8px);transition:opacity .3s,transform .3s}
.tile.sel .nm{opacity:1;transform:none}

/* cross-fading layers (hero text, stats) */
.xf{display:grid}
.xl{grid-area:1/1;align-self:end;opacity:0;pointer-events:none;transition:opacity .4s ease,transform .6s var(--ease)}
.xl.on{opacity:1;pointer-events:auto;transform:none}
#hero{position:absolute;left:44px;bottom:116px;width:560px}
#statsBox{position:absolute;right:36px;bottom:78px}
.logo{display:block;max-width:400px;max-height:150px;margin-bottom:12px;filter:drop-shadow(0 4px 18px rgba(0,0,0,.7))}
#hero h1{font-family:"Cinzel","Trajan Pro",Georgia,"Times New Roman",serif;font-size:54px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;line-height:1.05;margin:0 0 8px;text-shadow:0 2px 14px rgba(0,0,0,.6)}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
.tag{font-size:16px;opacity:.88;margin:8px 0 20px;max-width:440px;line-height:1.45}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}
.chips span{font-size:12.5px;padding:5px 12px;border-radius:99px;background:rgba(255,255,255,.12);backdrop-filter:blur(8px)}
.btns{display:flex;gap:12px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:9px;border:0;border-radius:999px;padding:13px 26px;font-size:16px;font-weight:600;color:#fff;background:rgba(255,255,255,.16);cursor:pointer;backdrop-filter:blur(8px);transition:background .15s,transform .12s}
.btn .ic{width:18px;height:18px}
.btn:hover{background:rgba(255,255,255,.3)}.btn:active{transform:scale(.95)}
.btn.primary{background:linear-gradient(180deg,color-mix(in srgb,var(--ac) 78%,#fff),var(--ac));color:var(--onac);padding:14px 46px;box-shadow:0 6px 22px rgba(var(--acr),.5);animation:btnPulse 3.2s ease-in-out infinite}
.btn.primary:hover{background:linear-gradient(180deg,color-mix(in srgb,var(--ac) 60%,#fff),color-mix(in srgb,var(--ac) 88%,#fff))}
@keyframes btnPulse{50%{box-shadow:0 6px 32px rgba(var(--acr),.9)}}
.btn.round{width:50px;height:50px;padding:0}.btn.round .ic{width:22px;height:22px}
.btn.danger{background:rgba(220,60,60,.4)}.btn.danger:hover{background:rgba(235,70,85,.75)}
.stats{display:flex;align-items:center;gap:22px;padding:14px 26px;border-radius:14px;background:rgba(10,16,40,.62);backdrop-filter:blur(14px);box-shadow:inset 0 0 0 1px rgba(var(--acr),.3)}
.stats div{display:flex;flex-direction:column;gap:2px;font-size:12.5px}.stats b{font-size:16px}.stats i{width:1px;height:34px;background:rgba(255,255,255,.25)}
.stats span{display:flex;align-items:center;gap:7px}.stats span .ic{width:16px;height:16px;opacity:.85}
.stats .st{cursor:pointer}

/* library */
#libhead{display:flex;align-items:center;gap:14px;padding:10px 40px 10px 8px;height:64px}
#libhead h2{margin:0;font-size:27px;font-weight:700}
.cnt{padding:4px 13px;border-radius:99px;background:rgba(255,255,255,.1);font-size:13px}
#sortSel{margin-left:auto;background:rgba(10,16,40,.6);color:#fff;border:1.5px solid rgba(var(--acr),.4);border-radius:99px;padding:9px 16px;font:inherit;font-size:14px;outline:none}
#sortSel option{color:#000}
#grid{position:absolute;left:0;right:0;top:64px;bottom:64px;overflow-y:auto;overflow-x:hidden;display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:30px 24px;padding:26px 40px 30px 22px;align-content:start;scrollbar-width:none}
#grid::-webkit-scrollbar,#ach::-webkit-scrollbar,#drawer::-webkit-scrollbar,.card::-webkit-scrollbar,.recent::-webkit-scrollbar{display:none;width:0;height:0}
.cell{position:relative;z-index:1;display:flex;flex-direction:column;gap:12px;min-width:0;cursor:pointer}
.cell .tile{width:100%;height:auto;aspect-ratio:1/1}
.cell .tile.sel{transform:translateY(-6px) scale(1.07)}
.cell .tile .nm{display:none}
.cap{text-align:center;min-width:0;padding:0 4px}
.cap b{display:block;font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cap small{display:block;opacity:.6;font-size:12px;margin-top:3px}
.empty{grid-column:1/-1;display:flex;flex-direction:column;align-items:center;gap:14px;padding:70px 20px;opacity:.85;text-align:center}
.empty .ic{width:54px;height:54px;color:var(--ac2);opacity:.8}
.empty p{margin:0;max-width:420px;line-height:1.55;opacity:.8}

/* footer hints */
#foot{position:fixed;left:92px;right:0;bottom:0;height:80px;z-index:4;display:flex;align-items:center;gap:26px;padding:0 40px 0 8px;font-size:13.5px;opacity:.9;pointer-events:none}
#foot span{display:flex;gap:8px;align-items:center}
.gl{display:inline-flex;width:20px;height:20px;border-radius:50%;align-items:center;justify-content:center;background:var(--ac);color:var(--onac)}
.gl.r{background:#e0334a;color:#fff}.gl.d{background:none;color:#fff}
.gl .ic{width:11px;height:11px;stroke-width:2.6}.gl.d .ic{width:15px;height:15px}
#count{margin-left:auto}

/* ---------- achievements page ---------- */
#ach{overflow-y:auto;overflow-x:hidden;padding:8px 40px 96px 8px;scrollbar-width:none}
.ahead{display:flex;gap:22px;align-items:center}
.emblem{width:216px;flex:0 0 auto;display:flex;flex-direction:column;align-items:center}
.emblem svg{width:196px;height:196px;overflow:visible;filter:drop-shadow(0 0 26px rgba(var(--acr),.55))}
.elabel{margin-top:-18px;position:relative;padding:11px 36px;border-radius:15px;border:1.5px solid rgba(var(--acr),.5);background:var(--panel);backdrop-filter:blur(12px);font-size:21px;font-weight:700;letter-spacing:.01em;box-shadow:0 10px 24px rgba(0,0,0,.4)}
.astats{flex:1;min-width:0;display:flex;flex-direction:column;gap:18px;padding:22px 28px 20px;border-radius:22px;border:1.5px solid rgba(var(--acr),.38);background:var(--panel);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 14px 34px rgba(0,0,0,.35)}
.acols{display:grid;grid-template-columns:repeat(4,1fr)}
.acol{display:flex;flex-direction:column;align-items:center;gap:4px;padding:0 10px;text-align:center}
.acol+.acol{border-left:1px solid rgba(255,255,255,.18)}
.acol .tro{width:38px;height:38px;filter:drop-shadow(0 3px 8px rgba(0,0,0,.5))}
.acol b{font-size:30px;font-weight:700;line-height:1.1;font-variant-numeric:tabular-nums}
.acol span{font-size:13.5px;opacity:.78}
.abar{display:flex;align-items:center;gap:16px}
.abar b{font-size:20px;min-width:52px;text-align:right}
.bar,.pbar{flex:1;height:9px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}
.bar i,.pbar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--ac),var(--ac2));box-shadow:0 0 12px rgba(var(--acr),.8);transition:width .9s var(--ease)}
.pbar{height:5px;margin:8px 0 4px}
.sec2{display:flex;align-items:center;gap:12px;margin:28px 0 14px;font-size:21px;font-weight:700}
.sec2 .ic{width:23px;height:23px;color:var(--ac2)}
.sec2 a{margin-left:auto;font-size:14.5px;color:var(--ac2);cursor:pointer;font-weight:600;display:flex;gap:6px;align-items:center}
.sec2 a .ic{width:16px;height:16px;color:inherit;stroke-width:2.6}
.sec2 a:hover{color:#fff}
.recent{display:flex;gap:16px;overflow-x:auto;padding:8px 6px 18px;margin:0 -6px;scrollbar-width:none}
.rc{flex:0 0 206px;border-radius:18px;overflow:hidden;border:1.5px solid rgba(255,255,255,.13);background:rgba(10,16,40,.72);cursor:pointer;transition:transform .35s var(--ease),border-color .3s,box-shadow .3s}
.rc:first-child{border-color:var(--ac2);box-shadow:0 0 26px rgba(var(--acr),.55)}
.rc:hover{transform:translateY(-5px);border-color:rgba(var(--acr),.9)}
.rc .art{position:relative;height:112px;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center}
.rc .art::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(5,8,22,.15),rgba(5,8,22,.9))}
.rc .art .tbadge{position:relative;z-index:1;width:58px;height:58px}
.rc .art .tbadge .ic{width:29px;height:29px}
.rc .bd{padding:6px 14px 13px;text-align:center}
.rc .bd b{display:block;font-size:15.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rc .bd small{display:block;font-size:12.5px;opacity:.7;margin:3px 0 10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rcf{display:flex;justify-content:space-between;align-items:center;font-size:12.5px;opacity:.9}
.rcf span{display:flex;gap:6px;align-items:center}.rcf .tro{width:17px;height:17px}
.gr{display:grid;grid-template-columns:136px minmax(130px,1.1fr) minmax(130px,1fr) auto;align-items:center;gap:22px;padding:12px 24px 12px 12px;margin-bottom:12px;border-radius:18px;border:1.5px solid rgba(var(--acr),.3);background:var(--panel2);backdrop-filter:blur(12px);cursor:pointer;transition:transform .3s var(--ease),border-color .25s,box-shadow .25s}
.gr:hover{transform:translateX(4px);border-color:rgba(var(--acr),.85);box-shadow:0 0 24px rgba(var(--acr),.3)}
.gr .th{height:76px;border-radius:12px;background-size:cover;background-position:center;background-color:#141b30;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12);overflow:hidden}
.gr .th svg{width:46px;height:46px}
.gr h3{margin:0;font-size:21px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gr .sub{display:flex;gap:8px;align-items:center;margin-top:8px;font-size:14px;opacity:.82}
.gr .sub .tro{width:19px;height:19px}
.gr .pg{display:flex;align-items:center;gap:14px}
.gr .pg b{font-size:18px;min-width:46px;text-align:right}
.gr .tc{display:flex;gap:20px}
.gr .tc span{display:flex;flex-direction:column;align-items:center;gap:3px;font-size:16px;font-weight:700;min-width:30px}
.gr .tc .tro{width:26px;height:26px}
.scards{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:14px}
.sc{display:flex;align-items:center;gap:16px;padding:18px 20px;border-radius:18px;border:1.5px solid rgba(var(--acr),.3);background:var(--panel2);backdrop-filter:blur(12px)}
.sc .ib{width:50px;height:50px;border-radius:14px;flex:0 0 auto;display:flex;align-items:center;justify-content:center;background:rgba(var(--acr),.22);border:1px solid rgba(var(--acr),.5);color:var(--ac2)}
.sc .ib .ic{width:26px;height:26px}
.sc b{display:block;font-size:24px;font-weight:700;line-height:1.1}
.sc small{opacity:.7;font-size:13px}
.hb{display:grid;grid-template-columns:170px 1fr 80px;align-items:center;gap:16px;padding:8px 4px;font-size:14.5px}
.hb span:first-child{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600}
.hb span:last-child{text-align:right;opacity:.8;font-variant-numeric:tabular-nums}
.apanel{max-width:760px;padding:8px 28px 24px;border-radius:22px;border:1.5px solid rgba(var(--acr),.38);background:var(--panel);backdrop-filter:blur(16px)}
.apanel h2{margin:20px 0 4px;font-size:24px}
.apanel .help{margin-bottom:6px}
.pg-title{display:flex;align-items:center;gap:14px;margin:6px 0 18px;font-size:27px;font-weight:700}
.pg-title .ic{width:30px;height:30px;color:var(--ac2)}

/* trophy badges (drawer + pop-up) */
.tro{width:24px;height:24px;display:block;flex:0 0 auto}
.tro.lk{filter:grayscale(1) brightness(.7);opacity:.55}
.tbadge{width:50px;height:50px;border-radius:50%;flex:0 0 auto;display:flex;align-items:center;justify-content:center;box-shadow:inset 0 0 0 2px rgba(255,255,255,.35),inset 0 -6px 10px rgba(0,0,0,.25),0 4px 12px rgba(0,0,0,.4)}
.tbadge .ic{width:25px;height:25px;stroke:rgba(24,16,4,.88);stroke-width:2}
.tbadge.t-bronze{background:radial-gradient(circle at 32% 26%,#f6c08a,#cd7f32 58%,#8a5320)}
.tbadge.t-silver{background:radial-gradient(circle at 32% 26%,#fff,#c8d0dc 58%,#8993a3)}
.tbadge.t-gold{background:radial-gradient(circle at 32% 26%,#fff3bd,#f2c14e 58%,#b88418)}
.tbadge.t-plat{background:radial-gradient(circle at 32% 26%,#fff,#8fe3ff 52%,#3f9fd0)}
.tbadge.t-plat .ic{stroke:#05324a}
.tbadge.lk{filter:grayscale(1) brightness(.75);opacity:.5}
.tr{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}
.t-bronze.tr{background:#cd7f32}.t-silver.tr{background:#c8d0dc}.t-gold.tr{background:#f2c14e}.t-plat.tr{background:linear-gradient(135deg,#8fe3ff,#f2fbff)}

/* pop-up, drawer, modal, toast */
#pop{position:fixed;top:-90px;left:50%;transform:translateX(-50%);z-index:70;display:flex;gap:14px;align-items:center;background:rgba(14,18,32,.97);border:1px solid rgba(255,255,255,.2);padding:12px 26px 12px 14px;border-radius:99px;transition:top .45s cubic-bezier(.2,.9,.3,1);white-space:nowrap;box-shadow:0 10px 40px rgba(0,0,0,.6),0 0 30px rgba(var(--acr),.4)}
#pop.show{top:22px}
#pop .tbadge{width:44px;height:44px}#pop .tbadge .ic{width:22px;height:22px}
#pop small{display:block;opacity:.65;font-size:12px}
#drawer{position:fixed;top:0;right:0;bottom:0;width:470px;max-width:100vw;z-index:20;transform:translateX(105%);transition:transform .38s var(--ease);padding:22px 20px 26px;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:none;border-radius:26px 0 0 26px;border-left:1.5px solid rgba(var(--acr),.4);box-shadow:-20px 0 60px rgba(0,0,0,.5);background:linear-gradient(180deg,rgba(14,20,44,.97),rgba(7,10,26,.97))}
#drawer.open{transform:none}
#drawer h2{margin:0 0 4px;font-size:24px}
.dx{position:absolute;top:14px;right:14px;width:34px;height:34px;padding:0;border-radius:50%;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.08);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2;transition:background .15s,transform .15s}
.dx .ic{width:16px;height:16px}.dx:hover{background:rgba(var(--acr),.55);transform:rotate(90deg)}
.note{opacity:.7;font-size:13px;line-height:1.5;margin:10px 0 16px}
.achhead{display:flex;align-items:center;gap:18px;margin:2px 0 6px;padding:16px 58px 16px 16px;border-radius:20px;border:1px solid rgba(var(--acr),.45);background:linear-gradient(135deg,rgba(var(--acr),.3),rgba(255,255,255,.04));box-shadow:0 10px 30px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.1)}
.achhead h2{margin:0;font-size:22px}
.achhead .tiers{display:flex;gap:14px;font-size:14px;margin-top:2px}.achhead .tiers span{display:flex;align-items:center;font-weight:600}
.ring{position:relative;width:84px;height:84px;flex:0 0 auto}
.ring svg{width:84px;height:84px;transform:rotate(-90deg)}
.ring circle{fill:none;stroke-width:7}.ring .rb{stroke:rgba(255,255,255,.12)}
.ring .rf{stroke:var(--ac);stroke-linecap:round;filter:drop-shadow(0 0 6px rgba(var(--acr),.8))}
.ring b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:21px}
.ring b small{font-size:12px;opacity:.6;margin-left:1px}
.grow{flex:1;min-width:0}
.sec{display:flex;align-items:center;gap:12px;margin:22px 0 10px;opacity:.8;font-size:12px;letter-spacing:.12em;text-transform:uppercase}
.sec::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,rgba(255,255,255,.22),transparent)}
.ach{display:flex;gap:14px;align-items:center;border:1px solid rgba(255,255,255,.07);border-radius:18px;padding:12px 14px;margin-bottom:10px;background:rgba(255,255,255,.045);animation:rowIn .4s var(--ease) backwards;transition:transform .18s,border-color .18s}
@keyframes rowIn{from{opacity:0;transform:translateX(18px)}}
.ach:not(.locked){background:linear-gradient(90deg,rgba(var(--acr),.15),rgba(255,255,255,.04));border-color:rgba(var(--acr),.3);box-shadow:0 0 18px rgba(var(--acr),.14)}
.ach:hover{transform:translateX(-3px);border-color:rgba(var(--acr),.6)}
.ach.manual{cursor:pointer}
.ach b{display:block;font-size:15px}
.ach small{opacity:.65;font-size:12.5px;line-height:1.35;display:block}
.ach .tick.ok{width:26px;height:26px;border-radius:50%;background:#2fbf71;display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.ach .tick.ok .ic{width:15px;height:15px;stroke:#fff;stroke-width:3}
.tier-tag{margin-left:auto;flex:0 0 auto;font-size:11px;letter-spacing:.08em;text-transform:uppercase;padding:3px 10px;border-radius:99px;border:1px solid rgba(255,255,255,.2);opacity:.75}
.aic{position:relative;width:52px;height:52px;border-radius:10px;flex:0 0 auto;background:#222a3d;display:flex;align-items:center;justify-content:center;overflow:hidden}
.aic .ic{width:26px;height:26px;opacity:.55}
.aic img{position:absolute;inset:0;width:100%;height:100%}
.ach.locked .aic img{filter:grayscale(1);opacity:.55}
#modal{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:30;display:none;align-items:center;justify-content:center;padding:16px}
#modal.open{display:flex;animation:fadeIn .2s}
@keyframes fadeIn{from{opacity:0}}
.card{background:#10162a;border:1.5px solid rgba(var(--acr),.3);border-radius:22px;padding:26px;width:560px;max-width:100%;max-height:92vh;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:none;box-shadow:0 20px 60px rgba(0,0,0,.6);animation:cardIn .3s var(--ease)}
@keyframes cardIn{from{opacity:0;transform:translateY(14px) scale(.96)}}
.card h2{margin:0 0 14px}
.card label{display:block;font-size:13px;opacity:.7;margin:14px 0 6px}
.card input:not([type=checkbox]):not([type=range]),.apanel input:not([type=checkbox]):not([type=range]){width:100%;padding:12px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.07);color:#fff;font-size:15px;font-family:inherit;user-select:text;outline:none}
.line{display:flex;gap:10px;align-items:center;margin-top:8px}
.line.wrap{flex-wrap:wrap;margin-top:14px}.line.end{margin-top:22px}
.res{margin-top:8px;font-size:14px}
.res .opt{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:10px;cursor:pointer;background:rgba(255,255,255,.06);margin-top:5px}
.res .opt:hover{background:rgba(255,255,255,.18)}.res .opt .ic{width:18px;height:18px;opacity:.9}
.help{font-size:12.5px;opacity:.65;line-height:1.5;margin-top:8px}
.card label.row2,.apanel label.row2{display:flex;justify-content:space-between;align-items:center;gap:16px;padding:12px 0;margin:0;opacity:1;font-size:14.5px;border-bottom:1px solid rgba(255,255,255,.07)}
.row2 input[type=checkbox]{width:20px;height:20px;padding:0;accent-color:var(--ac);flex:0 0 auto}
.row2 input[type=range]{width:170px;padding:0;accent-color:var(--ac)}
.swatches{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:6px}
.sw{border:1.5px solid rgba(255,255,255,.15);border-radius:14px;background:rgba(255,255,255,.06);color:#fff;font:inherit;font-size:13px;padding:10px;display:flex;align-items:center;gap:10px;cursor:pointer;transition:.15s}
.sw i{width:22px;height:22px;border-radius:50%;background:var(--c);box-shadow:0 0 12px var(--c)}
.sw.on{border-color:var(--c);background:rgba(255,255,255,.14)}.sw:hover{transform:translateY(-2px)}
#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(30px);background:#fff;color:#0a0d16;padding:12px 20px;border-radius:99px;font-weight:600;font-size:14px;opacity:0;transition:.25s;z-index:60;max-width:90vw;text-align:center;pointer-events:none}
#toast.show{opacity:1;transform:translateX(-50%)}
#busy{position:fixed;inset:0;background:rgba(4,6,12,.82);z-index:50;display:none;align-items:center;justify-content:center;flex-direction:column;gap:18px;font-size:22px;font-weight:600}
#busy.open{display:flex}
.spin{width:44px;height:44px;border-radius:50%;border:4px solid rgba(255,255,255,.2);border-top-color:var(--ac2);animation:sp 1s linear infinite}
@keyframes sp{to{transform:rotate(360deg)}}
html[data-anim=off] *:not(.spin){animation:none!important;transition:none!important}

@media(max-width:1100px){#brand b{font-size:16px}.tb{padding:0 16px 0 14px;font-size:15px}.gr{grid-template-columns:110px 1fr auto}.gr .pg{display:none}}
@media(max-width:820px){:root{--sw:92px}#side{left:10px;width:68px;padding:8px}.sn{font-size:0;padding:0;justify-content:center}#brand .bt,.tb span,#clock{display:none}#brand{width:auto}.ahead{flex-direction:column}#foot span:not(#count){display:none}.stats{display:none}}
@media(max-height:640px){#hero{bottom:96px}#hero h1{font-size:42px}.logo{max-height:110px}}

/* ---------- polish v2 ---------- */
#tabs{gap:2px;padding:5px;border-radius:19px;border:1px solid rgba(255,255,255,.12);background:rgba(8,12,32,.55);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 6px 22px rgba(0,0,0,.28)}
.tb{height:42px;padding:0 20px 0 16px;border:0;border-radius:14px;background:transparent;backdrop-filter:none;-webkit-backdrop-filter:none;color:rgba(255,255,255,.72);font-size:15.5px}
.tb:hover{background:rgba(255,255,255,.08);color:#fff}
.tb.on,.tb.on:hover{background:transparent;color:var(--onac)}
#tabs .ind{border:0;border-radius:14px;background:linear-gradient(180deg,rgba(var(--acr),1),rgba(var(--acr),.74));box-shadow:0 4px 16px rgba(var(--acr),.5),inset 0 1px 0 rgba(255,255,255,.28)}
#row{padding:36px 74px;gap:24px}
.plate{border-radius:24px;background:linear-gradient(180deg,rgba(var(--acr),.1),rgba(var(--acr),.3));border:1.5px solid rgba(var(--acr),.75);box-shadow:0 0 22px rgba(var(--acr),.45),inset 0 -10px 18px rgba(var(--acr),.22),inset 0 1px 0 rgba(255,255,255,.16)}
.plate::after{left:24%;right:24%;height:2.5px}
.tile{border-radius:20px}
.tile .nm{display:none!important}
.tile:hover{transform:translateY(-3px) scale(1.03)}
.tile.sel,.tile.sel:hover{transform:scale(1.12);animation:none;box-shadow:0 0 0 2px var(--ac2),0 14px 28px rgba(0,0,0,.55),0 0 18px rgba(var(--acr),.5)}
.cell .tile:hover{transform:scale(1.03)}
.cell .tile.sel,.cell .tile.sel:hover{transform:scale(1.05)}
.cap b{transition:color .25s}
.cell:hover .cap b,.cell:has(.tile.sel) .cap b{color:var(--ac2)}

/* ---------- strip v3 (Home shelf) ---------- */
#strip{border-radius:28px;border:1px solid rgba(var(--acr),.38);background:linear-gradient(180deg,rgba(24,38,84,.55),rgba(8,12,34,.62));box-shadow:inset 0 1px 0 rgba(255,255,255,.12),inset 0 0 36px rgba(var(--acr),.08),0 10px 28px rgba(0,0,0,.38),0 0 24px rgba(var(--acr),.14)}
#row{padding:32px 70px;gap:22px}
#row .tile{width:90px;height:90px;border-radius:19px;opacity:1;filter:saturate(.78) brightness(.8);transition:transform .45s var(--ease),filter .35s,opacity .3s,box-shadow .4s}
#row .tile:hover{filter:saturate(1) brightness(1)}
#row .tile.sel,#row .tile.sel:hover{filter:none}
#row .tile.add,#row .tile.add:hover{filter:none;opacity:.8}
#row .tile.add:hover{opacity:1}

/* ---------- full-screen wallpaper (Home) ---------- */
.shade{background:linear-gradient(90deg,rgba(3,6,20,.5) 0%,rgba(3,6,20,.12) 40%,rgba(3,6,20,0) 65%),linear-gradient(180deg,rgba(3,6,20,.5) 0%,rgba(3,6,20,0) 22%,rgba(3,6,20,0) 58%,rgba(3,6,20,.72) 100%)}
.bg div{background-position:center center}

/* ---------- game page inside the Library ---------- */
body.libv.gdv .bg{opacity:1}
body.libv.gdv .shade{opacity:1;background:linear-gradient(90deg,rgba(3,6,20,.8) 0%,rgba(3,6,20,.5) 45%,rgba(3,6,20,.15) 100%),linear-gradient(180deg,rgba(3,6,20,.55) 0%,rgba(3,6,20,0) 25%,rgba(3,6,20,.2) 60%,rgba(3,6,20,.85) 100%)}
body.gdv #libhead,body.gdv #grid{visibility:hidden}
#gd{position:absolute;inset:0;z-index:3;padding:6px 40px 96px 8px;display:flex;flex-direction:column}
@keyframes gdIn{from{opacity:0;transform:translateY(14px)}}
.gtop{display:flex;align-items:center;gap:12px;height:54px;flex:0 0 auto}
.gtop .grow{flex:1}
.gback{display:inline-flex;align-items:center;gap:8px;height:42px;padding:0 18px 0 12px;border-radius:99px;border:1px solid rgba(255,255,255,.16);background:rgba(10,16,40,.55);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:#fff;font:inherit;font-size:14.5px;font-weight:600;cursor:pointer;transition:background .2s,transform .15s}
.gback .ic{width:18px;height:18px}.gback:hover{background:rgba(var(--acr),.45)}.gback:active{transform:scale(.96)}
.gtop .btn.round{width:42px;height:42px}.gtop .btn.round .ic{width:18px;height:18px}
.gcount{font-size:13.5px;opacity:.8;min-width:52px;text-align:center;font-variant-numeric:tabular-nums}
.gdm{flex:1;min-height:0;display:flex;align-items:center;gap:44px;animation:gdIn .5s var(--ease) backwards}
.gcover{position:relative;flex:0 0 auto;height:min(58vh,440px);aspect-ratio:2/3;border-radius:22px;overflow:hidden;background:#141b30;box-shadow:0 0 0 2px rgba(255,255,255,.18),0 24px 60px rgba(0,0,0,.6),0 0 40px rgba(var(--acr),.35)}
.gcover img{width:100%;height:100%;object-fit:cover;display:block}
.gcover .ph{display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-size:90px;font-weight:700}
.gcover .star{position:absolute;top:10px;right:12px;color:#ffd75e;filter:drop-shadow(0 1px 4px rgba(0,0,0,.8))}.gcover .star .ic{width:24px;height:24px}
.gdi{min-width:0;flex:1;max-width:680px}
.gdi h1{font-family:"Cinzel","Trajan Pro",Georgia,"Times New Roman",serif;font-size:clamp(30px,4.2vw,52px);font-weight:700;letter-spacing:.04em;text-transform:uppercase;line-height:1.05;margin:0 0 14px;text-shadow:0 2px 14px rgba(0,0,0,.6)}
.gdesc{font-size:15.5px;line-height:1.55;opacity:.9;margin:0 0 22px;max-width:620px;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}
.gdi .chips{margin-bottom:16px}
.gstats{display:flex;flex-wrap:wrap;gap:12px;margin-top:26px}
.gs{min-width:118px;padding:12px 20px;border-radius:16px;background:rgba(10,16,40,.62);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:inset 0 0 0 1px rgba(var(--acr),.3);display:flex;flex-direction:column;gap:4px;font-size:12.5px}
.gs span{display:flex;align-items:center;gap:7px;opacity:.8}.gs span .ic{width:15px;height:15px}.gs b{font-size:19px;font-weight:700}
.gs.click{cursor:pointer;transition:transform .15s,box-shadow .2s}.gs.click:hover{transform:translateY(-2px);box-shadow:inset 0 0 0 1px rgba(var(--acr),.8)}
.btn.round.on{background:rgba(255,107,129,.28)}.btn.round.on .ic{color:#ff8da0;fill:currentColor}
@media(max-width:900px){.gdm{flex-direction:column;align-items:flex-start;gap:20px;overflow-y:auto}.gcover{height:220px}}
</style><link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%23283a8c'/%3E%3Cstop offset='1' stop-color='%23060a1e'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='32' height='32' rx='7' fill='url(%23g)'/%3E%3Crect x='5' y='11' width='22' height='9.5' rx='4.7' fill='white'/%3E%3Ccircle cx='9.5' cy='18.5' r='4' fill='white'/%3E%3Ccircle cx='22.5' cy='18.5' r='4' fill='white'/%3E%3Cpath d='M9 13.2h4M11 11.2v4' stroke='%232664f0' stroke-width='1.6' stroke-linecap='round'/%3E%3Ccircle cx='21.5' cy='13.2' r='1.3' fill='%232664f0'/%3E%3Ccircle cx='23.8' cy='15.2' r='1.3' fill='%232664f0'/%3E%3C/svg%3E"></head><body>
<div id="aurora"><i></i><i></i></div><div class="bg"><div></div><div></div></div><div class="shade"></div><canvas id="fx"></canvas>
<header id="top">
  <div id="brand"><span id="logoMark"></span><span class="bt"><b>GAME</b><small>LAUNCHER</small></span></div>
  <nav id="tabs"><i class="ind" id="tabInd"></i>
    <button class="tb" data-v="home"><i class="i" data-ic="home"></i><span>Home</span></button>
    <button class="tb" data-v="lib"><i class="i" data-ic="lib"></i><span>Library</span></button>
    <button class="tb" data-v="fav"><i class="i" data-ic="heart"></i><span>Favorites</span></button>
    <button class="tb" data-v="ach"><i class="i" data-ic="trophy"></i><span>Achievements</span></button>
  </nav>
  <div class="right"><span id="clock"></span><input id="q" placeholder="Search games"><button class="ico" id="bSearch" title="Search ( / )"><i class="i" data-ic="search"></i></button><button class="ico" id="bSet" title="Settings"><i class="i" data-ic="gear"></i></button></div>
</header>
<aside id="side"><div id="sideItems"><i class="ind" id="sideInd"></i><div id="sideList"></div></div></aside>
<button id="bExit" title="Exit"><i class="i" data-ic="power"></i></button>
<div id="home"><div id="strip"><button class="arr off" id="aL" title="Previous"><i class="i" data-ic="chevL"></i></button><div id="row"></div><button class="arr off" id="aR" title="Next"><i class="i" data-ic="chevR"></i></button></div><div id="hero" class="xf"></div><div id="statsBox" class="xf"></div></div>
<div id="lib" class="hide"><div id="libhead"></div><div id="grid"></div><div id="gd" class="hide"></div></div>
<div id="ach" class="hide"></div>
<div id="foot"><span><i class="gl d"><i class="i" data-ic="dpad"></i></i>Navigate</span><span><i class="gl"><i class="i" data-ic="cross"></i></i>Select</span><span><i class="gl r"><i class="i" data-ic="circ"></i></i>Back</span><span id="count"></span></div>
<div id="drawer"></div><div id="modal"></div>
<div id="busy"><div class="spin"></div><div id="busyMsg"></div></div><div id="toast"></div><div id="pop"></div>
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs id="gdefs"></defs></svg>
<script>
const $=s=>document.querySelector(s);
const $$=s=>Array.from(document.querySelectorAll(s));
const APP_NAME='Game Launcher';
let games=[], settings={}, view='home', q='', selId=null, rev=0, sig='';
let homeF='all', libTab='all', favTab='all', sort='name', achSub='overview', achData=null;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const TOKEN="__TOKEN__";

/* ---------- icons (solid shapes) ---------- */
const F='fill="currentColor" stroke="none"';
const gearD=(function(){ const n=8,ro=10,ri=7.7; let d='';
  for(let i=0;i<n;i++){ const a=i*Math.PI*2/n;
    [[-.27,ri],[-.15,ro],[.15,ro],[.27,ri]].forEach((p,k)=>{ const x=12+p[1]*Math.cos(a+p[0]), y=12+p[1]*Math.sin(a+p[0]); d+=(i||k?'L':'M')+x.toFixed(2)+' '+y.toFixed(2); }); }
  return d+'ZM15.5 12a3.5 3.5 0 1 0-7 0 3.5 3.5 0 0 0 7 0Z'; })();
const IC={
home:'<path '+F+' d="M12 3 2.5 11.2a.9.9 0 0 0 .6 1.6H5v7.4A1.2 1.2 0 0 0 6.2 21.4h3.4V16a1 1 0 0 1 1-1h2.8a1 1 0 0 1 1 1v5.4h3.4a1.2 1.2 0 0 0 1.2-1.2v-7.4h1.9a.9.9 0 0 0 .6-1.6z"/>',
lib:'<rect '+F+' x="3.2" y="3.2" width="7.6" height="7.6" rx="2.2"/><rect '+F+' x="13.2" y="3.2" width="7.6" height="7.6" rx="2.2"/><rect '+F+' x="3.2" y="13.2" width="7.6" height="7.6" rx="2.2"/><rect '+F+' x="13.2" y="13.2" width="7.6" height="7.6" rx="2.2"/>',
heart:'<path '+F+' d="M12 21c-.3 0-8.5-5.1-8.5-11.4C3.5 6.5 5.7 4.3 8.4 4.3c1.5 0 2.9.7 3.6 1.9.7-1.2 2.1-1.9 3.6-1.9 2.7 0 4.9 2.2 4.9 5.3C20.5 15.9 12.3 21 12 21z"/>',
star:'<path '+F+' d="M12 2.8l2.8 5.9 6.4.9-4.7 4.5 1.2 6.4L12 17.4l-5.7 3.1 1.2-6.4-4.7-4.5 6.4-.9z"/>',
trophy:'<path '+F+' d="M7 3h10v6.4a5 5 0 0 1-10 0z"/><path fill="none" stroke="currentColor" stroke-width="1.9" d="M7 5H4.1v1.8a3.7 3.7 0 0 0 3.7 3.7M17 5h2.9v1.8a3.7 3.7 0 0 1-3.7 3.7"/><path '+F+' d="M10.6 14.2h2.8v3.2h-2.8z"/><path '+F+' d="M8 17.8h8l.9 3.2H7.1z"/>',
gear:'<path '+F+' fill-rule="evenodd" d="'+gearD+'"/>',
power:'<path d="M12 3.2v8.2" stroke-width="2.5"/><path d="M6.6 6.9a8 8 0 1 0 10.8 0" stroke-width="2.5"/>',
search:'<circle cx="10.6" cy="10.6" r="6.4" stroke-width="2.5"/><path d="M15.4 15.4l5.2 5.2" stroke-width="2.7"/>',
plus:'<path d="M12 5v14M5 12h14" stroke-width="2.5"/>',
gamepad:'<path '+F+' fill-rule="evenodd" d="M7.3 7.2h9.4a5.2 5.2 0 0 1 5.1 4.5l.5 4.4a2.7 2.7 0 0 1-4.7 2.1l-1.7-2.2a1.8 1.8 0 0 0-1.4-.7H9.6a1.8 1.8 0 0 0-1.4.7l-1.7 2.2a2.7 2.7 0 0 1-4.7-2.1l.5-4.4a5.2 5.2 0 0 1 5-4.5zM6.9 9.6v1.3H5.6v1.3h1.3v1.3h1.3v-1.3h1.3v-1.3H8.2V9.6zM15.7 10.1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM18.3 12.4a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>',
stats:'<rect '+F+' x="3.6" y="11.5" width="4.6" height="9" rx="1.3"/><rect '+F+' x="9.7" y="3.5" width="4.6" height="17" rx="1.3"/><rect '+F+' x="15.8" y="8" width="4.6" height="12.5" rx="1.3"/>',
clock:'<circle cx="12" cy="12" r="8.6" stroke-width="2"/><path d="M12 7v5.3l3.5 2" stroke-width="2.1"/>',
spk:'<path '+F+' d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11" stroke-width="2"/>',
spkx:'<path '+F+' d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5" stroke-width="2"/>',
chevL:'<path d="M14.5 5l-7 7 7 7"/>',
chevR:'<path d="M9.5 5l7 7-7 7"/>',
arrowR:'<path d="M5 12h14M13 6l6 6-6 6"/>',
play:'<path '+F+' d="M8.2 5.3a1 1 0 0 0-1.5.9v11.6a1 1 0 0 0 1.5.9l9.6-5.8a1 1 0 0 0 0-1.7z"/>',
dots:'<circle '+F+' cx="5.5" cy="12" r="1.9"/><circle '+F+' cx="12" cy="12" r="1.9"/><circle '+F+' cx="18.5" cy="12" r="1.9"/>',
image:'<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="M4.5 18l5-5 4 4 2.8-2.8L20 17"/>',
link:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/>',
moon:'<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
stack:'<path d="M12 3.5 3.5 8 12 12.5 20.5 8z"/><path d="M3.5 12 12 16.5 20.5 12"/><path d="M3.5 16 12 20.5 20.5 16"/>',
check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
installed:'<circle cx="12" cy="12" r="8.6" stroke-width="2"/><path d="M8.3 12.4l2.7 2.7 4.8-5.2" stroke-width="2.3"/>',
pencil:'<path d="M4 20l1.2-4.2L16.6 4.4a2.1 2.1 0 0 1 3 3L8.2 18.8z"/><path d="M14.5 6.5l3 3"/>',
dpad:'<path '+F+' d="M9.2 3.5h5.6v5.7h5.7v5.6h-5.7v5.7H9.2v-5.7H3.5V9.2h5.7z"/>',
cross:'<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
circ:'<circle cx="12" cy="12" r="6"/>',
sliders:'<path d="M4 7h8M16 7h4M4 17h3M11 17h9"/><circle cx="14" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
lock:'<rect x="5" y="11" width="14" height="9.5" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'
};
const svg=n=>'<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'+(IC[n]||'')+'</svg>';

/* coloured trophy cups (bronze / silver / gold / platinum) */
const TCOL={bronze:['#f6c08a','#cd7f32','#8a5320'],silver:['#ffffff','#c8d0dc','#7d889a'],gold:['#fff3bd','#f2c14e','#b07d10'],plat:['#f4fdff','#8fe3ff','#3a98cc']};
$('#gdefs').innerHTML=Object.keys(TCOL).map(t=>'<linearGradient id="tg-'+t+'" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="'+TCOL[t][0]+'"/><stop offset=".55" stop-color="'+TCOL[t][1]+'"/><stop offset="1" stop-color="'+TCOL[t][2]+'"/></linearGradient>').join('');
const trophy=(t,c)=>{ const u='url(#tg-'+t+')'; return '<svg class="tro '+(c||'')+'" viewBox="0 0 24 24"><path d="M7 2.8h10v6.5a5 5 0 0 1-10 0z" fill="'+u+'"/><path d="M7 4.8H4v1.8a3.6 3.6 0 0 0 3.6 3.6M17 4.8h3v1.8a3.6 3.6 0 0 1-3.6 3.6" fill="none" stroke="'+u+'" stroke-width="1.8" stroke-linecap="round"/><path d="M10.4 14h3.2v3.2h-3.2z" fill="'+u+'"/><path d="M7.8 17.6h8.4l.9 3.6H6.9z" fill="'+u+'"/><path d="M8.9 4.3h2.3v5.4c0 1 .4 1.6 1.1 2.1-2.1.1-3.4-1.3-3.4-3.3z" fill="#fff" fill-opacity=".4"/>'+(t==='plat'?'<circle cx="12" cy="7" r="1.5" fill="#fff"/>':'')+'</svg>'; };
const TIER={bronze:'Bronze',silver:'Silver',gold:'Gold',plat:'Platinum'};
const XP={bronze:10,silver:20,gold:30,plat:100};
const badge=(icon,tier,locked)=>'<div class="tbadge t-'+tier+(locked?' lk':'')+'">'+svg(icon==='trophy'||!IC[icon]?'trophy':icon)+'</div>';

/* the big laurel + trophy of the Achievements page */
function emblem(){
  let leaves='';
  const cx=100, cy=112, R=76, conv=Math.PI/180;
  [-1,1].forEach(side=>{
    for(let k=0;k<10;k++){
      const th=(98+k*13.2)*conv;
      [[R+5,-30],[R-7,34]].forEach(p=>{
        const x=cx+side*p[0]*Math.cos(th), y=cy+p[0]*Math.sin(th);
        const tang=Math.atan2(Math.cos(th),-Math.sin(th)*side)/conv;
        leaves+='<ellipse cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" rx="4.3" ry="11" transform="rotate('+(tang-90+side*p[1]*(-1)).toFixed(1)+' '+x.toFixed(1)+' '+y.toFixed(1)+')" fill="url(#lg)" opacity="'+(0.55+k*0.045).toFixed(2)+'"/>';
      });
    }
  });
  const u='url(#tg-silver)';
  return '<svg viewBox="0 0 200 200"><defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--ac2)"/><stop offset="1" stop-color="var(--ac)"/></linearGradient><radialGradient id="eg" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="var(--ac)" stop-opacity=".55"/><stop offset="1" stop-color="var(--ac)" stop-opacity="0"/></radialGradient></defs><circle cx="100" cy="106" r="92" fill="url(#eg)"/>'+leaves+
    '<g transform="translate(41 36) scale(5.1)"><path d="M7 2.8h10v6.5a5 5 0 0 1-10 0z" fill="'+u+'"/><path d="M7 4.8H4v1.8a3.6 3.6 0 0 0 3.6 3.6M17 4.8h3v1.8a3.6 3.6 0 0 1-3.6 3.6" fill="none" stroke="'+u+'" stroke-width="1.5" stroke-linecap="round"/><path d="M10.4 14h3.2v3.2h-3.2z" fill="'+u+'"/><path d="M7.8 17.6h8.4l.9 3.6H6.9z" fill="'+u+'"/><path d="M8.9 4.3h2.3v5.4c0 1 .4 1.6 1.1 2.1-2.1.1-3.4-1.3-3.4-3.3z" fill="#fff" fill-opacity=".5"/><circle cx="12" cy="6.6" r="1.7" fill="var(--ac)" opacity=".85"/></g></svg>';
}
function logoMark(){
  return '<svg class="lm" viewBox="0 0 48 48"><defs><linearGradient id="lmg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--ac)"/><stop offset="1" stop-color="#0a1030"/></linearGradient></defs><rect x="1.5" y="1.5" width="45" height="45" rx="13" fill="url(#lmg)" stroke="rgba(255,255,255,.35)" stroke-width="1.2"/><path fill="#fff" fill-rule="evenodd" d="M16.5 15.5h15a7.5 7.5 0 0 1 7.4 6.4l.9 6.3a4.1 4.1 0 0 1-7.2 3.2l-2.4-3.1a2.6 2.6 0 0 0-2-1h-8.4a2.6 2.6 0 0 0-2 1l-2.4 3.1a4.1 4.1 0 0 1-7.2-3.2l.9-6.3a7.5 7.5 0 0 1 7.4-6.4zM16 20.2v2.2h-2.2v2.2H16v2.2h2.2v-2.2h2.2v-2.2h-2.2v-2.2zM29.5 20.5a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2zM33.6 24.4a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2z"/></svg>';
}

/* ---------- helpers ---------- */
function fmtDur(s){ s=s||0; if(s>=3600) return (s/3600).toFixed(1).replace('.0','')+'h'; return Math.floor(s/60)+'m'; }
function fmtLong(s){ s=s||0; const h=Math.floor(s/3600), m=Math.floor(s%3600/60); return h?h+'h '+m+'m':m+'m'; }
function fmtProg(a){ return a.kind==='t'?fmtDur(a.cur)+' / '+fmtDur(a.target):a.cur+' / '+a.target; }
function fmtPlay(s){ if(!s) return 'Not played yet'; if(s<60) return 'Under a minute played'; const h=Math.floor(s/3600), m=Math.floor(s%3600/60); return (h?h+'h ':'')+m+'m played'; }
function fmtAgo(ts){ if(!ts) return ''; const d=(Date.now()/1000-ts); if(d<3600) return 'just now'; if(d<86400) return 'today'; const n=Math.floor(d/86400); return n===1?'yesterday':n+' days ago'; }
const fmtDate=ts=>ts?new Date(ts*1000).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}):'';
function hue(n){ let h=0; for(const c of n) h=(h*31+c.charCodeAt(0))%360; return 'hsl('+h+' 45% 32%)'; }
async function api(path, body){
  const opt = body===undefined ? {headers:{'X-Token':TOKEN}} :
    {method:'POST', headers:{'X-Token':TOKEN,'Content-Type':'application/json'}, body:JSON.stringify(body)};
  const r = await fetch(path,opt);
  let j={}; try{ j=await r.json(); }catch(e){ j={error:'Bad response'}; }
  if(!r.ok || j.error) throw new Error(j.error||r.statusText);
  return j;
}
let toastT;
function toast(m){ const t=$('#toast'); t.textContent=m; t.classList.add('show'); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.remove('show'),4200); }
function busy(msg){ if(msg){ $('#busyMsg').textContent=msg; $('#busy').classList.add('open'); } else $('#busy').classList.remove('open'); }
const flagged=new Set();
function flag(n){ if(flagged.has(n)) return; flagged.add(n); api('/api/flag',{name:n}).catch(()=>{}); }

/* ---------- sound ---------- */
let AC=null, sndOn=true, popT;
function snd(f,d,type,v,when,force){ if(!sndOn&&!force) return; try{ AC=AC||new (window.AudioContext||window.webkitAudioContext)(); const o=AC.createOscillator(), g=AC.createGain(), n=AC.currentTime+(when||0), vol=(v||.06)*UI.vol*2; o.type=type||'sine'; o.frequency.value=f; o.connect(g); g.connect(AC.destination); g.gain.setValueAtTime(.0001,n); g.gain.exponentialRampToValueAtTime(vol,n+.015); g.gain.exponentialRampToValueAtTime(.0001,n+d); o.start(n); o.stop(n+d+.02); }catch(e){} }
const sfx={move:()=>snd(660,.06,'triangle',.05),ok:()=>{snd(523,.12,'sine',.07);snd(784,.22,'sine',.07,.08)},open:()=>{snd(440,.1,'triangle',.05);snd(660,.14,'triangle',.05,.06)},boot:()=>[392,523,659,784].forEach((f,i)=>snd(f,.9,'sine',.05,i*.12))};

/* ---------- look & feel ---------- */
const UIDEF={theme:'midnight',anim:'on',particles:true,sfx:true,vol:.5,clock24:false,dim:1,popups:true,popsfx:true};
const UI=Object.assign({},UIDEF);
const THEMES=[['midnight','Midnight','#3a86ff'],['aurora','Aurora','#1fd1a5'],['ruby','Ruby','#ff4d63'],['violet','Violet','#9b6bff'],['sunset','Sunset','#ff8a3d'],['mono','Mono','#d9dde6']];
function applyUI(){
  const r=document.documentElement; r.dataset.theme=UI.theme; r.dataset.anim=UI.anim; r.style.setProperty('--br',UI.dim);
  sndOn=UI.sfx; fxToggle(); tick();
}
const saveUI=()=>api('/api/settings',{ui:UI}).catch(()=>{});
const fx=$('#fx'), fc=fx.getContext('2d'); let ps=[], fxOn=false, fxRaf=0;
function fxToggle(){
  const on=UI.particles&&UI.anim!=='off';
  if(on&&!fxOn){ fxOn=true; fx.width=innerWidth; fx.height=innerHeight;
    if(!ps.length) for(let i=0;i<46;i++) ps.push({x:Math.random()*fx.width,y:Math.random()*fx.height,r:Math.random()*2+.6,s:Math.random()*.25+.08,a:Math.random()*.5+.15,p:Math.random()*6});
    fxLoop(); }
  else if(!on&&fxOn){ fxOn=false; cancelAnimationFrame(fxRaf); fc.clearRect(0,0,fx.width,fx.height); }
}
function fxLoop(){
  if(!fxOn) return; fc.clearRect(0,0,fx.width,fx.height); const t=Date.now()/1000;
  fc.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--ac2').trim()||'#fff';
  for(const p of ps){ p.y-=p.s; p.x+=Math.sin(t+p.p)*.25; if(p.y<-5){ p.y=fx.height+5; p.x=Math.random()*fx.width; }
    fc.globalAlpha=p.a*(.6+.4*Math.sin(t*1.5+p.p)); fc.beginPath(); fc.arc(p.x,p.y,p.r,0,6.283); fc.fill(); }
  fc.globalAlpha=1; fxRaf=requestAnimationFrame(fxLoop);
}

/* ---------- trophy pop-ups ---------- */
let popQ=[], popBusy=false;
function queueNew(l){ if(!UI.popups) return; (l||[]).forEach(n=>popQ.push(n)); runPop(); }
function runPop(){
  if(popBusy||!popQ.length) return; popBusy=true; const n=popQ.shift();
  popTrophy(n.name, n.sub||(n.tier==='plat'?'Platinum trophy earned!':(n.game?'Trophy earned · '+n.game:'Trophy earned')), n.tier||'bronze', n.icon||'trophy');
  setTimeout(()=>{ popBusy=false; runPop(); },4800);
}
function popTrophy(title,sub,tier,icon){ const p=$('#pop'); p.innerHTML=badge(icon||'trophy',tier||'bronze')+'<div><small>'+esc(sub)+'</small><b>'+esc(title)+'</b></div>'; p.classList.add('show'); if(UI.popsfx){ snd(880,.18,'sine',.06,0,true); setTimeout(()=>snd(1320,.3,'sine',.06,0,true),130); } clearTimeout(popT); popT=setTimeout(()=>p.classList.remove('show'),4200); }

/* ---------- smooth building blocks ---------- */
/* cross-fading layers: the new text slides in while the old one slides out, nothing "restarts" */
function Xf(el){ el.innerHTML='<div class="xl on"></div><div class="xl"></div>'; this.L=Array.from(el.children); this.i=0; this.key=null; }
Xf.prototype.set=function(html,dir,key,instant){
  const A=this.L[this.i], B=this.L[1-this.i], d=(dir||0)*30;
  if(key!==undefined&&key===this.key){ A.innerHTML=html; return; }
  this.key=key; B.innerHTML=html;
  if(instant||UI.anim==='off'||!A.innerHTML.trim()){
    A.style.transition=B.style.transition='none'; A.classList.remove('on'); B.classList.add('on'); A.style.transform=B.style.transform='';
    void B.offsetWidth; A.style.transition=B.style.transition='';
  } else {
    B.style.transition='none'; B.style.transform='translateX('+d+'px)'; void B.offsetWidth; B.style.transition='';
    B.classList.add('on'); B.style.transform='';
    A.classList.remove('on'); A.style.transform='translateX('+(-d)+'px)';
  }
  this.i=1-this.i;
};
let HX=null, SX=null;
/* a glowing indicator that glides to the active element */
function moveInd(ind,el,instant){
  if(!el||!el.offsetWidth){ ind.style.opacity=0; return; }
  if(instant) ind.style.transition='none';
  ind.style.width=el.offsetWidth+'px'; ind.style.height=el.offsetHeight+'px';
  ind.style.transform='translate3d('+el.offsetLeft+'px,'+el.offsetTop+'px,0)'; ind.style.opacity=1;
  if(instant){ void ind.offsetWidth; ind.style.transition=''; }
}
/* the plate under the selected game */
function placePlate(box,instant){
  const c=$(box), pl=c.querySelector(':scope>.plate'), t=c.querySelector('.tile.sel');
  if(!pl) return; if(!t){ pl.style.opacity=0; return; }
  const g=box==='#grid', el=g?(t.closest('.cell')||t):t, pad=g?12:11, k=g?1:1.12;
  const w=el.offsetWidth*k+pad*2, hh=el.offsetHeight*k+pad*2;
  if(instant) pl.style.transition='none';
  pl.style.width=w+'px'; pl.style.height=hh+'px';
  pl.style.transform='translate3d('+(el.offsetLeft+el.offsetWidth/2-w/2)+'px,'+(el.offsetTop+el.offsetHeight/2-hh/2)+'px,0)'; pl.style.opacity=1;
  if(instant){ void pl.offsetWidth; pl.style.transition=''; }
}
let rowTarget=0, rowRaf=0;
function scrollRowTo(x,instant){
  const r=$('#row'); x=Math.max(0,Math.min(r.scrollWidth-r.clientWidth,x)); rowTarget=x;
  if(instant||UI.anim==='off'){ r.scrollLeft=x; return; }
  if(!rowRaf) rowRaf=requestAnimationFrame(stepRow);
}
function stepRow(){
  const r=$('#row'), d=rowTarget-r.scrollLeft;
  if(Math.abs(d)<.6){ r.scrollLeft=rowTarget; rowRaf=0; return; }
  const st=d*.17; r.scrollLeft+=Math.abs(st)<1?Math.sign(d):st; rowRaf=requestAnimationFrame(stepRow);
}

let gridTarget=0, gridRaf=0;
function scrollGridTo(y,instant){ const g=$('#grid'); y=Math.max(0,Math.min(g.scrollHeight-g.clientHeight,y)); gridTarget=y;
  if(instant||UI.anim==='off'){ g.scrollTop=y; return; } if(!gridRaf) gridRaf=requestAnimationFrame(stepGrid); }
function stepGrid(){ const g=$('#grid'), d=gridTarget-g.scrollTop; if(Math.abs(d)<.6){ g.scrollTop=gridTarget; gridRaf=0; return; }
  const st=d*.2; g.scrollTop+=Math.abs(st)<1?Math.sign(d):st; gridRaf=requestAnimationFrame(stepGrid); }
$('#grid').addEventListener('wheel',()=>{ gridTarget=$('#grid').scrollTop; },{passive:true});
/* ---------- background crossfade ---------- */
let bgFlip=0, bgUrl='', bgTok=0;
function setBg(url){
  url=url||''; if(url===bgUrl) return; bgUrl=url; const tok=++bgTok;
  const L=document.querySelectorAll('.bg div');
  const apply=()=>{ if(tok!==bgTok) return; const nxt=L[1-bgFlip];
    nxt.style.backgroundImage=url?'url("'+url+'")':'none'; nxt.classList.add('on'); L[bgFlip].classList.remove('on'); bgFlip=1-bgFlip; };
  if(!url) return apply();
  const im=new Image(); im.onload=apply; im.onerror=apply; im.src=url;
}

/* ---------- lists ---------- */
const isGrid=()=>view==='lib'||view==='fav';
function homeList(){
  const base=(a,b)=>(b.fav?1:0)-(a.fav?1:0)||(b.last_played||0)-(a.last_played||0)||(a.added||0)-(b.added||0);
  let l=games.slice();
  if(homeF==='recent') l=l.filter(g=>g.last_played).sort((a,b)=>b.last_played-a.last_played);
  else if(homeF==='fav') l=l.filter(g=>g.fav).sort(base);
  else if(homeF==='most') l=l.filter(g=>g.playtime>0).sort((a,b)=>b.playtime-a.playtime);
  else l.sort(base);
  return l;
}
function libList(){
  const s=q.toLowerCase(); let so=sort, l=games.filter(g=>!s||g.name.toLowerCase().includes(s));
  if(view==='fav'){ l=l.filter(g=>g.fav); if(favTab==='recent'){ so='recent'; l=l.filter(g=>g.last_played); } if(favTab==='most'){ so='played'; l=l.filter(g=>g.playtime>0); } }
  else { if(libTab==='inst') l=l.filter(g=>g.installed!==false); if(libTab==='most'){ so='played'; l=l.filter(g=>g.playtime>0); } if(libTab==='recent') so='added'; }
  const by={name:(a,b)=>a.name.localeCompare(b.name),recent:(a,b)=>(b.last_played||0)-(a.last_played||0),played:(a,b)=>(b.playtime||0)-(a.playtime||0),added:(a,b)=>(b.added||0)-(a.added||0)}[so];
  return l.sort(by);
}
const cur=()=>view==='home'?homeList():view==='ach'?[]:libList();
const sel=()=>games.find(g=>g.id===selId)||null;
const cols=()=>Math.max(1,getComputedStyle($('#grid')).gridTemplateColumns.split(' ').length);

/* ---------- side panel: options change with the page ---------- */
const SIDE={
  home:()=>({key:homeF,set:k=>{ homeF=k; render(); },items:[['all','gamepad','All Games'],['recent','clock','Recently Played'],['fav','heart','Favorites'],['most','stats','Most Played']],add:true}),
  lib:()=>({key:libTab,set:k=>{ libTab=k; render(); },items:[['all','gamepad','All Games'],['inst','installed','Installed'],['most','stats','Most Played'],['recent','clock','Recently Added']],add:true}),
  fav:()=>({key:favTab,set:k=>{ favTab=k; render(); },items:[['all','heart','All Favorites'],['recent','clock','Recently Played'],['most','stats','Most Played']],add:false}),
  ach:()=>({key:achSub,set:k=>{ achSub=k; render(); },items:[['overview','trophy','Achievements'],['games','gamepad','All Games'],['stats','stats','Stats'],['settings','gear','Settings']],add:false})
};
let sideView=null;
function renderSide(){
  const d=SIDE[view](), list=$('#sideList'), fresh=sideView!==view; sideView=view;
  list.innerHTML=d.items.map((it,i)=>'<div class="sn'+(it[0]===d.key?' on':'')+'" data-k="'+it[0]+'" style="--n:'+i+'">'+svg(it[1])+'<span>'+it[2]+'</span></div>').join('')+(d.add?'<div class="sn add" data-add="1">'+svg('plus')+'<span>Add Game</span></div>':'');
  list.querySelectorAll('.sn').forEach(n=>n.onclick=()=>{ if(n.dataset.add) return addGame(); sfx.move(); gd=false; d.set(n.dataset.k); });
  if(fresh&&UI.anim!=='off'){ list.classList.remove('fresh'); void list.offsetWidth; list.classList.add('fresh'); setTimeout(()=>list.classList.remove('fresh'),900); }
  moveInd($('#sideInd'),list.querySelector('.sn.on'),fresh);
}

/* ---------- tiles ---------- */
function tile(g){
  const t=document.createElement('div'); t.className='tile'+(g.id===selId?' sel':''); t.dataset.id=g.id;
  if(g.cover_url) t.innerHTML='<img draggable="false" src="'+esc(g.cover_url)+'">';
  else { t.style.background='linear-gradient(135deg,'+hue(g.name)+',#0b1020)'; t.innerHTML='<span class="ph">'+esc(g.name.trim().charAt(0).toUpperCase())+'</span>'; }
  if(g.fav) t.insertAdjacentHTML('beforeend','<span class="star">'+svg('star')+'</span>');
  
  return t;
}
function addTile(){ const a=document.createElement('div'); a.className='tile add'; a.innerHTML=svg('plus'); a.title='Add game'; a.onclick=addGame; return a; }
function markSel(box,instant){
  $$(box+' .tile').forEach(t=>t.classList.toggle('sel',t.dataset.id===selId));
  const el=document.querySelector(box+' .tile.sel'); placePlate(box,instant); if(!el) return;
  if(box==='#row'){ const r=$('#row'); scrollRowTo(el.offsetLeft-r.clientWidth/2+el.offsetWidth/2,instant); }
  else { const g=$('#grid'), c=el.closest('.cell')||el, top=c.offsetTop-g.scrollTop, bot=top+c.offsetHeight; let y=null;
    if(top<46) y=c.offsetTop-52; else if(bot>g.clientHeight-52) y=c.offsetTop+c.offsetHeight-g.clientHeight+60;
    if(y!==null) scrollGridTo(y,instant); }
}
function pick(id,dir){
  if(id===selId) return;
  const l=cur(), a=l.findIndex(g=>g.id===selId), b=l.findIndex(g=>g.id===id); selId=id;
  if(isGrid()){ markSel('#grid'); if(gd) paintGD(); }
  else { markSel('#row'); updArrows(); queueHero(dir||(b>=a?1:-1)); }
}
function move(d){ const l=cur(), i=l.findIndex(g=>g.id===selId), n=Math.max(0,Math.min(l.length-1,i+d)); if(n===i||!l[n]) return; sfx.move(); pick(l[n].id,d>0?1:-1); }
function updArrows(){
  const l=homeList(), i=l.findIndex(g=>g.id===selId);
  $('#aL').classList.toggle('off', i<=0); $('#aR').classList.toggle('off', i<0||i>=l.length-1);
}

/* ---------- Home ---------- */
let heroT=0, heroTok=0;
function queueHero(dir){ clearTimeout(heroT); heroT=setTimeout(()=>paintHero(dir),UI.anim==='off'?0:70); }
const probe=u=>new Promise(r=>{ const i=new Image(); i.onload=()=>r(true); i.onerror=()=>r(false); i.src=u; setTimeout(()=>r(false),700); });
async function paintHero(dir,instant){
  const tok=++heroTok, g=sel();
  if(!g){
    const none=games.length&&homeF!=='all';
    HX.set('<h1>'+(none?'Nothing here yet':games.length?'Add a game':'Welcome')+'</h1><p class="tag">'+(none?'Play, favorite or add games and they will show up in this list.':'Press + and choose the game\'s .exe file. It shows up here with its art. The game stays where it is.')+'</p><div class="btns"><button class="btn primary badd">'+svg('plus')+'Add game</button></div>',0,'none',instant);
    SX.set('',0,'none',instant); setBg(''); return;
  }
  const hasLogo=g.logo_url?await probe(g.logo_url):false;
  if(tok!==heroTok) return;
  const tag=(g.desc||'').split(/(?<=[.!?])\s/)[0];
  const chips=[g.developer,(g.genres||[]).join(' · '),g.last_played?'Last played '+fmtAgo(g.last_played):''].filter(Boolean).map(x=>'<span>'+esc(x)+'</span>').join('');
  HX.set((hasLogo?'<img class="logo" src="'+esc(g.logo_url)+'"><h1 class="sr">'+esc(g.name)+'</h1>':'<h1>'+esc(g.name)+'</h1>')+'<p class="tag">'+esc(tag)+'</p><div class="chips">'+chips+'</div><div class="btns"><button class="btn primary bplay">'+svg('play')+'<span>Play</span></button><button class="btn round bmore" title="More">'+svg('dots')+'</button></div>',dir,g.id,instant);
  SX.set('<div class="stats"><div><span>'+svg('gamepad')+'Play Time</span><b>'+esc(fmtPlay(g.playtime).replace(' played',''))+'</b></div><i></i><div class="st" id="stAch"><span>'+svg('trophy')+'Achievements</span><b>'+(g.tro_total?g.tro_unlocked+' / '+g.tro_total:'—')+'</b></div></div>',dir,g.id,instant);
  setBg(g.hero_url||g.cover_url);
}
function renderHome(l,instant){
  const row=$('#row'); row.innerHTML='<i class="plate"></i>';
  l.forEach(g=>{ const t=tile(g); t.onclick=()=>pick(g.id); t.ondblclick=()=>{ pick(g.id); play(); }; row.appendChild(t); });
  row.appendChild(addTile());
  markSel('#row',true); updArrows(); paintHero(0,instant);
}

/* ---------- game page (opens inside the Library) ---------- */
let gd=false;
function openGD(){ if(!sel()) return; gd=true; sfx.ok(); document.body.classList.add('gdv'); $('#gd').classList.remove('hide'); paintGD(); }
function closeGD(){ gd=false; sfx.move(); document.body.classList.remove('gdv'); $('#gd').classList.add('hide'); markSel('#grid',true); }
function paintGD(){
  const g=sel(), el=$('#gd'); if(!g) return;
  const l=cur(), i=l.findIndex(x=>x.id===g.id);
  const cover=g.cover_url?'<img draggable="false" src="'+esc(g.cover_url)+'">':'<span class="ph" style="background:linear-gradient(135deg,'+hue(g.name)+',#0b1020)">'+esc(g.name.trim().charAt(0).toUpperCase())+'</span>';
  const chips=[g.developer,(g.genres||[]).join(' · ')].filter(Boolean).map(x=>'<span>'+esc(x)+'</span>').join('');
  const st=(ic,lab,v,cls)=>'<div class="gs'+(cls||'')+'"><span>'+svg(ic)+lab+'</span><b>'+esc(v)+'</b></div>';
  el.innerHTML='<div class="gtop"><button class="gback">'+svg('chevL')+'<span>'+(view==='fav'?'Favorites':'Library')+'</span></button><span class="grow"></span>'+
    '<button class="btn round gprev" style="opacity:'+(i>0?1:.35)+'">'+svg('chevL')+'</button><span class="gcount">'+(i+1)+' / '+l.length+'</span><button class="btn round gnext" style="opacity:'+(i<l.length-1?1:.35)+'">'+svg('chevR')+'</button></div>'+
    '<div class="gdm"><div class="gcover">'+cover+(g.fav?'<span class="star">'+svg('star')+'</span>':'')+'</div><div class="gdi"><h1>'+esc(g.name)+'</h1>'+(chips?'<div class="chips">'+chips+'</div>':'')+
    (g.desc?'<p class="gdesc">'+esc(g.desc)+'</p>':'')+
    '<div class="btns"><button class="btn primary gplay">'+svg('play')+'<span>Play</span></button><button class="btn round gfav'+(g.fav?' on':'')+'" title="'+(g.fav?'Remove from favorites':'Add to favorites')+'">'+svg('heart')+'</button><button class="btn round gach" title="Achievements">'+svg('trophy')+'</button><button class="btn round gmore" title="More">'+svg('dots')+'</button></div>'+
    '<div class="gstats">'+st('clock','Play Time',g.playtime?fmtPlay(g.playtime).replace(' played',''):'Not played yet')+st('play','Times Played',String(g.launches||0))+st('gamepad','Last Played',g.last_played?fmtAgo(g.last_played):'Never')+'<div class="gs click gtro"><span>'+svg('trophy')+'Trophies</span><b>'+(g.tro_total?g.tro_unlocked+' / '+g.tro_total:'—')+'</b></div></div></div></div>';
  el.querySelector('.gback').onclick=closeGD; el.querySelector('.gplay').onclick=play; el.querySelector('.gmore').onclick=moreMenu;
  el.querySelector('.gach').onclick=openAch; el.querySelector('.gtro').onclick=openAch;
  el.querySelector('.gprev').onclick=()=>move(-1); el.querySelector('.gnext').onclick=()=>move(1);
  el.querySelector('.gfav').onclick=async()=>{ await api('/api/fav',{id:g.id}); await reload(g.id); };
  setBg(g.hero_url||g.cover_url);
}

/* ---------- Library / Favorites ---------- */
function renderLib(l){
  const f=view==='fav';
  const title=q?'Search: “'+q+'”':f?{all:'Favorites',recent:'Recently Played',most:'Most Played'}[favTab]:{all:'All Games',inst:'Installed',most:'Most Played',recent:'Recently Added'}[libTab];
  const canSort=q||(f?favTab==='all':libTab==='all'||libTab==='inst');
  $('#libhead').innerHTML='<h2>'+esc(title)+'</h2><span class="cnt">'+l.length+(l.length===1?' game':' games')+'</span>'+(canSort?'<select id="sortSel">'+[['name','Name'],['recent','Last played'],['played','Play time'],['added','Recently added']].map(o=>'<option value="'+o[0]+'"'+(o[0]===sort?' selected':'')+'>Sort by: '+o[1]+'</option>').join('')+'</select>':'');
  const so=$('#sortSel'); if(so) so.onchange=e=>{ sort=e.target.value; render(); };
  const gr=$('#grid'); gr.innerHTML='<i class="plate"></i>';
  l.forEach(g=>{ const c=document.createElement('div'); c.className='cell'; c.appendChild(tile(g));
    c.insertAdjacentHTML('beforeend','<div class="cap"><b>'+esc(g.name)+'</b><small>'+esc(fmtPlay(g.playtime))+'</small></div>');
    c.onclick=()=>{ pick(g.id); openGD(); }; gr.appendChild(c); });
  if(!f){ const c=document.createElement('div'); c.className='cell'; c.appendChild(addTile()); c.insertAdjacentHTML('beforeend','<div class="cap"><b>Add game</b><small>Choose an .exe</small></div>'); c.onclick=addGame; gr.appendChild(c); }
  if(!l.length) gr.insertAdjacentHTML('beforeend','<div class="empty">'+svg(f?'heart':'gamepad')+'<p>'+(q?'No games match your search.':f?'No favorites here yet. Select a game and press F, or use the ••• button on Home.':'Nothing here yet.')+'</p></div>');
  markSel('#grid',true);
}

/* ---------- Achievements page ---------- */
let achTok=0;
function achAgg(){
  const rows=[{gid:null,name:APP_NAME,items:achData.launcher,brand:true}];
  achData.games.forEach(g=>rows.push({gid:g.id,name:g.name,cover:g.cover_url,hero:g.hero_url,items:g.items}));
  const all=[]; rows.forEach(r=>r.items.forEach(i=>all.push(Object.assign({},i,{gid:r.gid,gname:r.name,hero:r.hero,cover:r.cover}))));
  const done=all.filter(i=>i.achieved), prog=all.filter(i=>!i.achieved&&i.cur>0), lock=all.filter(i=>!i.achieved&&!(i.cur>0));
  rows.forEach(r=>{ r.done=r.items.filter(i=>i.achieved).length; r.total=r.items.length; r.pc=r.total?Math.round(100*r.done/r.total):0; r.t={bronze:0,silver:0,gold:0,plat:0}; r.items.forEach(i=>{ if(i.achieved) r.t[i.tier]++; }); });
  return {rows,all,done,prog,lock,xp:done.reduce((s,i)=>s+XP[i.tier],0)};
}
function gameRow(r){
  const th=r.brand?'<div class="th">'+logoMark()+'</div>':'<div class="th" style="'+(r.hero||r.cover?'background-image:url(\''+esc(r.hero||r.cover)+'\')':'background:linear-gradient(135deg,'+hue(r.name)+',#0b1020)')+'">'+(r.hero||r.cover?'':esc(r.name.charAt(0).toUpperCase()))+'</div>';
  return '<div class="gr" data-id="'+esc(r.gid||'')+'">'+th+'<div><h3>'+esc(r.name)+'</h3><div class="sub">'+trophy('gold')+r.done+' / '+r.total+' Achievements</div></div><div class="pg"><div class="bar"><i style="width:'+r.pc+'%"></i></div><b>'+r.pc+'%</b></div><div class="tc">'+['plat','gold','silver','bronze'].map(t=>'<span>'+trophy(t)+r.t[t]+'</span>').join('')+'</div></div>';
}
function ovHTML(A){
  const total=A.all.length, pc=total?Math.round(100*A.done.length/total):0;
  const rec=A.done.filter(i=>i.ts).sort((a,b)=>b.ts-a.ts).slice(0,9);
  const rows=A.rows.slice().sort((a,b)=>b.pc-a.pc||b.done-a.done).slice(0,3);
  return '<div class="ahead"><div class="emblem">'+emblem()+'<div class="elabel">Achievements</div></div><div class="astats"><div class="acols">'+
    [['plat',total,'Total Achievements'],['gold',A.done.length,'Completed'],['silver',A.prog.length,'In Progress'],['bronze',A.lock.length,'Locked']].map(c=>'<div class="acol">'+trophy(c[0])+'<b>'+c[1]+'</b><span>'+c[2]+'</span></div>').join('')+
    '</div><div class="abar"><div class="bar"><i style="width:'+pc+'%"></i></div><b>'+pc+'%</b></div></div></div>'+
    '<div class="sec2">'+svg('clock')+'Recent Achievements</div>'+
    (rec.length?'<div class="recent">'+rec.map(i=>{ const art=i.hero||i.cover; return '<div class="rc" data-id="'+esc(i.gid||'')+'"><div class="art" style="'+(art?'background-image:url(\''+esc(art)+'\')':'background:linear-gradient(135deg,rgba(var(--acr),.55),#0b1020)')+'">'+badge(i.icon,i.tier)+'</div><div class="bd"><b>'+esc(i.name)+'</b><small>'+esc(i.desc)+'</small><div class="rcf"><span>'+trophy(i.tier)+XP[i.tier]+' XP</span><span>'+esc(fmtDate(i.ts))+'</span></div></div></div>'; }).join('')+'</div>':'<div class="note">Nothing unlocked yet. Add a game, start it, mark a favorite… trophies show up here.</div>')+
    '<div class="sec2">'+svg('star')+'Game Achievements<a data-go="games">See All '+svg('arrowR')+'</a></div>'+rows.map(gameRow).join('');
}
function gamesHTML(A){ return '<div class="pg-title">'+svg('gamepad')+'All Games</div>'+A.rows.map(gameRow).join(''); }
function statsHTML(A){
  const tot=games.reduce((s,g)=>s+(g.playtime||0),0), launches=games.reduce((s,g)=>s+(g.launches||0),0), favs=games.filter(g=>g.fav).length;
  const card=(ic,v,l)=>'<div class="sc"><div class="ib">'+svg(ic)+'</div><div><b>'+v+'</b><small>'+l+'</small></div></div>';
  const top=games.filter(g=>g.playtime>0).sort((a,b)=>b.playtime-a.playtime).slice(0,6), mx=top[0]?top[0].playtime:1;
  const tc={bronze:0,silver:0,gold:0,plat:0}; A.done.forEach(i=>tc[i.tier]++);
  const tmax=Math.max(1,...Object.values(tc));
  return '<div class="pg-title">'+svg('stats')+'Stats</div><div class="scards">'+card('clock',esc(fmtLong(tot)),'Total play time')+card('play',launches,'Game launches')+card('gamepad',games.length,'Games in library')+card('heart',favs,'Favorites')+card('trophy',A.done.length+' / '+A.all.length,'Trophies earned')+card('star',A.xp,'Total XP')+'</div>'+
    '<div class="sec2">'+svg('stats')+'Most played</div>'+(top.length?top.map(g=>'<div class="hb"><span>'+esc(g.name)+'</span><div class="bar"><i style="width:'+Math.max(3,Math.round(100*g.playtime/mx))+'%"></i></div><span>'+esc(fmtLong(g.playtime))+'</span></div>').join(''):'<div class="note">No play time yet. Turn on <b>Count play time</b> in Achievements → Settings.</div>')+
    '<div class="sec2">'+svg('trophy')+'Trophies by tier</div>'+['plat','gold','silver','bronze'].map(t=>'<div class="hb"><span>'+TIER[t]+'</span><div class="bar"><i style="width:'+Math.round(100*tc[t]/tmax)+'%"></i></div><span>'+tc[t]+'</span></div>').join('');
}
function achSetHTML(){
  const tg=(id,label,on)=>'<label class="row2"><span>'+label+'</span><input type="checkbox" id="'+id+'" '+(on?'checked':'')+'></label>';
  return '<div class="pg-title">'+svg('gear')+'Achievement Settings</div><div class="apanel"><h2>Trophies</h2>'+tg('aPop','Show a pop-up when I earn a trophy',UI.popups)+tg('aSnd','Play a sound with the pop-up',UI.popsfx)+
    '<h2>Play time</h2>'+tg('aTrack','Count play time (keeps a tiny hidden helper running while the game is open)',settings.track_play)+'<div class="help">Play-time trophies and the Stats page need this turned on.</div>'+
    '<h2>Steam</h2><label style="display:block;font-size:13px;opacity:.7;margin:10px 0 6px">Steam API key (optional)</label><input id="sKey" value="'+esc(settings.steam_key||'')+'" placeholder="32 characters">'+
    '<label style="display:block;font-size:13px;opacity:.7;margin:14px 0 6px">Your SteamID64 (optional)</label><input id="sId" value="'+esc(settings.steam_id||'')+'" placeholder="17 digits">'+
    '<div class="help">Only needed to see your real achievements for games you own on Steam. Get a free key at steamcommunity.com/dev/apikey and find your SteamID64 at steamid.io. Your Steam profile\'s "Game details" must be Public.</div>'+
    '<div class="line end"><span class="grow"></span><button class="btn primary" id="aSave">Save</button></div></div>';
}
function bindAch(){
  const box=$('#ach');
  box.querySelectorAll('[data-go]').forEach(a=>a.onclick=()=>{ achSub=a.dataset.go; render(); });
  box.querySelectorAll('.gr,.rc').forEach(el=>el.onclick=()=>{ const id=el.dataset.id; if(!id) return openAllAch(); selId=id; openAch(); });
  if(achSub==='settings'){
    $('#aPop').onchange=e=>{ UI.popups=e.target.checked; saveUI(); }; $('#aSnd').onchange=e=>{ UI.popsfx=e.target.checked; saveUI(); if(UI.popsfx) snd(880,.18,'sine',.06,0,true); };
    $('#aTrack').onchange=async e=>{ try{ await api('/api/settings',{track_play:e.target.checked}); settings.track_play=e.target.checked; }catch(x){ toast(x.message); } };
    $('#aSave').onclick=async()=>{ try{ await api('/api/settings',{steam_key:$('#sKey').value,steam_id:$('#sId').value}); settings.steam_key=$('#sKey').value; settings.steam_id=$('#sId').value; toast('Saved'); }catch(x){ toast(x.message); } };
  }
}
async function renderAch(){
  const box=$('#ach'), tok=++achTok, g=sel()||games[0]; setBg(g?(g.hero_url||g.cover_url):'');
  if(achSub==='settings'){ flag('settings'); box.innerHTML=achSetHTML(); bindAch(); return; }
  const paint=()=>{ const A=achAgg(); box.innerHTML=achSub==='games'?gamesHTML(A):achSub==='stats'?statsHTML(A):ovHTML(A); bindAch(); };
  if(achData) paint(); else box.innerHTML='<div class="note">Loading…</div>';
  try{ const d=await api('/api/ach_overview'); if(tok!==achTok) return; const changed=JSON.stringify(d.launcher)+JSON.stringify(d.games)!==(achData?JSON.stringify(achData.launcher)+JSON.stringify(achData.games):''); achData=d; queueNew(d.new); if(changed||!box.querySelector('.gr,.acol,.sc')) paint(); }
  catch(e){ if(tok===achTok&&!achData) box.innerHTML='<div class="note">'+esc(e.message)+'</div>'; }
}

/* ---------- render ---------- */
function goView(v){ if(v===view) return; gd=false; view=v; if(v!=='ach') achData=achData; render(); }
function render(instant){
  if(view==='lib') flag('lib');
  if(!isGrid()) gd=false; document.body.classList.toggle('libv',isGrid()); document.body.classList.toggle('gdv',gd); $('#gd').classList.toggle('hide',!gd); document.body.classList.toggle('achv',view==='ach');
  $('#home').classList.toggle('hide',view!=='home'); $('#lib').classList.toggle('hide',!isGrid()); $('#ach').classList.toggle('hide',view!=='ach');
  $$('.tb').forEach(n=>n.classList.toggle('on',n.dataset.v===view));
  moveInd($('#tabInd'),$('.tb.on'),!!instant);
  renderSide();
  if(view==='ach'){ renderAch(); $('#count').textContent=''; return; }
  const l=cur(); if(!l.some(g=>g.id===selId)) selId=l[0]?l[0].id:null;
  if(view==='home') renderHome(l,instant); else renderLib(l);
  if(gd){ if(sel()) paintGD(); else { gd=false; document.body.classList.remove('gdv'); $('#gd').classList.add('hide'); } }
  $('#count').textContent=isGrid()?l.length+(l.length===1?' Game':' Games'):'';
}
const mkSig=()=>JSON.stringify(games.map(g=>[g.id,g.name,g.fav,g.cover_url,g.hero_url,g.logo_url,g.installed,g.playtime,g.last_played,g.tro_unlocked,g.launches,g.desc]));
async function reload(keepId,first){
  const d=await api('/api/games'); games=d.games; settings=d.settings; Object.assign(UI,UIDEF,settings.ui||{}); applyUI();
  if(keepId) selId=keepId;
  const s=mkSig(); if(s!==sig||keepId){ sig=s; render(first); }
  queueNew(d.new);
}
function setQ(v,fromInput){ q=v; if(v) flag('search'); if(!fromInput) $('#q').value=v; if(v&&!isGrid()){ view='lib'; libTab='all'; } render(); }

/* ---------- menus & dialogs ---------- */
function modal(html){ sfx.open(); const m=$('#modal'); m.innerHTML='<div class="card">'+html+'</div>'; m.classList.add('open'); m.onmousedown=e=>{ if(e.target===m) closeModal(); }; return m; }
function closeModal(){ const m=$('#modal'); m.classList.remove('open'); m.innerHTML=''; }
function closeAll(){ $('#drawer').classList.remove('open'); closeModal(); }
function moreMenu(){
  const g=sel(); if(!g) return;
  modal('<h2>'+esc(g.name)+'</h2><div class="res"><div class="opt" id="mF">'+svg('heart')+(g.fav?'Remove from favorites':'Add to favorites')+'</div><div class="opt" id="mA">'+svg('trophy')+'Achievements</div><div class="opt" id="mE">'+svg('pencil')+'Edit game</div></div>');
  $('#mF').onclick=async()=>{ closeModal(); await api('/api/fav',{id:g.id}); await reload(g.id); };
  $('#mA').onclick=()=>{ closeModal(); openAch(); }; $('#mE').onclick=()=>{ closeModal(); openEdit(); };
}
function confirmExit(){
  modal('<h2>Close '+APP_NAME+'?</h2><p style="margin:0;opacity:.8;line-height:1.5">The launcher will close. Your games and settings stay saved.</p><div class="line end"><span class="grow"></span><button class="btn" id="xNo">Stay</button><button class="btn danger" id="xYes">'+svg('power')+'Exit</button></div>');
  $('#xNo').onclick=closeModal; $('#xYes').onclick=quit;
}
async function quit(){ try{ await api('/api/quit',{}); try{window.close();}catch(e){} }catch(e){ toast(e.message); } }
async function pathOrDialog(url, body, promptText){
  try{ return await api(url, body); }
  catch(e){
    if(e.message==='cancelled') return null;
    if(e.message==='nodialog'){ const p=prompt(promptText); if(!p) return null; return await api(url, Object.assign({},body,{path:p})); }
    throw e;
  }
}
function addGame(){
  modal('<h2>Add a game</h2><p style="font-size:14.5px;line-height:1.6;opacity:.88;margin:0">Choose the game\'s <b>.exe</b> file. The game stays where it is; the launcher only remembers where it is.<br><br>If you are online, it finds a matching picture for the game automatically, even when the folder name is messy or renamed. If you are offline, the game is added without a picture.</p><div class="line end"><span class="grow"></span><button class="btn" id="agX">Cancel</button><button class="btn primary" id="agGo">'+svg('plus')+'Choose .exe…</button></div>');
  $('#agX').onclick=closeModal; $('#agGo').onclick=()=>{ closeModal(); doAdd(); };
}
async function doAdd(){
  busy('Pick the game file, then wait while its picture is found…');
  try{
    const r=await pathOrDialog('/api/add',{}, "Couldn't open a file window. Paste the full path of the game's .exe:");
    if(r){ games.push(r.game); sig=''; selId=r.game.id; if(view==='ach') view='home'; render(); sfx.ok(); toast(r.note||('Added '+r.game.name+(r.matched?' · picture found online':''))); }
  }catch(e){ toast(e.message); } finally{ busy(false); }
}
async function play(){
  const g=sel(); if(!g) return;
  sfx.ok(); busy('Starting '+g.name+'…');
  try{
    await api('/api/play',{id:g.id});
    setTimeout(()=>{ try{window.close();}catch(e){} document.body.innerHTML='<div style="padding:40px;font:20px sans-serif;color:#fff">Launching… you can close this tab.</div>'; },1300);
  }catch(e){ busy(false); toast(e.message); }
}

/* trophies drawer (per game / launcher) */
function stagger(d){ const x=d.querySelector('.dx'); if(x) x.onclick=()=>d.classList.remove('open'); d.querySelectorAll('.ach').forEach((e,i)=>e.style.animationDelay=(i*35)+'ms'); }
function achHead(title,sub,done,total,items){
  const pc=total?done/total:0, C=2*Math.PI*34, tc={bronze:0,silver:0,gold:0,plat:0}; items.forEach(i=>{ if(i.achieved) tc[i.tier]++; });
  return '<button class="dx" title="Close">'+svg('cross')+'</button><div class="achhead"><div class="ring"><svg viewBox="0 0 84 84"><circle cx="42" cy="42" r="34" class="rb"/><circle cx="42" cy="42" r="34" class="rf" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+(C*(1-pc)).toFixed(1)+'"/></svg><b>'+done+'<small>/'+total+'</small></b></div><div class="grow"><h2>'+esc(title)+'</h2><div class="note" style="margin:2px 0 8px">'+esc(sub)+'</div><div class="tiers">'+['bronze','silver','gold','plat'].map(t=>'<span><i class="tr t-'+t+'"></i>'+tc[t]+'</span>').join('')+'</div></div></div>';
}
function troRow(a){
  const pc=a.target?Math.round(100*a.cur/a.target):0;
  const extra=a.achieved?(a.ts?'<small>Unlocked '+esc(new Date(a.ts*1000).toLocaleDateString())+'</small>':''):'<div class="pbar"><i style="width:'+pc+'%"></i></div><small>'+fmtProg(a)+'</small>';
  return '<div class="ach'+(a.achieved?'':' locked')+'">'+badge(a.icon,a.tier,!a.achieved)+'<div class="grow"><b>'+esc(a.name)+'</b><small>'+esc(a.desc)+'</small>'+extra+'</div>'+(a.achieved?'<span class="tick ok">'+svg('check')+'</span>':'<span class="tier-tag">'+TIER[a.tier]+'</span>')+'</div>';
}
async function openAllAch(){
  const d=$('#drawer'); d.innerHTML='<h2>'+APP_NAME+'</h2><div class="note">Loading…</div>'; d.classList.add('open');
  try{
    const r=await api('/api/trophies'); queueNew(r.new);
    let h=achHead(APP_NAME,'Trophies you earn just by using the launcher.',r.unlocked,r.total,r.items)+'<div class="sec">Launcher trophies</div>';
    h+=r.items.slice().sort((a,b)=>b.achieved-a.achieved).map(troRow).join('');
    d.innerHTML=h+'<div class="line"><button class="btn" id="aClose">Close</button></div>';
    stagger(d); $('#aClose').onclick=()=>d.classList.remove('open');
  }catch(e){ d.innerHTML='<h2>'+APP_NAME+'</h2><div class="note">'+esc(e.message)+'</div><button class="btn" id="aClose">Close</button>'; $('#aClose').onclick=()=>d.classList.remove('open'); }
}
async function openAch(){
  const g=sel(); if(!g) return; const d=$('#drawer');
  d.innerHTML='<h2>'+esc(g.name)+'</h2><div class="note">Loading achievements…</div>'; d.classList.add('open');
  try{
    const r=await api('/api/achievements?id='+g.id); queueNew(r.new);
    const cu=r.custom||[], cdone=cu.filter(x=>x.achieved).length;
    let h=achHead(g.name,'Trophies for this game',cdone,cu.length,cu);
    h+='<div class="sec">Game trophies</div>';
    if(!settings.track_play&&cu.some(x=>x.kind==='t'&&!x.achieved)) h+='<div class="note" style="margin-top:0">Play-time trophies need <b>Count play time</b> turned on in Achievements → Settings.</div>';
    h+=cu.slice().sort((a,b)=>b.achieved-a.achieved).map(troRow).join('');
    if(r.items.length||r.note){
      h+='<div class="sec">'+(r.mode==='steam'?'Steam achievements · synced':'Steam achievements'+(r.items.length?' · tap to tick':''))+'</div>';
      if(r.items.length) h+='<div class="abar" style="margin-bottom:6px"><div class="bar"><i style="width:'+(r.total?Math.round(100*r.unlocked/r.total):0)+'%"></i></div></div><div class="note" style="margin:0 0 6px">'+r.unlocked+' of '+r.total+' unlocked</div>';
      if(r.note) h+='<div class="note">'+esc(r.note)+'</div>';
      h+='<div id="achList"></div>';
    }
    h+='<div class="line"><button class="btn" id="aRef">Refresh</button><button class="btn" id="aClose">Close</button></div>';
    d.innerHTML=h; stagger(d); const list=$('#achList');
    if(list) r.items.forEach(a=>{
      const el=document.createElement('div'); el.className='ach'+(a.achieved?'':' locked')+(r.mode==='manual'?' manual':'');
      el.innerHTML='<div class="aic">'+svg('trophy')+(a.icon?'<img src="'+esc(a.icon)+'" referrerpolicy="no-referrer" onerror="this.style.display=\'none\'">':'')+'</div><div class="grow"><b>'+esc(a.name)+'</b><small>'+esc(a.desc)+(a.rare?' · '+a.rare+'% of players':'')+'</small></div>'+(a.achieved?'<span class="tick ok">'+svg('check')+'</span>':'');
      if(r.mode==='manual') el.onclick=async()=>{ await api('/api/ach_toggle',{id:g.id,name:a.id}); if(!a.achieved){ const r2=await api('/api/achievements?id='+g.id), pl=r2.unlocked===r2.total; queueNew([{name:a.name,tier:pl?'plat':'bronze',icon:'trophy',sub:pl?'Platinum trophy earned!':'Trophy earned'}]); } sig=''; await reload(g.id); openAch(); };
      list.appendChild(el);
    });
    $('#aRef').onclick=openAch; $('#aClose').onclick=()=>d.classList.remove('open');
  }catch(e){ d.innerHTML='<h2>'+esc(g.name)+'</h2><div class="note">'+esc(e.message)+'</div><button class="btn" id="aClose">Close</button>'; $('#aClose').onclick=()=>d.classList.remove('open'); }
}
function openEdit(){
  const g=sel(); if(!g) return;
  modal('<h2>Edit game</h2><label>Name</label><input id="eName" value="'+esc(g.name)+'">'+
    '<label>Steam page (gives the art, description and achievements)</label>'+
    '<div class="line"><input id="eSearch" value="'+esc(g.name)+'"><button class="btn" id="eFind">Search</button></div>'+
    '<div class="res" id="eRes">'+(g.appid?'Currently matched to Steam app '+g.appid:'No Steam page matched yet')+'</div>'+
    '<div class="line wrap"><button class="btn" id="eImg">Choose my own background image…</button><button class="btn" id="eSteam">Use Steam art</button></div>'+
    '<div class="help">Game file: '+esc(g.path)+'</div>'+
    '<div class="line end"><button class="btn danger" id="eDel">Remove from launcher</button><span class="grow"></span><button class="btn" id="eCancel">Close</button><button class="btn primary" id="eSave">Save</button></div>');
  const run=async(fn)=>{ busy('Working…'); try{ await fn(); }catch(e){ toast(e.message); } finally{ busy(false); } };
  $('#eCancel').onclick=closeModal;
  $('#eSave').onclick=()=>run(async()=>{ await api('/api/update',{id:g.id,name:$('#eName').value}); closeModal(); sig=''; await reload(g.id); });
  const find=()=>run(async()=>{
    const r=await api('/api/search?term='+encodeURIComponent($('#eSearch').value)); const box=$('#eRes'); box.innerHTML='';
    if(!r.items.length) box.textContent='Nothing found. Try another spelling.';
    r.items.forEach(it=>{ const o=document.createElement('div'); o.className='opt'; o.textContent=it.name;
      o.onclick=()=>run(async()=>{ await api('/api/update',{id:g.id,appid:it.id}); closeModal(); sig=''; await reload(g.id); toast('Matched to '+it.name); }); box.appendChild(o); });
  });
  $('#eFind').onclick=find; $('#eSearch').onkeydown=e=>{ if(e.key==='Enter') find(); };
  $('#eImg').onclick=()=>run(async()=>{ const r=await pathOrDialog('/api/art',{id:g.id},'Paste the full path of an image file:'); if(r){ closeModal(); sig=''; await reload(g.id); } });
  $('#eSteam').onclick=()=>run(async()=>{ await api('/api/art',{id:g.id,reset:true}); closeModal(); sig=''; await reload(g.id); });
  $('#eDel').onclick=()=>{ if(confirm('Remove "'+g.name+'" from the launcher? The game itself is NOT deleted.')) run(async()=>{ await api('/api/remove',{id:g.id}); closeModal(); selId=null; sig=''; await reload(); }); };
}
function openSettings(){ flag('settings');
  const sw=THEMES.map(t=>'<button class="sw'+(UI.theme===t[0]?' on':'')+'" data-t="'+t[0]+'" style="--c:'+t[2]+'"><i></i>'+t[1]+'</button>').join('');
  const tg=(id,label,on)=>'<label class="row2"><span>'+label+'</span><input type="checkbox" id="'+id+'" '+(on?'checked':'')+'></label>';
  const rg=(id,label,mn,mx,v)=>'<label class="row2"><span>'+label+'</span><input type="range" id="'+id+'" min="'+mn+'" max="'+mx+'" step="0.05" value="'+v+'"></label>';
  modal('<h2>Settings</h2><div class="sec" style="margin-top:6px">Theme</div><div class="swatches">'+sw+'</div>'+
    tg('uAnim','Animations',UI.anim!=='off')+tg('uPart','Floating particles',UI.particles)+rg('uDim','Background brightness',0.4,1.1,UI.dim)+
    '<div class="sec">Sound &amp; clock</div>'+tg('uSfx','Sound effects',UI.sfx)+rg('uVol','Volume',0.1,1,UI.vol)+tg('u24','24-hour clock',UI.clock24)+
    '<div class="help" style="margin-top:14px">Trophy pop-ups, play-time counting and the Steam key are in <b>Achievements → Settings</b>.</div>'+
    '<div class="line end"><span class="grow"></span><button class="btn primary" id="sCancel">Done</button></div>');
  const set=(k,v)=>{ UI[k]=v; applyUI(); saveUI(); };
  $$('.sw').forEach(b=>b.onclick=()=>{ $$('.sw').forEach(x=>x.classList.toggle('on',x===b)); set('theme',b.dataset.t); flag('theme'); sfx.move(); });
  $('#uAnim').onchange=e=>set('anim',e.target.checked?'on':'off'); $('#uPart').onchange=e=>set('particles',e.target.checked);
  $('#uDim').oninput=e=>set('dim',+e.target.value); $('#uSfx').onchange=e=>{ flag('sound'); set('sfx',e.target.checked); sfx.ok(); };
  $('#uVol').onchange=e=>{ set('vol',+e.target.value); sfx.ok(); }; $('#u24').onchange=e=>set('clock24',e.target.checked);
  $('#sCancel').onclick=closeModal;
}

/* ---------- input: keyboard, wheel, gamepad ---------- */
const overlayOpen=()=>$('#modal').classList.contains('open')||$('#drawer').classList.contains('open')||$('#busy').classList.contains('open');
function back(){ if(overlayOpen()) closeAll(); else if(gd) closeGD(); else if(q) setQ(''); else if(view!=='home') goView('home'); }
document.addEventListener('keydown',e=>{
  const k=e.key; if(k.indexOf('Arrow')===0) flag('kbd');
  if(k==='Escape'){ back(); return; }
  if(overlayOpen()||/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
  const g=sel(); let h=true;
  if(k==='ArrowRight') move(1); else if(k==='ArrowLeft') move(-1);
  else if(k==='ArrowDown'){ if(isGrid()&&!gd) move(cols()); } else if(k==='ArrowUp'){ if(isGrid()&&!gd) move(-cols()); }
  else if(k==='Home'||k==='End'){ const l=cur(); if(l.length){ sfx.move(); pick(l[k==='Home'?0:l.length-1].id,k==='Home'?-1:1); } }
  else if(k==='PageDown'||k==='PageUp') move((k==='PageDown'?1:-1)*(isGrid()?cols()*3:5));
  else if(k==='Enter'&&document.activeElement.tagName!=='BUTTON'){ if(view==='ach'){} else if(isGrid()&&!gd){ if(g) openGD(); } else play(); }
  else if((k==='a'||k==='A')&&g&&view!=='ach') openAch();
  else if((k==='f'||k==='F')&&g&&view!=='ach') api('/api/fav',{id:g.id}).then(()=>reload(g.id));
  else if(k==='l'||k==='L'){ goView(view==='home'?'lib':'home'); }
  else if(k==='/'){ $('#q').classList.add('on'); $('#q').focus(); }
  else if(/^[1-9]$/.test(k)&&view!=='ach'){ const l=cur(); if(l[+k-1]) pick(l[+k-1].id); }
  else h=false;
  if(h) e.preventDefault();
});
let wheelT=0;
$('#row').addEventListener('wheel',e=>{ if(overlayOpen()) return; const n=Date.now(); if(n-wheelT<85) return; wheelT=n; move(e.deltaY>0||e.deltaX>0?1:-1); },{passive:true});
let gpHeld={};
setInterval(()=>{
  const pads=navigator.getGamepads?navigator.getGamepads():[];
  for(const p of pads){ if(!p) continue; const b=i=>!!(p.buttons[i]&&p.buttons[i].pressed);
    const s={l:b(14)||p.axes[0]<-.6,r:b(15)||p.axes[0]>.6,u:b(12)||p.axes[1]<-.6,d:b(13)||p.axes[1]>.6,a:b(0),b:b(1),y:b(3),t:b(4)||b(5)};
    if(s.l||s.r||s.u||s.d||s.a||s.b||s.y||s.t) flag('pad');
    if(!overlayOpen()){
      if(s.l&&!gpHeld.l) move(-1); if(s.r&&!gpHeld.r) move(1);
      if(isGrid()){ if(s.d&&!gpHeld.d) move(cols()); if(s.u&&!gpHeld.u) move(-cols()); }
      if(s.a&&!gpHeld.a){ if(view==='ach'){} else if(isGrid()&&!gd){ if(sel()) openGD(); } else play(); }
      if(s.y&&!gpHeld.y&&sel()&&view!=='ach') openAch();
      if(s.t&&!gpHeld.t){ goView(view==='home'?'lib':'home'); }
    }
    if(s.b&&!gpHeld.b) back();
    gpHeld=s; break; }
},90);

/* ---------- boot ---------- */
$('#logoMark').innerHTML=logoMark();
$$('[data-ic]').forEach(e=>e.innerHTML=svg(e.dataset.ic));
HX=new Xf($('#hero')); SX=new Xf($('#statsBox'));
$$('.tb').forEach(n=>n.onclick=()=>{ sfx.move(); goView(n.dataset.v); });
$('#hero').addEventListener('click',e=>{ if(e.target.closest('.bplay')) play(); else if(e.target.closest('.bmore')) moreMenu(); else if(e.target.closest('.badd')) addGame(); });
$('#statsBox').addEventListener('click',e=>{ if(e.target.closest('.st')) openAch(); });
$('#aL').onclick=()=>move(-1); $('#aR').onclick=()=>move(1);
$('#bSet').onclick=openSettings; $('#bExit').onclick=confirmExit;
$('#bSearch').onclick=()=>{ const i=$('#q'); i.classList.toggle('on'); if(i.classList.contains('on')) i.focus(); else setQ(''); };
$('#q').oninput=e=>setQ(e.target.value,true);
function tick(){ $('#clock').textContent=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',hour12:!UI.clock24}); } tick(); setInterval(tick,15000);
setInterval(async()=>{ try{ const r=await api('/api/ping'); if(rev && r.rev!==rev && !overlayOpen()){ await reload(selId); } rev=r.rev; }catch(e){} },4000);
addEventListener('resize',()=>{ if(fxOn){ fx.width=innerWidth; fx.height=innerHeight; } moveInd($('#tabInd'),$('.tb.on'),true); moveInd($('#sideInd'),$('#sideList .sn.on'),true); if(view==='home') markSel('#row',true); else if(isGrid()) markSel('#grid',true); });
window.addEventListener('pagehide',()=>{ try{ navigator.sendBeacon('/api/bye?t='+TOKEN,'{}'); }catch(e){} });
{ let b=0; const f=()=>{ if(!b){ b=1; sfx.boot(); } }; addEventListener('keydown',f,{once:true}); addEventListener('pointerdown',f,{once:true}); }
reload(null,true).catch(e=>toast(e.message));
</script></body></html>
"""


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--track":
        run_tracker(sys.argv[2])
    else:
        main()
