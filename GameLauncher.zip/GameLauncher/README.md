# Game Launcher

A PlayStation-style game launcher for Windows.

- Press **+** and pick a game's `.exe`. The game stays where it is; the launcher only remembers the path.
- Art, description and achievements come from Steam's public store pages (internet needed, optional).
- Pick a game and press **Play**: the game starts and the launcher closes completely, so nothing of it stays running while you play.
- Play time is counted only if you turn on *Count play time* in Settings (it keeps a tiny hidden helper open while the game runs).
- Top bar: Home / Library / Favorites / Achievements, search and Settings. The left panel shows options for the page you are on. The red button in the bottom-left corner exits.
- Arrow keys / mouse wheel / gamepad to move, Enter / A to play.
- Six color themes, animations, particles, sound effects and a 24-hour clock option are in Settings.
- Add a game: press **+**, pick the `.exe`, and the launcher searches the internet for its picture (works even for renamed or messy folder names). Offline, the game is added without a picture and looked up again later.
- Trophies are made by the launcher itself (no Steam needed): launcher-wide ones in *Achievements*, and a set for every game (first launch, play-time milestones, favorite...) that fills in as you use it. Play-time trophies need *Count play time* in Settings.

## Get the .exe from GitHub (no install on your PC)

1. Create a new repository on GitHub and upload everything from this folder (keep the `.github` folder).
2. Open the **Actions** tab. The build starts by itself after the upload (or press **Run workflow**).
3. When it turns green, open the run and download **GameLauncher-exe** from *Artifacts*. Unzip it and you have `GameLauncher.exe`.

Want a permanent download link? Push a tag such as `v1.0` and the exe is attached to a GitHub Release.

## Run it without building

Install Python 3.8+ from python.org, then double-click `GameLauncher.pyw`.

## Notes

- Windows may show a "SmartScreen" warning for the exe because it isn't code-signed. Choose *More info > Run anyway*.
- Your library is stored in `C:\Users\<you>\.mygamelauncher\`.
- Real achievement progress works for games you own on Steam: add a Steam API key and SteamID64 in Settings, and set your Steam profile's game details to Public. For other games you can tick achievements yourself.
- The launcher opens in an Edge/Chrome app window. Edge comes with Windows.
